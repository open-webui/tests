--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_grant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_grant (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    user_id text,
    key text NOT NULL,
    data json,
    expires_at bigint,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth (
    id character varying NOT NULL,
    email character varying,
    password text,
    active boolean
);


--
-- Name: automation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    data json NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: automation_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_run (
    id text NOT NULL,
    automation_id text NOT NULL,
    chat_id text,
    status text NOT NULL,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    color text,
    is_default boolean NOT NULL,
    data json,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event (
    id text NOT NULL,
    calendar_id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    start_at bigint NOT NULL,
    end_at bigint,
    all_day boolean NOT NULL,
    rrule text,
    color text,
    location text,
    data json,
    meta json,
    is_cancelled boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event_attendee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendee (
    id text NOT NULL,
    event_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    type text,
    is_private boolean,
    archived_at bigint,
    archived_by text,
    deleted_at bigint,
    deleted_by text,
    updated_by text
);


--
-- Name: channel_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_file (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    message_id text
);


--
-- Name: channel_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_member (
    id text NOT NULL,
    channel_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    status text,
    is_active boolean DEFAULT true NOT NULL,
    is_channel_muted boolean DEFAULT false NOT NULL,
    is_channel_pinned boolean DEFAULT false NOT NULL,
    data json,
    meta json,
    joined_at bigint NOT NULL,
    left_at bigint,
    last_read_at bigint,
    updated_at bigint,
    role text,
    invited_by text,
    invited_at bigint
);


--
-- Name: channel_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_webhook (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    profile_image_url text,
    token text NOT NULL,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    user_id character varying,
    title text,
    created_at bigint,
    updated_at bigint,
    share_id text,
    archived boolean,
    chat json,
    pinned boolean,
    meta json DEFAULT '{}'::json NOT NULL,
    folder_id text,
    tasks json,
    summary text,
    last_read_at bigint
);


--
-- Name: chat_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_file (
    id text NOT NULL,
    user_id text NOT NULL,
    chat_id text NOT NULL,
    file_id text NOT NULL,
    message_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text,
    role text NOT NULL,
    parent_id text,
    content json,
    output json,
    model_id text,
    files json,
    sources json,
    embeds json,
    done boolean,
    status_history json,
    error json,
    usage json,
    created_at bigint,
    updated_at bigint,
    context_summary text
);


--
-- Name: chatidtag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chatidtag (
    id character varying NOT NULL,
    tag_name character varying,
    chat_id character varying,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    key text NOT NULL,
    value json NOT NULL,
    updated_at bigint
);


--
-- Name: config_old; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_old (
    id integer NOT NULL,
    data json NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config_old.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    collection_name character varying NOT NULL,
    name character varying,
    title text,
    filename text,
    content text,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    user_id text,
    version bigint,
    type text,
    data json,
    meta json,
    snapshot json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id character varying NOT NULL,
    user_id character varying,
    filename text,
    meta json,
    created_at bigint,
    hash text,
    data json,
    updated_at bigint,
    path text
);


--
-- Name: folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder (
    id text NOT NULL,
    parent_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    items json,
    meta json,
    is_expanded boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    data json
);


--
-- Name: function; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    type text,
    content text,
    meta text,
    valves text,
    is_active boolean,
    is_global boolean,
    updated_at bigint,
    created_at bigint
);


--
-- Name: group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."group" (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    permissions json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: group_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_member (
    id text NOT NULL,
    group_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    updated_at bigint
);


--
-- Name: knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint,
    data json
);


--
-- Name: knowledge_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_directory (
    id text NOT NULL,
    knowledge_id text NOT NULL,
    parent_id text,
    name text NOT NULL,
    user_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: knowledge_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_file (
    id text NOT NULL,
    user_id text NOT NULL,
    knowledge_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    directory_id text
);


--
-- Name: memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory (
    id character varying NOT NULL,
    user_id character varying,
    content text,
    updated_at bigint,
    created_at bigint,
    type character varying DEFAULT 'context'::character varying NOT NULL,
    path text,
    meta json
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    id text NOT NULL,
    user_id text,
    channel_id text,
    content text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    parent_id text,
    reply_to_id text,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at bigint,
    pinned_by text
);


--
-- Name: message_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    message_id text NOT NULL,
    name text NOT NULL,
    created_at bigint
);


--
-- Name: model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model (
    id text NOT NULL,
    user_id text,
    base_model_id text,
    name text,
    params text,
    meta text,
    updated_at bigint,
    created_at bigint,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    id text NOT NULL,
    user_id text,
    title text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: oauth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_session (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pinned_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_note (
    id text NOT NULL,
    user_id text NOT NULL,
    note_id text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: prompt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt (
    id text NOT NULL,
    command character varying,
    user_id character varying NOT NULL,
    name text NOT NULL,
    content text NOT NULL,
    data json,
    meta json,
    is_active boolean DEFAULT true NOT NULL,
    version_id text,
    tags json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: prompt_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt_history (
    id text NOT NULL,
    prompt_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: shared_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_chat (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text NOT NULL,
    title text,
    chat json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    updated_at bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tag (
    id character varying NOT NULL,
    name character varying,
    user_id character varying NOT NULL,
    meta json
);


--
-- Name: tool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    content text,
    specs text,
    meta text,
    valves text,
    updated_at bigint,
    created_at bigint
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id character varying NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    profile_image_url text,
    last_active_at bigint,
    updated_at bigint,
    created_at bigint,
    settings json,
    info json,
    username character varying(50),
    bio text,
    gender text,
    date_of_birth date,
    profile_banner_image_url text,
    timezone character varying,
    presence_state character varying,
    status_emoji character varying,
    status_message text,
    status_expires_at bigint,
    oauth json,
    scim json
);


--
-- Name: config_old id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Data for Name: access_grant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_grant (id, resource_type, resource_id, principal_type, principal_id, permission, created_at) FROM stdin;
31640b8a-8bd0-4bf6-a35c-c0c03c581ec2	prompt	30cb38c4-c25e-46db-8d35-e9914b9266f4	group	71275e92-4c57-472f-82f9-906632f662c8	read	1795595563
8319ddfd-bdf7-4234-b820-049e36c8e063	tool	weather_tool	group	71275e92-4c57-472f-82f9-906632f662c8	read	1795595563
cea0e735-29dd-4644-8994-0f55090509fb	model	research-assistant	user	fd9ef608-ed69-460f-8959-a495ba07ff28	read	1795595563
49a6f859-4077-4061-9b23-b1bae4350cbb	skill	trip-planner	group	71275e92-4c57-472f-82f9-906632f662c8	read	1795595563
a4e67395-4b40-4ed2-bc2a-eacb4b9973a1	skill	trip-planner	user	fd9ef608-ed69-460f-8959-a495ba07ff28	write	1795595563
46debca2-6244-48b7-bc08-e418a4a4be58	skill	house-style	user	*	read	1795595564
72622e50-992b-4084-9321-c5daeacb9684	skill	dave-notes	group	71275e92-4c57-472f-82f9-906632f662c8	read	1795595564
6a88f095-dae0-434e-badb-6bf2a34ba145	knowledge	39c7f51b-d492-44ed-a698-6f63fef0718e	group	71275e92-4c57-472f-82f9-906632f662c8	read	1795595564
244cd9f8-56da-48bb-8850-e52ac0ff9112	shared_chat	20b9206b-3d2b-4ee6-ab0b-b193cb93347b	user	fd9ef608-ed69-460f-8959-a495ba07ff28	read	1795595565
893cd123-7185-465b-a411-20c8dad10673	note	1ce92f8f-c9d4-43a7-a69c-92d5752f8436	user	fd9ef608-ed69-460f-8959-a495ba07ff28	read	1795595568
c21a1d6a-e7aa-4b85-8ab5-00ee55ba8e18	note	1ce92f8f-c9d4-43a7-a69c-92d5752f8436	user	fd9ef608-ed69-460f-8959-a495ba07ff28	write	1795595568
d66d1013-40d1-40ec-aa5d-13fa1387dadd	channel	4f5ed0c8-b2c1-4d5e-b1c4-923dd6e91c6c	group	71275e92-4c57-472f-82f9-906632f662c8	read	1795595568
96f73aa4-b542-41ad-a1f1-22b6d5ae4764	channel	4f5ed0c8-b2c1-4d5e-b1c4-923dd6e91c6c	group	71275e92-4c57-472f-82f9-906632f662c8	write	1795595568
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
42e2978c7933
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, user_id, key, data, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth (id, email, password, active) FROM stdin;
7f472b45-603a-43ba-9bd9-e8ce448f033a	admin@example.com	$2b$12$sBEaZJGWqsPQaxotq0eIH.or8hyC4499JTmorezlB2m2hU.0yYR2m	t
878735d5-0172-4127-ae59-c2404d65d622	alice@example.com	$2b$12$YKoHyyEcl5Ml2sR4J51lseVGTqYvu61OhzjWttyAmh5BhnNN.4iPK	t
fd9ef608-ed69-460f-8959-a495ba07ff28	bob@example.com	$2b$12$5QVJ5sSrt6NutAtsEq5fLO66UUw65fDkdWGDt273WYEr3hydkBznO	t
48057b7c-be29-4b22-88c0-7e85ef771dca	carol@example.com	$2b$12$WXGNR.Ad9mgC4RY7uV5e..ydRP4qzcOySk9sOIHL7DegCwT/ykA3.	t
\.


--
-- Data for Name: automation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation (id, user_id, name, data, meta, is_active, last_run_at, next_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: automation_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_run (id, automation_id, chat_id, status, error, created_at) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar (id, user_id, name, color, is_default, data, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event (id, calendar_id, user_id, title, description, start_at, end_at, all_day, rrule, color, location, data, meta, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendee (id, event_id, user_id, status, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel (id, user_id, name, description, data, meta, created_at, updated_at, type, is_private, archived_at, archived_by, deleted_at, deleted_by, updated_by) FROM stdin;
4f5ed0c8-b2c1-4d5e-b1c4-923dd6e91c6c	7f472b45-603a-43ba-9bd9-e8ce448f033a	lighthouse	Team chatter	null	null	1795595568392603676	1795595568392603937	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: channel_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_file (id, user_id, channel_id, file_id, created_at, updated_at, message_id) FROM stdin;
\.


--
-- Data for Name: channel_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_member (id, channel_id, user_id, created_at, status, is_active, is_channel_muted, is_channel_pinned, data, meta, joined_at, left_at, last_read_at, updated_at, role, invited_by, invited_at) FROM stdin;
290ccbfd-ce93-4dc4-b3b6-72542d791f53	4f5ed0c8-b2c1-4d5e-b1c4-923dd6e91c6c	878735d5-0172-4127-ae59-c2404d65d622	1795595568416616353	joined	t	f	f	null	null	1795595568416616032	\N	1795595568416616253	1795595568416616423	\N	\N	\N
fd2b0534-ee8a-4a5d-8edd-15be3d6eafdd	4f5ed0c8-b2c1-4d5e-b1c4-923dd6e91c6c	fd9ef608-ed69-460f-8959-a495ba07ff28	1795595568455291336	joined	t	f	f	null	null	1795595568455290695	\N	1795595568455291176	1795595568455291456	\N	\N	\N
\.


--
-- Data for Name: channel_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_webhook (id, user_id, channel_id, name, profile_image_url, token, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat (id, user_id, title, created_at, updated_at, share_id, archived, chat, pinned, meta, folder_id, tasks, summary, last_read_at) FROM stdin;
20b9206b-3d2b-4ee6-ab0b-b193cb93347b	878735d5-0172-4127-ae59-c2404d65d622	Packing for Vienna	1795595564	1795595565	47b102b8-8234-406a-9412-ce5b2640b588	f	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "6576bff5-fc8e-40a7-91c0-78dabab3ff26", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1795595564, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1795595565}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1795595566}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1795595567, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1795595568}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "6576bff5-fc8e-40a7-91c0-78dabab3ff26", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1795595564, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1795595566}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1795595567, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1795595568}], "files": [{"type": "file", "id": "6576bff5-fc8e-40a7-91c0-78dabab3ff26", "name": "packing.txt", "status": "uploaded"}], "params": {}}	t	{"tags": ["travel"]}	b67d96db-d9f7-4fa0-b5a1-45c91c9ba7c2	null	\N	1795595565
cc08d9d0-af7b-4a00-8afa-4028252c87d4	878735d5-0172-4127-ae59-c2404d65d622	Schnitzel questions	1795595565	1795595566	\N	f	{"id": "cc08d9d0-af7b-4a00-8afa-4028252c87d4", "title": "Schnitzel questions", "models": ["mock-model"], "history": {"currentId": "ef80df63-5c09-4727-b162-8920255fed79", "messages": {"a351fe69-a02a-430b-9b94-bd4fbfc4ae14": {"id": "a351fe69-a02a-430b-9b94-bd4fbfc4ae14", "parentId": null, "childrenIds": ["c8c51d90-9fd4-48cb-b7e9-c4323f93d80e"], "role": "user", "content": "What is a Schnitzel?", "models": ["mock-model"], "timestamp": 1795595565}, "c8c51d90-9fd4-48cb-b7e9-c4323f93d80e": {"id": "c8c51d90-9fd4-48cb-b7e9-c4323f93d80e", "parentId": "a351fe69-a02a-430b-9b94-bd4fbfc4ae14", "childrenIds": ["50869140-c1c8-4e43-9f0d-e1b3d26b0ff6"], "role": "assistant", "content": "", "done": true, "model": "mock-model", "timestamp": 1795595565, "output": [{"type": "message", "id": "msg_14f11c1dc2f94b51b3c56119", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]}, "50869140-c1c8-4e43-9f0d-e1b3d26b0ff6": {"id": "50869140-c1c8-4e43-9f0d-e1b3d26b0ff6", "parentId": "c8c51d90-9fd4-48cb-b7e9-c4323f93d80e", "childrenIds": ["ef80df63-5c09-4727-b162-8920255fed79"], "role": "user", "content": "How do I eat it?", "models": ["mock-model"], "timestamp": 1795595565}, "ef80df63-5c09-4727-b162-8920255fed79": {"id": "ef80df63-5c09-4727-b162-8920255fed79", "parentId": "50869140-c1c8-4e43-9f0d-e1b3d26b0ff6", "childrenIds": [], "role": "assistant", "content": "", "done": true, "model": "mock-model", "timestamp": 1795595565, "output": [{"type": "message", "id": "msg_54850992f839427e92b26d8e", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]}}}, "messages": [{"role": "user", "content": "What is a Schnitzel?"}], "files": [], "tags": [], "timestamp": 1795595565114}	f	{}	\N	null	\N	1795595565
15a90b2d-5a8b-475b-a7ea-6b51ffd7de07	878735d5-0172-4127-ae59-c2404d65d622	Lighthouse key	1795595566	1795595567	\N	f	{"id": "15a90b2d-5a8b-475b-a7ea-6b51ffd7de07", "title": "Lighthouse key", "models": ["mock-model"], "history": {"currentId": "2d2d58b5-85d9-4f18-b82c-1a81a33af627", "messages": {"613c7ad9-c94b-4d67-abab-65f7bb05761e": {"id": "613c7ad9-c94b-4d67-abab-65f7bb05761e", "parentId": null, "childrenIds": ["2d2d58b5-85d9-4f18-b82c-1a81a33af627"], "role": "user", "content": "Where does the lighthouse key hang?", "models": ["mock-model"], "timestamp": 1795595566, "files": [{"type": "collection", "id": "39c7f51b-d492-44ed-a698-6f63fef0718e", "name": "Handbook"}]}, "2d2d58b5-85d9-4f18-b82c-1a81a33af627": {"id": "2d2d58b5-85d9-4f18-b82c-1a81a33af627", "parentId": "613c7ad9-c94b-4d67-abab-65f7bb05761e", "childrenIds": [], "role": "assistant", "content": "", "done": true, "model": "mock-model", "timestamp": 1795595566, "statusHistory": [{"action": "queries_generated", "queries": ["ok"], "done": false}, {"action": "sources_retrieved", "count": 1, "done": true}], "sources": [{"source": {"type": "collection", "id": "39c7f51b-d492-44ed-a698-6f63fef0718e", "name": "Handbook"}, "document": ["The upgrade handbook says the lighthouse key hangs behind the blue door."], "metadata": [{"created_by": "7f472b45-603a-43ba-9bd9-e8ce448f033a", "embedding_config": "{'engine': 'openai', 'model': 'sentence-transformers/all-MiniLM-L6-v2'}", "start_index": 0, "source": "handbook.txt", "name": "handbook.txt", "hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "file_id": "4e520f8c-c638-4490-b5d1-44881fe8dd76"}], "distances": [0.9999999403953552]}], "output": [{"type": "message", "id": "msg_44ae773b27c84e96b2e4a552", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Behind the blue door [1]."}]}]}}}, "messages": [{"role": "user", "content": "Where does the lighthouse key hang?"}], "files": [{"type": "collection", "id": "39c7f51b-d492-44ed-a698-6f63fef0718e", "name": "Handbook"}], "tags": [], "timestamp": 1795595566192}	f	{}	\N	null	\N	1795595566
601d7db5-8c8d-4c95-bb9f-320d96770a88	878735d5-0172-4127-ae59-c2404d65d622	Old plans	1795595567	1795595567	\N	t	{"title": "Old plans", "models": ["mock-model"], "history": {}}	f	{}	\N	null	\N	1795595567
bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e	fd9ef608-ed69-460f-8959-a495ba07ff28	Getting to the Prater	1795595567	1795595568	\N	f	{"id": "bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e", "title": "Getting to the Prater", "models": ["mock-model"], "history": {"currentId": "4fc84f4f-d798-4bf0-8215-14b79d835d59", "messages": {"f91db9ef-0143-4617-9a38-2f3d8253e3c3": {"id": "f91db9ef-0143-4617-9a38-2f3d8253e3c3", "parentId": null, "childrenIds": ["4706ddf1-0415-4ee2-8586-7c24fdc80331"], "role": "user", "content": "How do I get to the Prater?", "models": ["mock-model"], "timestamp": 1795595567}, "4706ddf1-0415-4ee2-8586-7c24fdc80331": {"id": "4706ddf1-0415-4ee2-8586-7c24fdc80331", "parentId": "f91db9ef-0143-4617-9a38-2f3d8253e3c3", "childrenIds": ["63085264-d1d8-4d38-a46f-8b6cb4339fa2"], "role": "assistant", "content": "", "done": true, "model": "mock-model", "timestamp": 1795595567, "output": [{"type": "message", "id": "msg_67f2de94fea34b6a88cdf551", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Take the U-Bahn."}]}], "usage": {"prompt_tokens": 12, "completion_tokens": 7, "total_tokens": 19, "input_tokens": 12, "output_tokens": 7}, "annotation": {"rating": 1, "reason": "Accurate", "comment": "Exactly the line I needed.", "tags": ["transport"]}, "feedbackId": "2005525d-dd6b-4393-ba7e-8cfc6d197d99", "followUps": ["How long does it take?", "Is there a night line?"], "embeds": ["<p>U2 to Praterstern</p>"]}, "63085264-d1d8-4d38-a46f-8b6cb4339fa2": {"id": "63085264-d1d8-4d38-a46f-8b6cb4339fa2", "parentId": "4706ddf1-0415-4ee2-8586-7c24fdc80331", "childrenIds": ["4fc84f4f-d798-4bf0-8215-14b79d835d59"], "role": "user", "content": "And back?", "models": ["mock-model"], "timestamp": 1795595567}, "4fc84f4f-d798-4bf0-8215-14b79d835d59": {"id": "4fc84f4f-d798-4bf0-8215-14b79d835d59", "parentId": "63085264-d1d8-4d38-a46f-8b6cb4339fa2", "childrenIds": [], "role": "assistant", "content": "", "done": false, "model": "mock-model", "timestamp": 1795595567, "error": {"content": "the provider is down"}}}}, "messages": [{"role": "user", "content": "How do I get to the Prater?"}], "files": [], "tags": [], "timestamp": 1795595567152}	f	{}	\N	null	\N	1795595567
\.


--
-- Data for Name: chat_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_file (id, user_id, chat_id, file_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_message (id, chat_id, user_id, role, parent_id, content, output, model_id, files, sources, embeds, done, status_history, error, usage, created_at, updated_at, context_summary) FROM stdin;
20b9206b-3d2b-4ee6-ab0b-b193cb93347b-u1-0000-4000-8000-000000000000	20b9206b-3d2b-4ee6-ab0b-b193cb93347b	878735d5-0172-4127-ae59-c2404d65d622	user	\N	"What should I pack for Vienna?"	null	\N	[{"type": "file", "id": "6576bff5-fc8e-40a7-91c0-78dabab3ff26", "name": "packing.txt", "status": "uploaded"}]	null	null	t	null	null	null	1795595564	1795595564	\N
20b9206b-3d2b-4ee6-ab0b-b193cb93347b-a1-0000-4000-8000-000000000000	20b9206b-3d2b-4ee6-ab0b-b193cb93347b	878735d5-0172-4127-ae59-c2404d65d622	assistant	u1-0000-4000-8000-000000000000	"Pack an umbrella."	null	mock-model	null	null	null	t	null	null	null	1795595565	1795595565	\N
20b9206b-3d2b-4ee6-ab0b-b193cb93347b-a1b-0000-4000-8000-000000000000	20b9206b-3d2b-4ee6-ab0b-b193cb93347b	878735d5-0172-4127-ae59-c2404d65d622	assistant	u1-0000-4000-8000-000000000000	"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses."	null	mock-model	null	null	null	t	null	null	null	1795595566	1795595565	\N
20b9206b-3d2b-4ee6-ab0b-b193cb93347b-u2-0000-4000-8000-000000000000	20b9206b-3d2b-4ee6-ab0b-b193cb93347b	878735d5-0172-4127-ae59-c2404d65d622	user	a1b-0000-4000-8000-000000000000	"And for the evening?"	null	\N	null	null	null	t	null	null	null	1795595567	1795595565	\N
20b9206b-3d2b-4ee6-ab0b-b193cb93347b-a2-0000-4000-8000-000000000000	20b9206b-3d2b-4ee6-ab0b-b193cb93347b	878735d5-0172-4127-ae59-c2404d65d622	assistant	u2-0000-4000-8000-000000000000	"A light jacket."	null	mock-model	null	null	null	t	null	null	null	1795595568	1795595565	\N
15a90b2d-5a8b-475b-a7ea-6b51ffd7de07-613c7ad9-c94b-4d67-abab-65f7bb05761e	15a90b2d-5a8b-475b-a7ea-6b51ffd7de07	878735d5-0172-4127-ae59-c2404d65d622	user	\N	"Where does the lighthouse key hang?"	null	\N	[{"type": "collection", "id": "39c7f51b-d492-44ed-a698-6f63fef0718e", "name": "Handbook"}]	null	null	t	null	null	null	1795595566	1795595567	\N
cc08d9d0-af7b-4a00-8afa-4028252c87d4-ef80df63-5c09-4727-b162-8920255fed79	cc08d9d0-af7b-4a00-8afa-4028252c87d4	878735d5-0172-4127-ae59-c2404d65d622	assistant	50869140-c1c8-4e43-9f0d-e1b3d26b0ff6	""	[{"type": "message", "id": "msg_54850992f839427e92b26d8e", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]	mock-model	null	null	null	t	null	null	null	1795595565	1795595566	\N
cc08d9d0-af7b-4a00-8afa-4028252c87d4-a351fe69-a02a-430b-9b94-bd4fbfc4ae14	cc08d9d0-af7b-4a00-8afa-4028252c87d4	878735d5-0172-4127-ae59-c2404d65d622	user	\N	"What is a Schnitzel?"	null	\N	null	null	null	t	null	null	null	1795595565	1795595566	\N
cc08d9d0-af7b-4a00-8afa-4028252c87d4-c8c51d90-9fd4-48cb-b7e9-c4323f93d80e	cc08d9d0-af7b-4a00-8afa-4028252c87d4	878735d5-0172-4127-ae59-c2404d65d622	assistant	a351fe69-a02a-430b-9b94-bd4fbfc4ae14	""	[{"type": "message", "id": "msg_14f11c1dc2f94b51b3c56119", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]	mock-model	null	null	null	t	null	null	null	1795595565	1795595566	\N
cc08d9d0-af7b-4a00-8afa-4028252c87d4-50869140-c1c8-4e43-9f0d-e1b3d26b0ff6	cc08d9d0-af7b-4a00-8afa-4028252c87d4	878735d5-0172-4127-ae59-c2404d65d622	user	c8c51d90-9fd4-48cb-b7e9-c4323f93d80e	"How do I eat it?"	null	\N	null	null	null	t	null	null	null	1795595565	1795595566	\N
15a90b2d-5a8b-475b-a7ea-6b51ffd7de07-2d2d58b5-85d9-4f18-b82c-1a81a33af627	15a90b2d-5a8b-475b-a7ea-6b51ffd7de07	878735d5-0172-4127-ae59-c2404d65d622	assistant	613c7ad9-c94b-4d67-abab-65f7bb05761e	""	[{"type": "message", "id": "msg_44ae773b27c84e96b2e4a552", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Behind the blue door [1]."}]}]	mock-model	null	[{"source": {"type": "collection", "id": "39c7f51b-d492-44ed-a698-6f63fef0718e", "name": "Handbook"}, "document": ["The upgrade handbook says the lighthouse key hangs behind the blue door."], "metadata": [{"created_by": "7f472b45-603a-43ba-9bd9-e8ce448f033a", "embedding_config": "{'engine': 'openai', 'model': 'sentence-transformers/all-MiniLM-L6-v2'}", "start_index": 0, "source": "handbook.txt", "name": "handbook.txt", "hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "file_id": "4e520f8c-c638-4490-b5d1-44881fe8dd76"}], "distances": [0.9999999403953552]}]	null	t	[{"action": "queries_generated", "queries": ["ok"], "done": false}, {"action": "sources_retrieved", "count": 1, "done": true}]	null	null	1795595566	1795595567	\N
bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e-4fc84f4f-d798-4bf0-8215-14b79d835d59	bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e	fd9ef608-ed69-460f-8959-a495ba07ff28	assistant	63085264-d1d8-4d38-a46f-8b6cb4339fa2	""	null	mock-model	null	null	null	f	null	{"content": "the provider is down"}	null	1795595567	1795595568	\N
bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e-f91db9ef-0143-4617-9a38-2f3d8253e3c3	bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e	fd9ef608-ed69-460f-8959-a495ba07ff28	user	\N	"How do I get to the Prater?"	null	\N	null	null	null	t	null	null	null	1795595567	1795595568	\N
bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e-4706ddf1-0415-4ee2-8586-7c24fdc80331	bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e	fd9ef608-ed69-460f-8959-a495ba07ff28	assistant	f91db9ef-0143-4617-9a38-2f3d8253e3c3	""	[{"type": "message", "id": "msg_67f2de94fea34b6a88cdf551", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Take the U-Bahn."}]}]	mock-model	null	null	["<p>U2 to Praterstern</p>"]	t	null	null	{"prompt_tokens": 12, "completion_tokens": 7, "total_tokens": 19, "input_tokens": 12, "output_tokens": 7}	1795595567	1795595568	\N
bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e-63085264-d1d8-4d38-a46f-8b6cb4339fa2	bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e	fd9ef608-ed69-460f-8959-a495ba07ff28	user	4706ddf1-0415-4ee2-8586-7c24fdc80331	"And back?"	null	\N	null	null	null	t	null	null	null	1795595567	1795595568	\N
\.


--
-- Data for Name: chatidtag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chatidtag (id, tag_name, chat_id, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config (key, value, updated_at) FROM stdin;
direct.enable	false	1795595561
ollama.enable	false	1795595561
ollama.base_urls	["http://localhost:11434"]	1795595561
ollama.api_configs	{}	1795595561
openai.enable	true	1795595561
openai.api_keys	["sk-mock"]	1795595561
openai.api_base_urls	["http://127.0.0.1:44383/v1"]	1795595561
openai.api_configs	{}	1795595561
models.base_models_cache	false	1795595561
tool_server.connections	[]	1795595561
oauth.client.timeout	""	1795595561
terminal_server.connections	[]	1795595561
code_execution.enable	true	1795595561
code_execution.engine	"pyodide"	1795595561
code_execution.jupyter.url	""	1795595561
code_execution.jupyter.auth	""	1795595561
code_execution.jupyter.auth_token	""	1795595561
code_execution.jupyter.auth_password	""	1795595561
code_execution.jupyter.timeout	60	1795595561
code_interpreter.enable	true	1795595561
memories.background_review.enable	false	1795595561
memories.review_interval_turns	10	1795595561
memories.user_char_limit	2000	1795595561
memories.context_char_limit	2000	1795595561
code_interpreter.engine	"pyodide"	1795595561
code_interpreter.prompt_template	""	1795595561
code_interpreter.jupyter.url	""	1795595561
code_interpreter.jupyter.auth	""	1795595561
code_interpreter.jupyter.auth_token	""	1795595561
code_interpreter.jupyter.auth_password	""	1795595561
code_interpreter.jupyter.timeout	60	1795595561
google_drive.enable	false	1795595561
google_drive.client_id	""	1795595561
google_drive.api_key	""	1795595561
onedrive.enable	false	1795595561
onedrive.sharepoint_url	""	1795595561
onedrive.sharepoint_tenant_id	""	1795595561
rag.content_extraction_engine	""	1795595561
rag.datalab_marker_api_key	""	1795595561
rag.datalab_marker_api_base_url	""	1795595561
rag.datalab_marker_additional_config	""	1795595561
rag.datalab_marker_use_llm	false	1795595561
rag.datalab_marker_skip_cache	false	1795595561
rag.datalab_marker_force_ocr	false	1795595561
rag.datalab_marker_paginate	false	1795595561
rag.datalab_marker_strip_existing_ocr	false	1795595561
rag.datalab_marker_disable_image_extraction	false	1795595561
rag.datalab_marker_format_lines	false	1795595561
rag.datalab_marker_output_format	"markdown"	1795595561
rag.mineru_api_mode	"local"	1795595561
rag.mineru_api_url	"http://localhost:8000"	1795595561
rag.mineru_api_timeout	"300"	1795595561
rag.mineru_api_key	""	1795595561
rag.mineru_params	{}	1795595561
rag.mineru_file_extensions	["pdf"]	1795595561
rag.external_document_loader_url	""	1795595561
rag.external_document_loader_api_key	""	1795595561
rag.external_document_loader_headers	{}	1795595561
rag.tika_server_url	"http://tika:9998"	1795595561
rag.docling_server_url	"http://docling:5001"	1795595561
rag.docling_api_key	""	1795595561
rag.docling_params	{}	1795595561
rag.document_intelligence_endpoint	""	1795595561
rag.document_intelligence_key	""	1795595561
rag.document_intelligence_model	"prebuilt-layout"	1795595561
rag.mistral_ocr_api_base_url	"https://api.mistral.ai/v1"	1795595561
rag.mistral_ocr_api_key	""	1795595561
rag.mistral_ocr_use_base64	false	1795595561
rag.paddleocr_vl_base_url	"http://localhost:8080"	1795595561
rag.paddleocr_vl_token	""	1795595561
rag.bypass_embedding_and_retrieval	false	1795595561
rag.top_k	3	1795595561
rag.top_k_reranker	3	1795595561
rag.relevance_threshold	0.0	1795595561
rag.hybrid_bm25_weight	0.5	1795595561
rag.enable_hybrid_search	false	1795595561
rag.enable_hybrid_search_enriched_texts	false	1795595561
rag.full_context	false	1795595561
rag.file.max_count	null	1795595561
rag.file.max_size	null	1795595561
file.image_compression_width	null	1795595561
file.image_compression_height	null	1795595561
rag.file.allowed_extensions	[]	1795595561
rag.embedding_engine	"openai"	1795595561
rag.pdf_extract_images	false	1795595561
rag.pdf_loader_mode	"page"	1795595561
rag.embedding_model	"sentence-transformers/all-MiniLM-L6-v2"	1795595561
rag.tokenizer_model	""	1795595561
rag.embedding_batch_size	1	1795595561
rag.enable_async_embedding	true	1795595561
rag.embedding_concurrent_requests	0	1795595561
rag.reranking_engine	""	1795595561
rag.reranking_model	""	1795595561
rag.reranking_batch_size	32	1795595561
rag.external_reranker_url	""	1795595561
rag.external_reranker_api_key	""	1795595561
rag.external_reranker_timeout	""	1795595561
rag.text_splitter	""	1795595561
rag.enable_markdown_header_text_splitter	true	1795595561
rag.tiktoken_encoding_name	"cl100k_base"	1795595561
rag.chunk_size	1000	1795595561
rag.chunk_min_size_target	0	1795595561
rag.chunk_overlap	100	1795595561
image_generation.automatic1111.base_url	""	1795595561
image_generation.automatic1111.api_auth	""	1795595561
image_generation.automatic1111.api_params	{}	1795595561
image_generation.comfyui.base_url	""	1795595561
image_generation.comfyui.api_key	""	1795595561
ldap.server.port	389	1795595561
ldap.server.attribute_for_mail	"mail"	1795595561
ldap.server.attribute_for_username	"uid"	1795595561
rag.template	"### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n{{CONTEXT}}\\n</context>\\n"	1795595561
rag.openai.api_base_url	"http://127.0.0.1:44383/v1"	1795595561
rag.openai.api_key	"sk-mock"	1795595561
rag.azure_openai.base_url	""	1795595561
rag.azure_openai.api_key	""	1795595561
rag.azure_openai.api_version	""	1795595561
rag.ollama.base_url	"http://localhost:11434"	1795595561
rag.ollama.api_key	""	1795595561
rag.youtube_loader_language	["en"]	1795595561
rag.youtube_loader_proxy_url	""	1795595561
web.search.enable	false	1795595561
web.search.confirmation.enable	false	1795595561
web.search.confirmation.content	"Your query will be sent to the configured web search provider."	1795595561
web.search.engine	""	1795595561
web.search.bypass_embedding_and_retrieval	false	1795595561
web.search.bypass_web_loader	false	1795595561
web.search.result_count	3	1795595561
web.search.domain.filter_list	[]	1795595561
web.search.concurrent_requests	0	1795595561
web.fetch.max_content_length	null	1795595561
web.loader.engine	""	1795595561
web.loader.concurrent_requests	10	1795595561
web.loader.timeout	""	1795595561
web.loader.ssl_verification	true	1795595561
web.search.trust_env	true	1795595561
web.search.ollama_cloud_api_key	""	1795595561
web.search.searxng_query_url	""	1795595561
web.search.searxng_language	"all"	1795595561
web.search.yacy_query_url	""	1795595561
web.search.yacy_username	""	1795595561
web.search.yacy_password	""	1795595561
web.search.google_pse_api_key	""	1795595561
web.search.google_pse_engine_id	""	1795595561
web.search.brave_search_api_key	""	1795595561
web.search.brave_search_context_tokens	8192	1795595561
web.search.kagi_search_api_key	""	1795595561
web.search.mojeek_search_api_key	""	1795595561
web.search.bocha_search_api_key	""	1795595561
web.search.serpstack_api_key	""	1795595561
web.search.serpstack_https	true	1795595561
web.search.serper_api_key	""	1795595561
web.search.serply_api_key	""	1795595561
web.search.serphouse_api_key	""	1795595561
web.search.serphouse_domain	"google.com"	1795595561
web.search.ddgs_backend	"auto"	1795595561
web.search.jina_api_key	""	1795595561
web.search.jina_api_base_url	""	1795595561
web.search.searchapi_api_key	""	1795595561
web.search.searchapi_engine	""	1795595561
web.search.serpapi_api_key	""	1795595561
web.search.serpapi_engine	""	1795595561
web.search.bing_search_v7_endpoint	"https://api.bing.microsoft.com/v7.0/search"	1795595561
web.search.bing_search_v7_subscription_key	""	1795595561
web.search.azure_ai_search_api_key	""	1795595561
web.search.azure_ai_search_endpoint	""	1795595561
web.search.azure_ai_search_index_name	""	1795595561
web.search.exa_api_key	""	1795595561
web.search.perplexity_api_key	""	1795595561
web.search.perplexity_model	"sonar"	1795595561
web.search.perplexity_search_context_usage	"medium"	1795595561
web.search.perplexity_search_api_url	"https://api.perplexity.ai/search"	1795595561
web.search.microsoft_web_iq_api_base_url	"https://api.microsoft.ai/v3"	1795595561
web.search.microsoft_web_iq_api_key	""	1795595561
web.search.microsoft_web_iq_language	"en"	1795595561
web.search.sougou_api_sid	""	1795595561
web.search.sougou_api_sk	""	1795595561
web.search.tavily_api_key	""	1795595561
web.search.tavily_extract_depth	"basic"	1795595561
web.loader.playwright_ws_url	""	1795595561
web.loader.playwright_timeout	10000	1795595561
web.loader.firecrawl_api_key	""	1795595561
web.loader.firecrawl_api_url	"https://api.firecrawl.dev"	1795595561
web.loader.firecrawl_timeout	""	1795595561
web.search.external_web_search_url	""	1795595561
web.search.external_web_search_api_key	""	1795595561
web.loader.external_web_loader_url	""	1795595561
web.loader.external_web_loader_api_key	""	1795595561
web.search.yandex_web_search_url	""	1795595561
web.search.yandex_web_search_api_key	""	1795595561
web.search.yandex_web_search_config	""	1795595561
web.search.youcom_api_key	""	1795595561
web.search.linkup_api_key	""	1795595561
web.search.linkup_search_params	{}	1795595561
image_generation.enable	false	1795595561
image_generation.engine	"openai"	1795595561
image_generation.model	""	1795595561
image_generation.size	"512x512"	1795595561
image_generation.steps	50	1795595561
image_generation.prompt.enable	true	1795595561
image_generation.comfyui.workflow	"\\n{\\n  \\"3\\": {\\n    \\"inputs\\": {\\n      \\"seed\\": 0,\\n      \\"steps\\": 20,\\n      \\"cfg\\": 8,\\n      \\"sampler_name\\": \\"euler\\",\\n      \\"scheduler\\": \\"normal\\",\\n      \\"denoise\\": 1,\\n      \\"model\\": [\\n        \\"4\\",\\n        0\\n      ],\\n      \\"positive\\": [\\n        \\"6\\",\\n        0\\n      ],\\n      \\"negative\\": [\\n        \\"7\\",\\n        0\\n      ],\\n      \\"latent_image\\": [\\n        \\"5\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"KSampler\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"KSampler\\"\\n    }\\n  },\\n  \\"4\\": {\\n    \\"inputs\\": {\\n      \\"ckpt_name\\": \\"model.safetensors\\"\\n    },\\n    \\"class_type\\": \\"CheckpointLoaderSimple\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Load Checkpoint\\"\\n    }\\n  },\\n  \\"5\\": {\\n    \\"inputs\\": {\\n      \\"width\\": 512,\\n      \\"height\\": 512,\\n      \\"batch_size\\": 1\\n    },\\n    \\"class_type\\": \\"EmptyLatentImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Empty Latent Image\\"\\n    }\\n  },\\n  \\"6\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"Prompt\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"7\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"8\\": {\\n    \\"inputs\\": {\\n      \\"samples\\": [\\n        \\"3\\",\\n        0\\n      ],\\n      \\"vae\\": [\\n        \\"4\\",\\n        2\\n      ]\\n    },\\n    \\"class_type\\": \\"VAEDecode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"VAE Decode\\"\\n    }\\n  },\\n  \\"9\\": {\\n    \\"inputs\\": {\\n      \\"filename_prefix\\": \\"ComfyUI\\",\\n      \\"images\\": [\\n        \\"8\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"SaveImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Save Image\\"\\n    }\\n  }\\n}\\n"	1795595561
image_generation.comfyui.nodes	[]	1795595561
image_generation.openai.api_base_url	"https://api.openai.com/v1"	1795595561
image_generation.openai.api_version	""	1795595561
image_generation.openai.api_key	""	1795595561
image_generation.openai.params	{}	1795595561
image_generation.gemini.api_base_url	""	1795595561
image_generation.gemini.api_key	""	1795595561
image_generation.gemini.endpoint_method	""	1795595561
images.edit.enable	false	1795595561
images.edit.engine	"openai"	1795595561
images.edit.model	""	1795595561
images.edit.size	""	1795595561
images.edit.openai.api_base_url	"https://api.openai.com/v1"	1795595561
images.edit.openai.api_version	""	1795595561
images.edit.openai.api_key	""	1795595561
images.edit.gemini.api_base_url	""	1795595561
images.edit.gemini.api_key	""	1795595561
images.edit.comfyui.base_url	""	1795595561
images.edit.comfyui.api_key	""	1795595561
images.edit.comfyui.workflow	""	1795595561
images.edit.comfyui.nodes	[]	1795595561
audio.stt.whisper_model	"base"	1795595561
audio.stt.deepgram.api_key	""	1795595561
audio.stt.openai.api_base_url	"https://api.openai.com/v1"	1795595561
audio.stt.openai.api_key	""	1795595561
audio.stt.openai.api_request_format	"multipart"	1795595561
audio.stt.engine	""	1795595561
audio.stt.model	""	1795595561
audio.stt.supported_content_types	[]	1795595561
audio.stt.allowed_extensions	["mp3", "wav", "m4a", "webm", "ogg", "flac", "mp4", "mpga", "mpeg"]	1795595561
audio.stt.azure.api_key	""	1795595561
audio.stt.azure.region	""	1795595561
audio.stt.azure.locales	""	1795595561
audio.stt.azure.base_url	""	1795595561
audio.stt.azure.max_speakers	""	1795595561
audio.stt.mistral.api_key	""	1795595561
audio.stt.mistral.api_base_url	"https://api.mistral.ai/v1"	1795595561
audio.stt.mistral.use_chat_completions	false	1795595561
audio.tts.openai.api_base_url	"https://api.openai.com/v1"	1795595561
audio.tts.openai.api_key	""	1795595561
audio.tts.openai.params	{}	1795595561
audio.tts.api_key	""	1795595561
audio.tts.engine	""	1795595561
audio.tts.model	"tts-1"	1795595561
audio.tts.voice	"alloy"	1795595561
audio.tts.split_on	"punctuation"	1795595561
audio.tts.azure.speech_region	""	1795595561
audio.tts.azure.speech_base_url	""	1795595561
audio.tts.azure.speech_output_format	"audio-24khz-160kbitrate-mono-mp3"	1795595561
audio.tts.mistral.api_key	""	1795595561
audio.tts.mistral.api_base_url	"https://api.mistral.ai/v1"	1795595561
ui.enable_login_form	true	1795595561
ui.enable_password_change_form	true	1795595561
ui.default_locale	""	1795595561
ui.default_models	null	1795595561
ui.default_pinned_models	null	1795595561
ui.prompt_suggestions	[{"title": ["Help me study", "vocabulary for a college entrance exam"], "content": "Help me study vocabulary: write a sentence for me to fill in the blank, and I'll try to pick the correct option."}, {"title": ["Give me ideas", "for what to do with my kids' art"], "content": "What are 5 creative things I could do with my kids' art? I don't want to throw them away, but it's also so much clutter."}, {"title": ["Tell me a fun fact", "about the Roman Empire"], "content": "Tell me a random fun fact about the Roman Empire"}, {"title": ["Show me a code snippet", "of a website's sticky header"], "content": "Show me a code snippet of a website's sticky header in CSS and JavaScript."}, {"title": ["Explain options trading", "if I'm familiar with buying and selling stocks"], "content": "Explain options trading in simple terms if I'm familiar with buying and selling stocks."}, {"title": ["Overcome procrastination", "give me tips"], "content": "Could you start by asking me about instances when I procrastinate the most and then give me some suggestions to overcome it?"}]	1795595561
ui.model_order_list	[]	1795595561
models.default_metadata	{}	1795595561
models.default_params	{}	1795595561
ldap.server.label	"LDAP Server"	1795595561
ldap.server.host	"localhost"	1795595561
ui.default_group_id	""	1795595563
automations.auth_token_expires_in	"1h"	1795595561
evaluation.arena.enable	true	1795595561
evaluation.arena.models	[]	1795595561
webhook_url	""	1795595561
task.model.default	""	1795595561
task.model.external	""	1795595561
chat.context_compaction.enable	false	1795595561
chat.context_compaction.token_threshold	80000	1795595561
chat.context_compaction.prompt_template	""	1795595561
task.title.prompt_template	""	1795595561
task.tags.prompt_template	""	1795595561
task.image.prompt_template	""	1795595561
task.follow_up.prompt_template	""	1795595561
task.follow_up.enable	false	1795595561
task.tags.enable	false	1795595561
task.title.enable	false	1795595561
task.query.search.enable	true	1795595561
task.query.retrieval.enable	true	1795595561
task.query.prompt_template	""	1795595561
task.autocomplete.enable	false	1795595561
task.autocomplete.input_max_length	-1	1795595561
task.autocomplete.prompt_template	""	1795595561
task.voice.prompt_template	""	1795595561
task.voice.prompt.enable	true	1795595561
task.tools.prompt_template	""	1795595561
oauth.enable_signup	false	1795595561
oauth.auto_redirect	false	1795595561
oauth.refresh_token.include_scope	false	1795595561
oauth.merge_accounts_by_email	false	1795595561
oauth.google.client_id	""	1795595561
oauth.google.client_secret	""	1795595561
oauth.google.scope	"openid email profile"	1795595561
oauth.google.redirect_uri	""	1795595561
oauth.microsoft.client_id	""	1795595561
oauth.microsoft.client_secret	""	1795595561
oauth.microsoft.tenant_id	""	1795595561
oauth.microsoft.login_base_url	"https://login.microsoftonline.com"	1795595561
oauth.microsoft.picture_url	"https://graph.microsoft.com/v1.0/me/photo/$value"	1795595561
oauth.microsoft.scope	"openid email profile"	1795595561
oauth.microsoft.redirect_uri	""	1795595561
oauth.github.client_id	""	1795595561
oauth.github.client_secret	""	1795595561
oauth.github.scope	"user:email"	1795595561
oauth.github.redirect_uri	""	1795595561
oauth.client_id	""	1795595561
oauth.client_secret	""	1795595561
oauth.provider_url	""	1795595561
oauth.end_session_endpoint	""	1795595561
oauth.redirect_uri	""	1795595561
oauth.scopes	"openid email profile"	1795595561
oauth.timeout	""	1795595561
oauth.token_endpoint_auth_method	null	1795595561
oauth.code_challenge_method	null	1795595561
oauth.provider_name	"SSO"	1795595561
oauth.sub_claim	null	1795595561
oauth.username_claim	"name"	1795595561
oauth.picture_claim	"picture"	1795595561
oauth.email_claim	"email"	1795595561
oauth.group_claim	"groups"	1795595561
oauth.feishu.client_id	""	1795595561
oauth.feishu.client_secret	""	1795595561
oauth.feishu.scope	"contact:user.base:readonly"	1795595561
oauth.feishu.redirect_uri	""	1795595561
oauth.enable_role_mapping	false	1795595561
oauth.enable_group_mapping	false	1795595561
oauth.enable_group_creation	false	1795595561
oauth.group_default_share	true	1795595561
oauth.blocked_groups	"[]"	1795595561
oauth.roles_claim	"roles"	1795595561
oauth.allowed_roles	["user", "admin"]	1795595561
oauth.admin_roles	["admin"]	1795595561
oauth.allowed_domains	["*"]	1795595561
oauth.update_picture_on_login	false	1795595561
oauth.update_name_on_login	false	1795595561
oauth.update_email_on_login	false	1795595561
oauth.audience	""	1795595561
ldap.enable	false	1795595561
ui.banners	[{"id": "upgrade-banner", "type": "info", "title": "Maintenance", "content": "Maintenance on Sunday", "dismissible": true, "timestamp": 1700000000}]	1795595563
ldap.server.app_dn	""	1795595561
ldap.server.app_password	""	1795595561
ldap.server.users_dn	""	1795595561
ldap.server.search_filter	""	1795595561
ldap.server.use_tls	true	1795595561
ldap.server.ca_cert_file	""	1795595561
ldap.server.validate_cert	true	1795595561
ldap.server.ciphers	"ALL"	1795595561
ldap.group.enable_management	false	1795595561
ldap.group.enable_creation	false	1795595561
ldap.server.attribute_for_groups	"memberOf"	1795595561
auth.admin.email	null	1795595563
auth.admin.show	true	1795595563
auth.api_key.allowed_endpoints	""	1795595563
auth.api_key.endpoint_restrictions	false	1795595563
auth.enable_api_keys	false	1795595563
auth.jwt_expiry	"4w"	1795595563
automations.enable	true	1795595563
automations.max_count	""	1795595563
automations.min_interval	""	1795595563
calendar.enable	true	1795595563
channels.enable	true	1795595563
folders.enable	true	1795595563
folders.max_file_count	""	1795595563
memories.enable	true	1795595563
memories.system_context.enable	true	1795595563
notes.enable	true	1795595563
ui.default_user_role	"user"	1795595563
ui.enable_community_sharing	false	1795595563
ui.enable_message_rating	true	1795595563
ui.enable_signup	false	1795595563
ui.enable_user_webhooks	false	1795595563
ui.pending_user_overlay_content	""	1795595563
ui.pending_user_overlay_title	""	1795595563
ui.watermark	""	1795595563
users.enable_status	true	1795595563
webui.url	"https://chat.example.com"	1795595563
user.permissions	{"workspace": {"models": false, "knowledge": false, "prompts": true, "tools": false, "skills": true, "models_import": false, "models_export": false, "prompts_import": false, "prompts_export": false, "tools_import": false, "tools_export": false, "skills_import": false, "skills_export": false}, "sharing": {"models": false, "public_models": false, "knowledge": false, "public_knowledge": false, "prompts": false, "public_prompts": false, "tools": false, "public_tools": false, "skills": false, "public_skills": false, "notes": false, "public_notes": false, "public_chats": false, "public_calendars": false}, "access_grants": {"allow_users": true}, "chat": {"controls": true, "valves": true, "system_prompt": true, "params": true, "file_upload": true, "web_upload": true, "delete": false, "delete_message": true, "continue_response": true, "regenerate_response": true, "rate_response": true, "edit": true, "share": true, "export": true, "import": true, "stt": true, "tts": true, "call": true, "multiple_models": true, "temporary": true, "temporary_enforced": false}, "features": {"api_keys": false, "notes": true, "channels": true, "folders": true, "direct_tool_servers": false, "web_search": true, "image_generation": true, "code_interpreter": true, "memories": true, "automations": false, "calendar": true, "webhooks": false}, "settings": {"interface": true}}	1795595563
\.


--
-- Data for Name: config_old; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_old (id, data, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (collection_name, name, title, filename, content, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, user_id, version, type, data, meta, snapshot, created_at, updated_at) FROM stdin;
49a10abc-0a65-41ad-831a-7b01b41beb6d	878735d5-0172-4127-ae59-c2404d65d622	0	rating	{"rating": 1, "model_id": "mock-model", "sibling_model_ids": null, "reason": "Accurate", "comment": null}	{"chat_id": "cc08d9d0-af7b-4a00-8afa-4028252c87d4", "message_id": "c8c51d90-9fd4-48cb-b7e9-c4323f93d80e"}	{"chat": {}}	1795595567	1795595567
2005525d-dd6b-4393-ba7e-8cfc6d197d99	fd9ef608-ed69-460f-8959-a495ba07ff28	0	rating	{"rating": 1, "model_id": "mock-model", "sibling_model_ids": null, "reason": "Accurate", "comment": null}	{"chat_id": "bc5fefe4-a66f-4ac5-ba1b-39dac7786f3e", "message_id": "4706ddf1-0415-4ee2-8586-7c24fdc80331"}	{"chat": {}}	1795595568	1795595568
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, user_id, filename, meta, created_at, hash, data, updated_at, path) FROM stdin;
4e520f8c-c638-4490-b5d1-44881fe8dd76	7f472b45-603a-43ba-9bd9-e8ce448f033a	handbook.txt	{"name": "handbook.txt", "content_type": "text/plain", "size": 72, "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "data": {}, "collection_name": "39c7f51b-d492-44ed-a698-6f63fef0718e"}	1795595564	51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb	{"status": "completed", "content": "The upgrade handbook says the lighthouse key hangs behind the blue door."}	1795595564	/home/tmp/seed-v0.10.2-9jxvow9b/data/uploads/4e520f8c-c638-4490-b5d1-44881fe8dd76_handbook.txt
6576bff5-fc8e-40a7-91c0-78dabab3ff26	878735d5-0172-4127-ae59-c2404d65d622	packing.txt	{"name": "packing.txt", "content_type": "text/plain", "size": 59, "file_hash": "85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a", "data": {}, "collection_name": "file-6576bff5-fc8e-40a7-91c0-78dabab3ff26"}	1795595564	85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a	{"status": "completed", "content": "Packing list: umbrella, passport, a very old map of Vienna."}	1795595564	/home/tmp/seed-v0.10.2-9jxvow9b/data/uploads/6576bff5-fc8e-40a7-91c0-78dabab3ff26_packing.txt
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder (id, parent_id, user_id, name, items, meta, is_expanded, created_at, updated_at, data) FROM stdin;
3382b8f4-03e6-4659-bba0-7a1162f89652	\N	878735d5-0172-4127-ae59-c2404d65d622	Trips	null	null	f	1795595564	1795595564	null
b67d96db-d9f7-4fa0-b5a1-45c91c9ba7c2	3382b8f4-03e6-4659-bba0-7a1162f89652	878735d5-0172-4127-ae59-c2404d65d622	Vienna	null	null	f	1795595564	1795595564	null
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function (id, user_id, name, type, content, meta, valves, is_active, is_global, updated_at, created_at) FROM stdin;
shout_filter	7f472b45-603a-43ba-9bd9-e8ce448f033a	Shout filter	filter	"""\ntitle: Shout filter\n"""\n\nfrom pydantic import BaseModel\n\n\nclass Filter:\n    class Valves(BaseModel):\n        suffix: str = "!"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def inlet(self, body: dict) -> dict:\n        return body\n	{"description": "Adds emphasis", "manifest": {"title": "Shout filter"}}	{"suffix": "!!!"}	t	t	1795595563	1795595563
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."group" (id, user_id, name, description, data, meta, permissions, created_at, updated_at) FROM stdin;
71275e92-4c57-472f-82f9-906632f662c8	7f472b45-603a-43ba-9bd9-e8ce448f033a	Research	People who read the handbook	{"config": {"share": "members"}}	null	{"workspace": {"models": true}}	1795595563	1795595563
\.


--
-- Data for Name: group_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_member (id, group_id, user_id, created_at, updated_at) FROM stdin;
6f03e345-172a-4c4f-8e97-c53bb12bd120	71275e92-4c57-472f-82f9-906632f662c8	878735d5-0172-4127-ae59-c2404d65d622	1795595563	1795595563
513140e1-7abe-4ddf-b499-937da7013ef7	71275e92-4c57-472f-82f9-906632f662c8	fd9ef608-ed69-460f-8959-a495ba07ff28	1795595563	1795595563
\.


--
-- Data for Name: knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge (id, user_id, name, description, meta, created_at, updated_at, data) FROM stdin;
39c7f51b-d492-44ed-a698-6f63fef0718e	7f472b45-603a-43ba-9bd9-e8ce448f033a	Handbook	Where things are	null	1795595564	1795595564	\N
\.


--
-- Data for Name: knowledge_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_directory (id, knowledge_id, parent_id, name, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_file (id, user_id, knowledge_id, file_id, created_at, updated_at, directory_id) FROM stdin;
05f9d67a-0b44-4bc3-b9b0-56e2472340ec	7f472b45-603a-43ba-9bd9-e8ce448f033a	39c7f51b-d492-44ed-a698-6f63fef0718e	4e520f8c-c638-4490-b5d1-44881fe8dd76	1795595564	1795595564	\N
\.


--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.memory (id, user_id, content, updated_at, created_at, type, path, meta) FROM stdin;
1edc0f4a-7401-4e46-b97e-892ed67a83cb	878735d5-0172-4127-ae59-c2404d65d622	Alice is allergic to peanuts.	1795595568	1795595568	context	\N	{"created_by": "manual"}
56868d66-2a34-4684-8db7-010b1a764583	878735d5-0172-4127-ae59-c2404d65d622	Alice prefers window seats.	1795595568	1795595568	context	\N	{"created_by": "manual"}
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (id, user_id, channel_id, content, data, meta, created_at, updated_at, parent_id, reply_to_id, is_pinned, pinned_at, pinned_by) FROM stdin;
703f0334-2595-4698-b1ef-46fcbac48d57	878735d5-0172-4127-ae59-c2404d65d622	4f5ed0c8-b2c1-4d5e-b1c4-923dd6e91c6c	Who has the lighthouse key?	null	null	1795595568418113057	1795595568418113057	\N	\N	f	\N	\N
3320223c-6082-4522-97f2-eaa7b93e5e9c	fd9ef608-ed69-460f-8959-a495ba07ff28	4f5ed0c8-b2c1-4d5e-b1c4-923dd6e91c6c	Behind the blue door.	null	null	1795595568457041040	1795595568457041040	703f0334-2595-4698-b1ef-46fcbac48d57	\N	f	\N	\N
\.


--
-- Data for Name: message_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reaction (id, user_id, message_id, name, created_at) FROM stdin;
7c41a119-82d4-408b-8077-ded64ec65b42	fd9ef608-ed69-460f-8959-a495ba07ff28	703f0334-2595-4698-b1ef-46fcbac48d57	thumbsup	1795595568506873857
\.


--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model (id, user_id, base_model_id, name, params, meta, updated_at, created_at, is_active) FROM stdin;
research-assistant	7f472b45-603a-43ba-9bd9-e8ce448f033a	mock-model	Research assistant	{"system": "You answer from the handbook.", "temperature": 0.2}	{"profile_image_url": null, "description": "Answers from the handbook", "capabilities": null}	1795595563	1795595563	t
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (id, user_id, title, data, meta, created_at, updated_at) FROM stdin;
1ce92f8f-c9d4-43a7-a69c-92d5752f8436	878735d5-0172-4127-ae59-c2404d65d622	Groceries	{"content": {"md": "# Groceries\\n\\n- apples\\n- *dark* chocolate", "html": "", "json": null}}	null	1795595568330148237	1795595568330148628
\.


--
-- Data for Name: oauth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_session (id, user_id, provider, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pinned_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_note (id, user_id, note_id, created_at) FROM stdin;
\.


--
-- Data for Name: prompt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt (id, command, user_id, name, content, data, meta, is_active, version_id, tags, created_at, updated_at) FROM stdin;
30cb38c4-c25e-46db-8d35-e9914b9266f4	summarize	7f472b45-603a-43ba-9bd9-e8ce448f033a	Summarize	Summarize the following text in three bullet points.	{}	{}	t	b2501d3c-b3b1-4dff-abfb-7cc1136fb452	[]	1795595563	1795595563
318e9cbb-5cd6-4538-b3d9-45a41a1ba548	alice-draft	878735d5-0172-4127-ae59-c2404d65d622	Alice's draft	Draft a polite reply to this email.	{}	{}	t	8efe6da3-1307-4c36-912e-223181406c27	[]	1795595563	1795595563
\.


--
-- Data for Name: prompt_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt_history (id, prompt_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
b2501d3c-b3b1-4dff-abfb-7cc1136fb452	30cb38c4-c25e-46db-8d35-e9914b9266f4	\N	{"name": "Summarize", "content": "Summarize the following text in three bullet points.", "command": "summarize", "data": {}, "meta": {}, "tags": [], "access_grants": [{"id": "31640b8a-8bd0-4bf6-a35c-c0c03c581ec2", "resource_type": "prompt", "resource_id": "30cb38c4-c25e-46db-8d35-e9914b9266f4", "principal_type": "group", "principal_id": "71275e92-4c57-472f-82f9-906632f662c8", "permission": "read", "created_at": 1795595563}]}	7f472b45-603a-43ba-9bd9-e8ce448f033a	Initial version	1795595563
8efe6da3-1307-4c36-912e-223181406c27	318e9cbb-5cd6-4538-b3d9-45a41a1ba548	\N	{"name": "Alice's draft", "content": "Draft a polite reply to this email.", "command": "alice-draft", "data": {}, "meta": {}, "tags": [], "access_grants": []}	878735d5-0172-4127-ae59-c2404d65d622	Initial version	1795595563
\.


--
-- Data for Name: shared_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shared_chat (id, chat_id, user_id, title, chat, created_at, updated_at) FROM stdin;
47b102b8-8234-406a-9412-ce5b2640b588	20b9206b-3d2b-4ee6-ab0b-b193cb93347b	878735d5-0172-4127-ae59-c2404d65d622	Packing for Vienna	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "6576bff5-fc8e-40a7-91c0-78dabab3ff26", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1795595564, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1795595565}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1795595566}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1795595567, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1795595568}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "6576bff5-fc8e-40a7-91c0-78dabab3ff26", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1795595564, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1795595566}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1795595567, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1795595568}], "files": [{"type": "file", "id": "6576bff5-fc8e-40a7-91c0-78dabab3ff26", "name": "packing.txt", "status": "uploaded"}], "params": {}}	1795595565	1795595565
\.


--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill (id, user_id, name, description, content, meta, is_active, updated_at, created_at) FROM stdin;
trip-planner	878735d5-0172-4127-ae59-c2404d65d622	Trip planner	Plans multi-city trips by train.	---\nname: trip-planner\ndescription: Plans multi-city trips by train.\n---\n\n# Trip planner\n\n1. Ask for the cities and the dates.\n2. Prefer night trains over flights.\n3. Keep every transfer above 40 minutes.\n4. Name the platform for every departure.\n	{"tags": ["travel"]}	t	1795595564	1795595563
uebersetzer	878735d5-0172-4127-ae59-c2404d65d622	Übersetzer 日本語 🚀		# Übersetzer 🌍\r\n\r\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\r\n\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \r\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\r\n	{"tags": []}	t	1795595564	1795595564
old-habits	fd9ef608-ed69-460f-8959-a495ba07ff28	Old habits	\N	Answer in Latin.	{"tags": []}	f	1795595564	1795595564
house-style	7f472b45-603a-43ba-9bd9-e8ce448f033a	House style	How every answer is formatted.	Use sentence case headings and no exclamation marks.	{"tags": []}	t	1795595564	1795595564
dave-notes	f392d7dc-c21b-45de-8036-ec8adeda989a	Dave's notes	Left behind.	Hand over to the next shift at six.	{"tags": []}	t	1795595564	1795595564
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tag (id, name, user_id, meta) FROM stdin;
travel	travel	878735d5-0172-4127-ae59-c2404d65d622	\N
\.


--
-- Data for Name: tool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool (id, user_id, name, content, specs, meta, valves, updated_at, created_at) FROM stdin;
weather_tool	7f472b45-603a-43ba-9bd9-e8ce448f033a	Weather	"""\ntitle: Weather\n"""\n\n\nfrom pydantic import BaseModel\n\n\nclass Tools:\n    class Valves(BaseModel):\n        units: str = "metric"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def get_weather(self, city: str) -> str:\n        """Report the weather in a city."""\n        return f"Sunny in {city}"\n	[{"name": "get_weather", "description": "Report the weather in a city.", "parameters": {"properties": {"city": {"type": "string"}}, "required": ["city"], "type": "object"}}]	{"description": "Weather lookups", "manifest": {"title": "Weather"}, "has_user_valves": false}	\N	1795595563	1795595563
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, role, profile_image_url, last_active_at, updated_at, created_at, settings, info, username, bio, gender, date_of_birth, profile_banner_image_url, timezone, presence_state, status_emoji, status_message, status_expires_at, oauth, scim) FROM stdin;
48057b7c-be29-4b22-88c0-7e85ef771dca	Carol Outsider	carol@example.com	user	/user.png	1795595563	1795595563	1795595563	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
7f472b45-603a-43ba-9bd9-e8ce448f033a	Ada Admin	admin@example.com	admin	/user.png	1795595568	1795595562	1795595562	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
878735d5-0172-4127-ae59-c2404d65d622	Alice Author	alice@example.com	user	/user.png	1795595568	1795595562	1795595562	{"ui": {"theme": "dark", "chatBubble": false, "notesSeen": 3}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
fd9ef608-ed69-460f-8959-a495ba07ff28	Bob Reader	bob@example.com	user	/user.png	1795595568	1795595562	1795595562	{"ui": {"models": ["research-assistant"]}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
\.


--
-- Name: config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_id_seq', 1, false);


--
-- Name: access_grant access_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT access_grant_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_key UNIQUE (key);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: automation automation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation
    ADD CONSTRAINT automation_pkey PRIMARY KEY (id);


--
-- Name: automation_run automation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_run
    ADD CONSTRAINT automation_run_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendee calendar_event_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT calendar_event_attendee_pkey PRIMARY KEY (id);


--
-- Name: calendar_event calendar_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event
    ADD CONSTRAINT calendar_event_pkey PRIMARY KEY (id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (id);


--
-- Name: channel_file channel_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_pkey PRIMARY KEY (id);


--
-- Name: channel_member channel_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT channel_member_pkey PRIMARY KEY (id);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_webhook channel_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_pkey PRIMARY KEY (id);


--
-- Name: chat_file chat_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: chat chat_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_share_id_key UNIQUE (share_id);


--
-- Name: chatidtag chatidtag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chatidtag
    ADD CONSTRAINT chatidtag_pkey PRIMARY KEY (id);


--
-- Name: config_old config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey1 PRIMARY KEY (key);


--
-- Name: document document_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_name_key UNIQUE (name);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (collection_name);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id, user_id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: group_member group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_pkey PRIMARY KEY (id);


--
-- Name: group group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pkey PRIMARY KEY (id);


--
-- Name: knowledge_directory knowledge_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_pkey PRIMARY KEY (id);


--
-- Name: knowledge_file knowledge_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_pkey PRIMARY KEY (id);


--
-- Name: knowledge knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge
    ADD CONSTRAINT knowledge_pkey PRIMARY KEY (id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: message_reaction message_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reaction
    ADD CONSTRAINT message_reaction_pkey PRIMARY KEY (id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: oauth_session oauth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_pkey PRIMARY KEY (id);


--
-- Name: pinned_note pinned_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_pkey PRIMARY KEY (id);


--
-- Name: tag pk_id_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_id_user_id PRIMARY KEY (id, user_id);


--
-- Name: prompt_history prompt_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt_history
    ADD CONSTRAINT prompt_history_pkey PRIMARY KEY (id);


--
-- Name: prompt prompt_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt
    ADD CONSTRAINT prompt_new_pkey PRIMARY KEY (id);


--
-- Name: shared_chat shared_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_pkey PRIMARY KEY (id);


--
-- Name: skill skill_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_name_key UNIQUE (name);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- Name: tool tool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool
    ADD CONSTRAINT tool_pkey PRIMARY KEY (id);


--
-- Name: access_grant uq_access_grant_grant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT uq_access_grant_grant UNIQUE (resource_type, resource_id, principal_type, principal_id, permission);


--
-- Name: channel_file uq_channel_file_channel_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT uq_channel_file_channel_file UNIQUE (channel_id, file_id);


--
-- Name: chat_file uq_chat_file_chat_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT uq_chat_file_chat_file UNIQUE (chat_id, file_id);


--
-- Name: calendar_event_attendee uq_event_attendee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT uq_event_attendee UNIQUE (event_id, user_id);


--
-- Name: group_member uq_group_member_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT uq_group_member_group_user UNIQUE (group_id, user_id);


--
-- Name: knowledge_directory uq_knowledge_directory_knowledge_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT uq_knowledge_directory_knowledge_parent_name UNIQUE (knowledge_id, parent_id, name);


--
-- Name: knowledge_file uq_knowledge_file_knowledge_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT uq_knowledge_file_knowledge_file UNIQUE (knowledge_id, file_id);


--
-- Name: pinned_note uq_pinned_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT uq_pinned_note UNIQUE (user_id, note_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: chat_message_chat_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_parent_idx ON public.chat_message USING btree (chat_id, parent_id);


--
-- Name: chat_message_model_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_model_created_idx ON public.chat_message USING btree (model_id, created_at);


--
-- Name: chat_message_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_user_created_idx ON public.chat_message USING btree (user_id, created_at);


--
-- Name: folder_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_idx ON public.chat USING btree (folder_id);


--
-- Name: folder_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_user_id_idx ON public.chat USING btree (folder_id, user_id);


--
-- Name: idx_access_grant_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_principal ON public.access_grant USING btree (principal_type, principal_id);


--
-- Name: idx_access_grant_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_resource ON public.access_grant USING btree (resource_type, resource_id);


--
-- Name: idx_oauth_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_expires_at ON public.oauth_session USING btree (expires_at);


--
-- Name: idx_oauth_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_id ON public.oauth_session USING btree (user_id);


--
-- Name: idx_oauth_session_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_provider ON public.oauth_session USING btree (user_id, provider);


--
-- Name: idx_skill_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_updated_at ON public.skill USING btree (updated_at);


--
-- Name: idx_skill_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_user_id ON public.skill USING btree (user_id);


--
-- Name: is_global_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX is_global_idx ON public.function USING btree (is_global);


--
-- Name: ix_automation_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_next_run ON public.automation USING btree (next_run_at);


--
-- Name: ix_automation_run_automation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_run_automation_id ON public.automation_run USING btree (automation_id);


--
-- Name: ix_calendar_event_attendee_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_attendee_user ON public.calendar_event_attendee USING btree (user_id, status);


--
-- Name: ix_calendar_event_calendar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_calendar ON public.calendar_event USING btree (calendar_id, start_at);


--
-- Name: ix_calendar_event_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_user_date ON public.calendar_event USING btree (user_id, start_at);


--
-- Name: ix_calendar_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_user ON public.calendar USING btree (user_id);


--
-- Name: ix_channel_file_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_channel_id ON public.channel_file USING btree (channel_id);


--
-- Name: ix_channel_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_file_id ON public.channel_file USING btree (file_id);


--
-- Name: ix_channel_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_user_id ON public.channel_file USING btree (user_id);


--
-- Name: ix_chat_file_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_chat_id ON public.chat_file USING btree (chat_id);


--
-- Name: ix_chat_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_file_id ON public.chat_file USING btree (file_id);


--
-- Name: ix_chat_file_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_message_id ON public.chat_file USING btree (message_id);


--
-- Name: ix_chat_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_user_id ON public.chat_file USING btree (user_id);


--
-- Name: ix_chat_message_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_chat_id ON public.chat_message USING btree (chat_id);


--
-- Name: ix_chat_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_created_at ON public.chat_message USING btree (created_at);


--
-- Name: ix_chat_message_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_model_id ON public.chat_message USING btree (model_id);


--
-- Name: ix_chat_message_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_user_id ON public.chat_message USING btree (user_id);


--
-- Name: ix_knowledge_directory_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_knowledge_id ON public.knowledge_directory USING btree (knowledge_id);


--
-- Name: ix_knowledge_directory_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_parent_id ON public.knowledge_directory USING btree (parent_id);


--
-- Name: ix_knowledge_file_directory_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_directory_id ON public.knowledge_file USING btree (directory_id);


--
-- Name: ix_knowledge_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_file_id ON public.knowledge_file USING btree (file_id);


--
-- Name: ix_knowledge_file_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_knowledge_id ON public.knowledge_file USING btree (knowledge_id);


--
-- Name: ix_knowledge_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_user_id ON public.knowledge_file USING btree (user_id);


--
-- Name: ix_memory_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_type ON public.memory USING btree (type);


--
-- Name: ix_memory_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_user_id ON public.memory USING btree (user_id);


--
-- Name: ix_prompt_history_prompt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompt_history_prompt_id ON public.prompt_history USING btree (prompt_id);


--
-- Name: ix_prompt_new_command; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_prompt_new_command ON public.prompt USING btree (command);


--
-- Name: updated_at_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX updated_at_user_id_idx ON public.chat USING btree (updated_at, user_id);


--
-- Name: user_id_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_archived_idx ON public.chat USING btree (user_id, archived);


--
-- Name: user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_idx ON public.tag USING btree (user_id);


--
-- Name: user_id_pinned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_pinned_idx ON public.chat USING btree (user_id, pinned);


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: channel_webhook channel_webhook_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: chat_message chat_message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: channel_file fk_channel_file_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT fk_channel_file_message_id FOREIGN KEY (message_id) REFERENCES public.message(id) ON DELETE CASCADE;


--
-- Name: knowledge_file fk_knowledge_file_directory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT fk_knowledge_file_directory_id FOREIGN KEY (directory_id) REFERENCES public.knowledge_directory(id) ON DELETE SET NULL;


--
-- Name: group_member group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: group_member group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_directory(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: oauth_session oauth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: pinned_note pinned_note_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id) ON DELETE CASCADE;


--
-- Name: shared_chat shared_chat_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

