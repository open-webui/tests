--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_grant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_grant (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    user_id text,
    key text NOT NULL,
    data json,
    expires_at bigint,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: app; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    user_id text,
    is_active boolean DEFAULT false NOT NULL,
    data json NOT NULL,
    api_key text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth (
    id character varying NOT NULL,
    email character varying,
    password text,
    active boolean,
    mfa json,
    session_stamp text
);


--
-- Name: auth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_session (
    id text NOT NULL,
    user_id text,
    refresh_token_id text,
    data json NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    expires_at bigint NOT NULL
);


--
-- Name: automation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    data json NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    folder_id text
);


--
-- Name: automation_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_run (
    id text NOT NULL,
    automation_id text NOT NULL,
    chat_id text,
    status text NOT NULL,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    color text,
    is_default boolean NOT NULL,
    data json,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event (
    id text NOT NULL,
    calendar_id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    start_at bigint NOT NULL,
    end_at bigint,
    all_day boolean NOT NULL,
    rrule text,
    color text,
    location text,
    data json,
    meta json,
    is_cancelled boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event_attendee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendee (
    id text NOT NULL,
    event_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    type text,
    is_private boolean,
    archived_at bigint,
    archived_by text,
    deleted_at bigint,
    deleted_by text,
    updated_by text
);


--
-- Name: channel_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_file (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    message_id text
);


--
-- Name: channel_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_member (
    id text NOT NULL,
    channel_id text NOT NULL,
    user_id text,
    created_at bigint,
    status text,
    is_active boolean DEFAULT true NOT NULL,
    is_channel_muted boolean DEFAULT false NOT NULL,
    is_channel_pinned boolean DEFAULT false NOT NULL,
    data json,
    meta json,
    joined_at bigint NOT NULL,
    left_at bigint,
    last_read_at bigint,
    updated_at bigint,
    role text,
    invited_by text,
    invited_at bigint,
    app_id text,
    CONSTRAINT ck_channel_member_identity CHECK (((user_id IS NULL) <> (app_id IS NULL)))
);


--
-- Name: channel_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_webhook (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    profile_image_url text,
    token text NOT NULL,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    user_id character varying,
    title text,
    created_at bigint,
    updated_at bigint,
    share_id text,
    archived boolean,
    chat json,
    pinned boolean,
    meta json DEFAULT '{}'::json NOT NULL,
    folder_id text,
    tasks json,
    summary text,
    last_read_at bigint,
    current_message_id text,
    variables json,
    timer_at bigint
);


--
-- Name: chat_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_file (
    id text NOT NULL,
    user_id text NOT NULL,
    chat_id text NOT NULL,
    file_id text NOT NULL,
    message_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text,
    role text NOT NULL,
    parent_id text,
    content json,
    output json,
    model_id text,
    files json,
    sources json,
    embeds json,
    done boolean,
    status_history json,
    error json,
    usage json,
    created_at bigint,
    updated_at bigint,
    context_summary text,
    meta json
);


--
-- Name: chat_view_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_view_state (
    user_id text NOT NULL,
    chat_id text NOT NULL,
    state json NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chatidtag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chatidtag (
    id character varying NOT NULL,
    tag_name character varying,
    chat_id character varying,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment (
    id text NOT NULL,
    user_id text,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    parent_id text,
    reply_to_id text,
    content text NOT NULL,
    target_type text,
    target_id text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    deleted_at bigint
);


--
-- Name: comment_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    comment_id text NOT NULL,
    name text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    key text NOT NULL,
    value json NOT NULL,
    updated_at bigint
);


--
-- Name: config_old; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_old (
    id integer NOT NULL,
    data json NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config_old.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    collection_name character varying NOT NULL,
    name character varying,
    title text,
    filename text,
    content text,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    user_id text,
    version bigint,
    type text,
    data json,
    meta json,
    snapshot json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id character varying NOT NULL,
    user_id character varying,
    filename text,
    meta json,
    created_at bigint,
    hash text,
    data json,
    updated_at bigint,
    path text
);


--
-- Name: folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder (
    id text NOT NULL,
    parent_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    items json,
    meta json,
    is_expanded boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    data json
);


--
-- Name: function; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    type text,
    content text,
    meta text,
    valves text,
    is_active boolean,
    is_global boolean,
    updated_at bigint,
    created_at bigint,
    version_id text
);


--
-- Name: function_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function_history (
    id text NOT NULL,
    function_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."group" (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    permissions json,
    created_at bigint,
    updated_at bigint,
    parent_group_id text
);


--
-- Name: group_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_member (
    id text NOT NULL,
    group_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    updated_at bigint
);


--
-- Name: knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint,
    data json
);


--
-- Name: knowledge_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_directory (
    id text NOT NULL,
    knowledge_id text NOT NULL,
    parent_id text,
    name text NOT NULL,
    user_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: knowledge_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_file (
    id text NOT NULL,
    user_id text NOT NULL,
    knowledge_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    directory_id text
);


--
-- Name: memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory (
    id character varying NOT NULL,
    user_id character varying,
    content text,
    updated_at bigint,
    created_at bigint,
    type character varying DEFAULT 'context'::character varying NOT NULL,
    path text,
    meta json
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    id text NOT NULL,
    user_id text,
    channel_id text,
    content text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    parent_id text,
    reply_to_id text,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at bigint,
    pinned_by text,
    app_id text
);


--
-- Name: message_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    message_id text NOT NULL,
    name text NOT NULL,
    created_at bigint
);


--
-- Name: model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model (
    id text NOT NULL,
    user_id text,
    base_model_id text,
    name text,
    params text,
    meta text,
    updated_at bigint,
    created_at bigint,
    is_active boolean DEFAULT true NOT NULL,
    version_id text
);


--
-- Name: model_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_history (
    id text NOT NULL,
    model_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    id text NOT NULL,
    user_id text,
    title text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification (
    id text NOT NULL,
    user_id text NOT NULL,
    event_type text NOT NULL,
    event_key text NOT NULL,
    actor_type text NOT NULL,
    actor_id text,
    resource_type text,
    resource_id text,
    object_type text,
    object_id text,
    data json NOT NULL,
    seen_at bigint,
    read_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    CONSTRAINT ck_notification_actor CHECK ((actor_type = ANY (ARRAY['user'::text, 'system'::text]))),
    CONSTRAINT ck_notification_object CHECK (((object_type IS NULL) = (object_id IS NULL))),
    CONSTRAINT ck_notification_resource CHECK (((resource_type IS NULL) = (resource_id IS NULL)))
);


--
-- Name: oauth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_session (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pinned_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_note (
    id text NOT NULL,
    user_id text NOT NULL,
    note_id text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: prompt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt (
    id text NOT NULL,
    command character varying,
    user_id character varying NOT NULL,
    name text NOT NULL,
    content text NOT NULL,
    data json,
    meta json,
    is_active boolean DEFAULT true NOT NULL,
    version_id text,
    tags json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: prompt_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt_history (
    id text NOT NULL,
    prompt_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: shared_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_chat (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text NOT NULL,
    title text,
    chat json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    updated_at bigint NOT NULL,
    created_at bigint NOT NULL,
    version_id text,
    data json
);


--
-- Name: skill_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_history (
    id text NOT NULL,
    skill_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tag (
    id character varying NOT NULL,
    name character varying,
    user_id character varying NOT NULL,
    meta json
);


--
-- Name: tool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    content text,
    specs text,
    meta text,
    valves text,
    updated_at bigint,
    created_at bigint,
    version_id text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: tool_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_history (
    id text NOT NULL,
    tool_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id character varying NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    profile_image_url text,
    last_active_at bigint,
    updated_at bigint,
    created_at bigint,
    settings json,
    info json,
    username character varying(50),
    bio text,
    gender text,
    date_of_birth date,
    profile_banner_image_url text,
    timezone character varying,
    presence_state character varying,
    status_emoji character varying,
    status_message text,
    status_expires_at bigint,
    oauth json,
    scim json,
    variables json
);


--
-- Name: config_old id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Data for Name: access_grant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_grant (id, resource_type, resource_id, principal_type, principal_id, permission, created_at) FROM stdin;
82faca8e-ff42-4765-af07-a95c5e4f0027	prompt	8d5c917b-b8d5-45e1-ad9a-4aecab91c4ff	group	1a9e8b27-82cc-4624-942c-1f93b14acc08	read	1795595630
67fe93b0-5743-46f8-9dbd-cb322f74be04	tool	weather_tool	group	1a9e8b27-82cc-4624-942c-1f93b14acc08	read	1795595630
bf2f66a6-bf7d-4471-af20-05005abaeeaa	model	research-assistant	user	1636581a-57a9-49a3-abd9-7079db647896	read	1795595630
b4c0418e-b08b-4c32-af8a-bb67a518e4bb	skill	trip-planner	group	1a9e8b27-82cc-4624-942c-1f93b14acc08	read	1795595630
20b78678-ac43-4c96-9a7f-32e4e3256fe6	skill	trip-planner	user	1636581a-57a9-49a3-abd9-7079db647896	write	1795595630
126930f3-cd97-40a9-93c4-739aaeec8d54	skill	house-style	user	*	read	1795595632
7b92c5c3-de8d-4bb1-837b-04d358fdce3b	skill	dave-notes	group	1a9e8b27-82cc-4624-942c-1f93b14acc08	read	1795595632
636c3a91-6f67-4cb2-96aa-227bcea0fa32	knowledge	2e700ced-9c11-4e00-b64f-719db7f4e9e6	group	1a9e8b27-82cc-4624-942c-1f93b14acc08	read	1795595632
31a4c9b7-59bf-46bb-a5e8-c5e70a97ecd2	shared_chat	0d09fe46-67bd-406b-b955-4779a6a6c2ef	user	1636581a-57a9-49a3-abd9-7079db647896	read	1795595632
c72f1089-d178-40b5-8d95-fd57cd158def	shared_chat	0f1f89a1-ad51-4992-9007-d27279807d50	user	1636581a-57a9-49a3-abd9-7079db647896	read	1795595641
052ab030-253f-406f-9cd1-9f0dfe8e198f	note	a907d19c-5d38-4877-b9eb-e9af71935f26	user	1636581a-57a9-49a3-abd9-7079db647896	read	1795595641
d8b4235b-a27e-4168-ab82-856d5a682e03	note	a907d19c-5d38-4877-b9eb-e9af71935f26	user	1636581a-57a9-49a3-abd9-7079db647896	write	1795595641
d110f28a-62d4-4db0-a8a0-81fb56b4a215	channel	c88311b7-4e54-4203-bfe4-927b32a3aa98	group	1a9e8b27-82cc-4624-942c-1f93b14acc08	read	1795595641
82cf35f1-0012-4976-b193-e56ebc09ab59	channel	c88311b7-4e54-4203-bfe4-927b32a3aa98	group	1a9e8b27-82cc-4624-942c-1f93b14acc08	write	1795595641
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
9f6c2a8d1b43
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, user_id, key, data, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app (id, slug, name, user_id, is_active, data, api_key, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth (id, email, password, active, mfa, session_stamp) FROM stdin;
41fa65e2-730a-4451-be4a-29363294205f	admin@example.com	$2b$12$jtykhaNuK1O5d6KYizUG6Ookffen6mOmC6IFyru1uIlLYbDSUAY3.	t	\N	97c257ff-fd8d-4e9d-aedd-88ab17727279
9e5a97c6-283b-4584-a48b-35f1b16fe74f	alice@example.com	$2b$12$e2B.JXOVdjvGIbyWCKyVPuqDyS/BVRr3hkvDzA1apidtztjqQpLSK	t	\N	96160390-57c6-4249-9dbf-fdf9e58e647d
1636581a-57a9-49a3-abd9-7079db647896	bob@example.com	$2b$12$Ym2qLyFBrVzkTD2SanYeROghww1cU3b.bkavUYmYxVQUAOngEZvPu	t	\N	18079070-1a91-4180-be14-724315a4c8fa
6fc344c0-d10a-4731-80c1-4719e317424d	carol@example.com	$2b$12$FxJUMK.Y1Jis.BsLLB8EsOQJ474m72aQAKujy8udxgzmo7XB4GIqe	t	\N	b9c31580-7a3a-4037-8f50-0624eec40cb8
\.


--
-- Data for Name: auth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_session (id, user_id, refresh_token_id, data, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: automation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation (id, user_id, name, data, meta, is_active, last_run_at, next_run_at, created_at, updated_at, folder_id) FROM stdin;
\.


--
-- Data for Name: automation_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_run (id, automation_id, chat_id, status, error, created_at) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar (id, user_id, name, color, is_default, data, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event (id, calendar_id, user_id, title, description, start_at, end_at, all_day, rrule, color, location, data, meta, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendee (id, event_id, user_id, status, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel (id, user_id, name, description, data, meta, created_at, updated_at, type, is_private, archived_at, archived_by, deleted_at, deleted_by, updated_by) FROM stdin;
c88311b7-4e54-4203-bfe4-927b32a3aa98	41fa65e2-730a-4451-be4a-29363294205f	lighthouse	Team chatter	null	null	1795595641915899453	1795595641915899854	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: channel_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_file (id, user_id, channel_id, file_id, created_at, updated_at, message_id) FROM stdin;
\.


--
-- Data for Name: channel_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_member (id, channel_id, user_id, created_at, status, is_active, is_channel_muted, is_channel_pinned, data, meta, joined_at, left_at, last_read_at, updated_at, role, invited_by, invited_at, app_id) FROM stdin;
e0aeb812-ba17-4d80-b23d-7c10656c5dbd	c88311b7-4e54-4203-bfe4-927b32a3aa98	9e5a97c6-283b-4584-a48b-35f1b16fe74f	1795595641943671647	joined	t	f	f	null	null	1795595641943671166	\N	1795595641943671466	1795595641943671707	\N	\N	\N	\N
c217babe-2eb4-4625-a521-ef265fec1ce3	c88311b7-4e54-4203-bfe4-927b32a3aa98	1636581a-57a9-49a3-abd9-7079db647896	1795595641990107464	joined	t	f	f	null	null	1795595641990106823	\N	1795595641990107354	1795595641990107544	\N	\N	\N	\N
\.


--
-- Data for Name: channel_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_webhook (id, user_id, channel_id, name, profile_image_url, token, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat (id, user_id, title, created_at, updated_at, share_id, archived, chat, pinned, meta, folder_id, tasks, summary, last_read_at, current_message_id, variables, timer_at) FROM stdin;
0d09fe46-67bd-406b-b955-4779a6a6c2ef	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Packing for Vienna	1795595632	1795595632	44bac9fb-44c6-49c5-bd68-940ffc80020a	f	{"title":"Packing for Vienna","models":["mock-model"],"history":{"messages":{"u1-0000-4000-8000-000000000000":{"id":"u1-0000-4000-8000-000000000000","parentId":null,"childrenIds":["a1-0000-4000-8000-000000000000","a1b-0000-4000-8000-000000000000"],"role":"user","content":"What should I pack for Vienna?","files":[{"type":"file","id":"ccdbdb1f-d5d2-464e-b417-fcfd34542acd","name":"packing.txt","status":"uploaded"}],"timestamp":1795595632,"models":["mock-model"],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"a1-0000-4000-8000-000000000000":{"id":"a1-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"Pack an umbrella.","model":"mock-model","done":true,"timestamp":1795595633,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"},"a1b-0000-4000-8000-000000000000":{"id":"a1b-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":["u2-0000-4000-8000-000000000000"],"role":"assistant","content":"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.","model":"mock-model","done":true,"timestamp":1795595634,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"},"u2-0000-4000-8000-000000000000":{"id":"u2-0000-4000-8000-000000000000","parentId":"a1b-0000-4000-8000-000000000000","childrenIds":["a2-0000-4000-8000-000000000000"],"role":"user","content":"And for the evening?","timestamp":1795595635,"models":["mock-model"],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"a2-0000-4000-8000-000000000000":{"id":"a2-0000-4000-8000-000000000000","parentId":"u2-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"A light jacket.","model":"mock-model","done":true,"timestamp":1795595636,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"}},"currentId":"a2-0000-4000-8000-000000000000"},"messages":[{"id":"u1-0000-4000-8000-000000000000","parentId":null,"childrenIds":["a1-0000-4000-8000-000000000000","a1b-0000-4000-8000-000000000000"],"role":"user","content":"What should I pack for Vienna?","files":[{"type":"file","id":"ccdbdb1f-d5d2-464e-b417-fcfd34542acd","name":"packing.txt","status":"uploaded"}],"timestamp":1795595632,"models":["mock-model"],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},{"id":"a1b-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":["u2-0000-4000-8000-000000000000"],"role":"assistant","content":"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.","model":"mock-model","done":true,"timestamp":1795595634,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"},{"id":"u2-0000-4000-8000-000000000000","parentId":"a1b-0000-4000-8000-000000000000","childrenIds":["a2-0000-4000-8000-000000000000"],"role":"user","content":"And for the evening?","timestamp":1795595635,"models":["mock-model"],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},{"id":"a2-0000-4000-8000-000000000000","parentId":"u2-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"A light jacket.","model":"mock-model","done":true,"timestamp":1795595636,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"}],"files":[{"type":"file","id":"ccdbdb1f-d5d2-464e-b417-fcfd34542acd","name":"packing.txt","status":"uploaded"}],"params":{}}	t	{"tags":["travel"]}	2dcd5fd8-dcbb-4100-bf78-2aef31256c9c	null	\N	1795595632	a2-0000-4000-8000-000000000000	{}	\N
a312cac5-d61d-4460-b514-d21f986c5c63	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Schnitzel questions	1795595632	1795595633	\N	f	{"id":"a312cac5-d61d-4460-b514-d21f986c5c63","title":"Schnitzel questions","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"e1f82a33-729b-4b7d-b65d-67cad33ff88d","messages":{"d392e665-e66e-40e7-9d3e-bd1d64891f0f":{"id":"d392e665-e66e-40e7-9d3e-bd1d64891f0f","parentId":null,"childrenIds":["036bbd5b-1f44-4ed7-8720-8cd91b0df331"],"role":"user","content":"What is a Schnitzel?","models":["mock-model"],"timestamp":1795595632,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"036bbd5b-1f44-4ed7-8720-8cd91b0df331":{"id":"036bbd5b-1f44-4ed7-8720-8cd91b0df331","parentId":"d392e665-e66e-40e7-9d3e-bd1d64891f0f","childrenIds":["73ab61a0-b601-4288-b51e-425e91d1bb5b"],"role":"assistant","content":"Schnitzel is a breaded cutlet.","done":true,"model":"mock-model","timestamp":1795595632,"meta":{"task_id":"fcaff070-d9c0-4143-a18e-bd678508ac76","response_started_at":1795595632.7782192,"response_ended_at":1795595633.2541645},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_2a3c43aa65f64592a2b01f5c","call_id":"fc_2a3c43aa65f64592a2b01f5c","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_7cf9faf249704bc993a4453b","call_id":"fc_2a3c43aa65f64592a2b01f5c","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_1e451c15c20e4e018a312590","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Schnitzel is a breaded cutlet."}]}],"usage":{"incomplete":true}},"73ab61a0-b601-4288-b51e-425e91d1bb5b":{"id":"73ab61a0-b601-4288-b51e-425e91d1bb5b","parentId":"036bbd5b-1f44-4ed7-8720-8cd91b0df331","childrenIds":["e1f82a33-729b-4b7d-b65d-67cad33ff88d"],"role":"user","content":"How do I eat it?","models":["mock-model"],"timestamp":1795595633,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"e1f82a33-729b-4b7d-b65d-67cad33ff88d":{"id":"e1f82a33-729b-4b7d-b65d-67cad33ff88d","parentId":"73ab61a0-b601-4288-b51e-425e91d1bb5b","childrenIds":[],"role":"assistant","content":"Try it with lemon.","done":true,"model":"mock-model","modelIdx":null,"timestamp":1795595633,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","meta":{"task_id":"566a9496-61a6-4bb0-8946-47632191bb47","response_started_at":1795595633.3850703,"response_ended_at":1795595633.8248253},"output":[{"type":"message","id":"msg_6129daf4c9a044e88c05e294","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Try it with lemon."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"What is a Schnitzel?"}],"files":[],"tags":[],"timestamp":1795595632753}	f	{}	\N	null	\N	1795595632	e1f82a33-729b-4b7d-b65d-67cad33ff88d	{}	\N
0f1f89a1-ad51-4992-9007-d27279807d50	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Weather in Graz	1795595636	1795595637	b813eeb6-95f6-45f3-ae21-4ace825b337a	f	{"id":"0f1f89a1-ad51-4992-9007-d27279807d50","title":"Weather in Graz","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"0921fb70-ef05-434b-8327-fc7ea6b67fad","messages":{"3b7ad9c2-266a-4557-bee6-04dd1e252355":{"id":"3b7ad9c2-266a-4557-bee6-04dd1e252355","parentId":null,"childrenIds":["0921fb70-ef05-434b-8327-fc7ea6b67fad"],"role":"user","user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","content":"What is the weather in Graz?","models":["mock-model"],"timestamp":1795595636,"user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"0921fb70-ef05-434b-8327-fc7ea6b67fad":{"id":"0921fb70-ef05-434b-8327-fc7ea6b67fad","parentId":"3b7ad9c2-266a-4557-bee6-04dd1e252355","childrenIds":[],"role":"assistant","content":"It is sunny in Graz, so leave the umbrella at home.","done":true,"model":"mock-model","timestamp":1795595636,"modelIdx":0,"meta":{"task_id":"d44b445b-1d9d-4dec-8e1a-b1ed6c10d899","response_started_at":1795595636.3402812,"response_ended_at":1795595637.1931596},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_c33573d258cc4ab3afc123f4","call_id":"fc_c33573d258cc4ab3afc123f4","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_74885fa12f604f1cb4d09cc3","call_id":"fc_c33573d258cc4ab3afc123f4","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"get_weather","arguments":"{\\"city\\": \\"Graz\\"}","status":"completed","started_at":1795595636.7800179,"ended_at":1795595636.7812085,"duration":0.0011906449944945052,"tool_id":"weather_tool"},{"type":"function_call_output","id":"fco_e5bc45b29d624c378b94ee5c","call_id":"call_1","output":[{"type":"input_text","text":"Sunny in Graz"}],"status":"completed"},{"type":"reasoning","id":"r_90ac9ca9d7d34f72b2af171f","status":"completed","start_tag":"<think>","end_tag":"</think>","attributes":{"type":"reasoning_content"},"content":[{"type":"output_text","text":"The weather tool says sunny, so no umbrella is needed."}],"summary":null,"started_at":1795595637.1908998,"ended_at":1795595637.191013,"duration":0},{"type":"message","id":"msg_aca895b6e0a64da88804fdb4","status":"completed","role":"assistant","content":[{"type":"output_text","text":"It is sunny in Graz, so leave the umbrella at home."}]}],"usage":{"incomplete":true,"input_tokens":42,"output_tokens":7,"total_tokens":49,"prompt_tokens":42,"completion_tokens":7}}}},"messages":[{"role":"user","content":"What is the weather in Graz?"}],"files":[],"tags":[],"timestamp":1795595636318}	f	{}	\N	null	\N	1795595636	0921fb70-ef05-434b-8327-fc7ea6b67fad	{}	\N
32b8ab93-497c-4574-b6fb-7501e3236e1f	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Lighthouse key	1795595633	1795595634	\N	f	{"id":"32b8ab93-497c-4574-b6fb-7501e3236e1f","title":"Lighthouse key","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"51d75adb-4ffa-4e09-8545-a4b760b5624b","messages":{"f5b9a4fd-fdd0-4bc6-8e13-2332ea4f45f5":{"id":"f5b9a4fd-fdd0-4bc6-8e13-2332ea4f45f5","parentId":null,"childrenIds":["51d75adb-4ffa-4e09-8545-a4b760b5624b"],"role":"user","content":"Where does the lighthouse key hang?","models":["mock-model"],"timestamp":1795595633,"files":[{"type":"collection","id":"2e700ced-9c11-4e00-b64f-719db7f4e9e6","name":"Handbook"}],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"51d75adb-4ffa-4e09-8545-a4b760b5624b":{"id":"51d75adb-4ffa-4e09-8545-a4b760b5624b","parentId":"f5b9a4fd-fdd0-4bc6-8e13-2332ea4f45f5","childrenIds":[],"role":"assistant","content":"Behind the blue door [1].","done":true,"model":"mock-model","timestamp":1795595633,"meta":{"task_id":"ec260634-66a5-49a4-b03a-967f10425984","response_started_at":1795595633.8977861,"response_ended_at":1795595634.762565},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","sources":[{"source":{"id":"8a88c64c-6825-475c-9d18-53791115fb4a","name":"handbook.txt","type":"file"},"document":["The upgrade handbook says the lighthouse key hangs behind the blue door."],"metadata":[{"file_id":"8a88c64c-6825-475c-9d18-53791115fb4a","name":"handbook.txt","source":"handbook.txt"}],"distances":[0.9999999403953552]}],"output":[{"type":"function_call","id":"fc_f467b04aaf154606b130e37c","call_id":"fc_f467b04aaf154606b130e37c","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_1dd3f616bc3f41ebb26bb08c","call_id":"fc_f467b04aaf154606b130e37c","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"query_knowledge_files","arguments":"{\\"query\\": \\"lighthouse key\\", \\"knowledge_ids\\": [\\"2e700ced-9c11-4e00-b64f-719db7f4e9e6\\"]}","status":"completed","started_at":1795595634.3292935,"ended_at":1795595634.341974,"duration":0.012680514002568088,"tool_id":"builtin:query_knowledge_files","tool_type":"builtin"},{"type":"function_call_output","id":"fco_a5074d4461fb4afe8a284c6e","call_id":"call_1","output":[{"type":"input_text","text":"[{\\"content\\":\\"The upgrade handbook says the lighthouse key hangs behind the blue door.\\",\\"source\\":\\"handbook.txt\\",\\"file_id\\":\\"8a88c64c-6825-475c-9d18-53791115fb4a\\",\\"distance\\":0.9999999403953552}]\\n\\n### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n<source id=\\"1\\" name=\\"handbook.txt\\" resource-type=\\"file\\" resource-id=\\"8a88c64c-6825-475c-9d18-53791115fb4a\\"></source>\\n</context>\\n"}],"status":"completed"},{"type":"message","id":"msg_2fb7f07c7d87469d99ab9eed","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Behind the blue door [1]."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Where does the lighthouse key hang?"}],"files":[{"type":"collection","id":"2e700ced-9c11-4e00-b64f-719db7f4e9e6","name":"Handbook"}],"tags":[],"timestamp":1795595633875}	f	{}	\N	null	\N	1795595633	51d75adb-4ffa-4e09-8545-a4b760b5624b	{}	\N
781d9d1b-1f81-4c07-b81b-7187ca557c14	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Old plans	1795595634	1795595634	\N	t	{"title":"Old plans","models":["mock-model"],"history":{}}	f	{}	\N	null	\N	1795595634	\N	{}	\N
8faa427a-c740-422a-b204-b49e0b8ff2f5	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Sub-agent: List three museums near the Ring.	1795595640	1795595640	\N	f	{"id":"8faa427a-c740-422a-b204-b49e0b8ff2f5","title":"Sub-agent: List three museums near the Ring.","models":["mock-model"],"history":{"currentId":"8ad944df-daed-467d-8a91-e0d4d06441d9","messages":{"d0844676-ea97-4a49-bc2c-cb78dac5e77d":{"id":"d0844676-ea97-4a49-bc2c-cb78dac5e77d","parentId":null,"childrenIds":["8ad944df-daed-467d-8a91-e0d4d06441d9"],"role":"user","content":"List three museums near the Ring.","timestamp":1795595640,"models":["mock-model"]},"8ad944df-daed-467d-8a91-e0d4d06441d9":{"id":"8ad944df-daed-467d-8a91-e0d4d06441d9","parentId":"d0844676-ea97-4a49-bc2c-cb78dac5e77d","childrenIds":[],"role":"assistant","content":"Albertina, Leopold Museum and Kunsthistorisches Museum.","done":true,"model":"mock-model","timestamp":1795595640,"modelIdx":null,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","meta":{"task_id":"9c4ec77e-b68a-4e4f-9fe0-e0ff0fe4fda6","response_started_at":1795595640.3195531,"response_ended_at":1795595640.7406678},"output":[{"type":"function_call","id":"fc_83fb518620ae4cc4b0e0ac01","call_id":"fc_83fb518620ae4cc4b0e0ac01","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_93d597bf53d54e3f9e2b23e6","call_id":"fc_83fb518620ae4cc4b0e0ac01","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_15c46d6903054d0f9e9ccd12","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Albertina, Leopold Museum and Kunsthistorisches Museum."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"List three museums near the Ring."}],"files":[]}	f	{"internal":true,"type":"subagent","parent_chat_id":"ae10e2c0-b336-4289-b502-dc5cb5108256","parent_message_id":"c3728031-2348-4d90-9555-0a2d779eb9fc","delegation_id":"deleg_638efb7e","mode":"foreground"}	\N	null	\N	1795595640	8ad944df-daed-467d-8a91-e0d4d06441d9	{}	\N
d7625e57-13d2-4843-a4b0-ca2cee321c5f	1636581a-57a9-49a3-abd9-7079db647896	Getting to the Prater	1795595634	1795595636	\N	f	{"id":"d7625e57-13d2-4843-a4b0-ca2cee321c5f","title":"Getting to the Prater","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"81c81420-f84f-4c3c-aeee-b0509192b78d","messages":{"5aefcf40-9b52-4a91-b328-438527397d17":{"id":"5aefcf40-9b52-4a91-b328-438527397d17","parentId":null,"childrenIds":["4d2b80db-43e7-43c2-8fa8-5f766ea110ab"],"role":"user","content":"How do I get to the Prater?","models":["mock-model"],"timestamp":1795595634,"user_id":"1636581a-57a9-49a3-abd9-7079db647896","user":{"id":"1636581a-57a9-49a3-abd9-7079db647896","name":"Bob Reader"}},"4d2b80db-43e7-43c2-8fa8-5f766ea110ab":{"id":"4d2b80db-43e7-43c2-8fa8-5f766ea110ab","parentId":"5aefcf40-9b52-4a91-b328-438527397d17","childrenIds":["c8035ec4-4eb2-41d9-a024-08c43aca7ad0"],"role":"assistant","content":"Take the U-Bahn.","done":true,"model":"mock-model","timestamp":1795595634,"meta":{"task_id":"41cd582c-8082-4179-a3d3-1e2f89373efa","response_started_at":1795595634.9648123,"response_ended_at":1795595635.422887},"user_id":"1636581a-57a9-49a3-abd9-7079db647896","output":[{"type":"function_call","id":"fc_4162e939544c466994db093e","call_id":"fc_4162e939544c466994db093e","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_10d8bb948b054c7fa0d7d4e7","call_id":"fc_4162e939544c466994db093e","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_211ad34cd04d4a27a0cecf61","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Take the U-Bahn."}]}],"usage":{"input_tokens":12,"output_tokens":7,"total_tokens":19,"prompt_tokens":12,"completion_tokens":7},"annotation":{"rating":1,"reason":"Accurate","comment":"Exactly the line I needed.","tags":["transport"]},"feedbackId":"0802895b-c15b-4591-95d1-db092918768b","followUps":["How long does it take?","Is there a night line?"],"embeds":["<p>U2 to Praterstern</p>"]},"c8035ec4-4eb2-41d9-a024-08c43aca7ad0":{"id":"c8035ec4-4eb2-41d9-a024-08c43aca7ad0","parentId":"4d2b80db-43e7-43c2-8fa8-5f766ea110ab","childrenIds":["81c81420-f84f-4c3c-aeee-b0509192b78d"],"role":"user","content":"And back?","models":["mock-model"],"timestamp":1795595635,"user_id":"1636581a-57a9-49a3-abd9-7079db647896","user":{"id":"1636581a-57a9-49a3-abd9-7079db647896","name":"Bob Reader"}},"81c81420-f84f-4c3c-aeee-b0509192b78d":{"id":"81c81420-f84f-4c3c-aeee-b0509192b78d","parentId":"c8035ec4-4eb2-41d9-a024-08c43aca7ad0","childrenIds":[],"role":"assistant","content":"","done":true,"model":"mock-model","modelIdx":null,"timestamp":1795595635,"user_id":"1636581a-57a9-49a3-abd9-7079db647896","meta":{"task_id":"2b238a93-49a7-44b7-b244-3d3038bd6c3f","response_started_at":1795595635.5749235,"response_ended_at":1795595636.0036309},"error":{"content":"the provider is down"}}}},"messages":[{"role":"user","content":"How do I get to the Prater?"}],"files":[],"tags":[],"timestamp":1795595634940}	f	{}	\N	null	\N	1795595634	81c81420-f84f-4c3c-aeee-b0509192b78d	{}	\N
af9bc9d8-ca74-46db-b7d2-7a8aa44f6629	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Castle near Vienna	1795595637	1795595637	\N	f	{"id":"af9bc9d8-ca74-46db-b7d2-7a8aa44f6629","title":"Castle near Vienna","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"6c85000b-060a-4ede-b87e-fc451b7d8a6c","messages":{"618721b6-5c8c-42ca-8d68-9ed36cac8c27":{"id":"618721b6-5c8c-42ca-8d68-9ed36cac8c27","parentId":null,"childrenIds":["6c85000b-060a-4ede-b87e-fc451b7d8a6c"],"role":"user","user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","content":"Name a castle near Vienna.","models":["mock-model"],"timestamp":1795595637,"user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"6c85000b-060a-4ede-b87e-fc451b7d8a6c":{"id":"6c85000b-060a-4ede-b87e-fc451b7d8a6c","parentId":"618721b6-5c8c-42ca-8d68-9ed36cac8c27","childrenIds":[],"role":"assistant","content":"Burg Kreuzenstein, north of Vienna.","done":true,"model":"mock-model","timestamp":1795595637,"modelIdx":0,"meta":{"task_id":"a299d60d-b266-4373-b9da-a6e6e738c471","response_started_at":1795595637.3194683,"response_ended_at":1795595637.7526093},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_7493a0b5512949e9ba980f00","call_id":"fc_7493a0b5512949e9ba980f00","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_a48c4d099fc44576b3757e9d","call_id":"fc_7493a0b5512949e9ba980f00","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_f0cc4e7e678b48ccad3e8a57","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Burg Kreuzenstein, north of Vienna."}]}],"usage":{"incomplete":true}}}},"messages":[{"id":"618721b6-5c8c-42ca-8d68-9ed36cac8c27","parentId":null,"childrenIds":["6c85000b-060a-4ede-b87e-fc451b7d8a6c"],"role":"user","user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","content":"Name a castle near Vienna.","models":["mock-model"],"timestamp":1795595637,"user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},{"id":"6c85000b-060a-4ede-b87e-fc451b7d8a6c","parentId":"618721b6-5c8c-42ca-8d68-9ed36cac8c27","childrenIds":[],"role":"assistant","content":"Burg Kreuzenstein, north of Vienna.","done":true,"model":"mock-model","timestamp":1795595637,"modelIdx":0,"meta":{"task_id":"a299d60d-b266-4373-b9da-a6e6e738c471","response_started_at":1795595637.3194683,"response_ended_at":1795595637.7526093},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_7493a0b5512949e9ba980f00","call_id":"fc_7493a0b5512949e9ba980f00","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_a48c4d099fc44576b3757e9d","call_id":"fc_7493a0b5512949e9ba980f00","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_f0cc4e7e678b48ccad3e8a57","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Burg Kreuzenstein, north of Vienna."}]}],"usage":{"incomplete":true}}],"files":[],"tags":[],"timestamp":1795595637294}	f	{}	\N	null	\N	1795595637	6c85000b-060a-4ede-b87e-fc451b7d8a6c	{}	\N
e8c5d683-8933-4b4b-b5be-a155c5719123	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Day trip	1795595637	1795595639	\N	f	{"id":"e8c5d683-8933-4b4b-b5be-a155c5719123","title":"Day trip","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"521b3df0-77a8-4347-9682-6563d1b908aa","messages":{"e92dcd22-ff76-4ae3-b06e-105f7eee5cdc":{"id":"e92dcd22-ff76-4ae3-b06e-105f7eee5cdc","parentId":null,"childrenIds":["a980c506-f90a-4381-9c56-824443eebfc1","521b3df0-77a8-4347-9682-6563d1b908aa"],"role":"user","user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","content":"Suggest a day trip from Vienna.","models":["mock-model"],"timestamp":1795595637,"user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"a980c506-f90a-4381-9c56-824443eebfc1":{"id":"a980c506-f90a-4381-9c56-824443eebfc1","parentId":"e92dcd22-ff76-4ae3-b06e-105f7eee5cdc","childrenIds":[],"role":"assistant","content":"Bratislava by boat.","done":true,"model":"mock-model","timestamp":1795595637,"modelIdx":0,"meta":{"task_id":"d1e9dbe5-af38-4427-ad3a-cc43e91e14fd","response_started_at":1795595637.8520074,"response_ended_at":1795595638.28059},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_fd3b337c8e95408c9a9bff04","call_id":"fc_fd3b337c8e95408c9a9bff04","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_4e5c52aeded14a8092536488","call_id":"fc_fd3b337c8e95408c9a9bff04","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_2088c538bda1438c9aa199bb","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Bratislava by boat."}]}],"usage":{"incomplete":true}},"521b3df0-77a8-4347-9682-6563d1b908aa":{"id":"521b3df0-77a8-4347-9682-6563d1b908aa","parentId":"e92dcd22-ff76-4ae3-b06e-105f7eee5cdc","childrenIds":[],"role":"assistant","content":"The Wachau by bike.","done":true,"model":"mock-model","modelIdx":0,"timestamp":1795595638,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","meta":{"task_id":"e6e72636-5d7a-44cf-ae95-346225501e64","response_started_at":1795595638.8350713,"response_ended_at":1795595639.2543952},"output":[{"type":"function_call","id":"fc_abd40f73d8a4485b858ca0bc","call_id":"fc_abd40f73d8a4485b858ca0bc","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_2f3e81652c1249159465f278","call_id":"fc_abd40f73d8a4485b858ca0bc","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_913c8c23533642b4957ab3c1","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The Wachau by bike."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Suggest a day trip from Vienna."}],"files":[],"tags":[],"timestamp":1795595637834}	f	{}	\N	null	\N	1795595637	521b3df0-77a8-4347-9682-6563d1b908aa	{}	\N
13d0c2da-c6ca-42e1-be99-3f11df8611a9	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Museum order	1795595639	1795595639	\N	f	{"id":"13d0c2da-c6ca-42e1-be99-3f11df8611a9","title":"Museum order","models":["mock-model","research-assistant"],"terminal_id":null,"working_directory":"","history":{"currentId":"1e788a35-3cf8-4367-b7a6-4b93de167426","messages":{"465bbde2-a457-4028-8753-381015542878":{"id":"465bbde2-a457-4028-8753-381015542878","parentId":null,"childrenIds":["1e788a35-3cf8-4367-b7a6-4b93de167426","80e1e238-4049-449d-b57f-10899f7b948e"],"role":"user","user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","content":"Which museum first?","models":["mock-model","research-assistant"],"timestamp":1795595639,"user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"1e788a35-3cf8-4367-b7a6-4b93de167426":{"id":"1e788a35-3cf8-4367-b7a6-4b93de167426","parentId":"465bbde2-a457-4028-8753-381015542878","childrenIds":[],"role":"assistant","content":"The Albertina.","done":true,"model":"mock-model","timestamp":1795595639,"modelIdx":0,"meta":{"task_id":"1bdb394e-5ccc-4955-9cfd-bc51e8ef0399","response_started_at":1795595639.3454106,"response_ended_at":1795595639.7808566},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_77e97cc524d543e9bf21739d","call_id":"fc_77e97cc524d543e9bf21739d","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_aa3ef153c2e94bdc98352731","call_id":"fc_77e97cc524d543e9bf21739d","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_1b0e05c1b9a24bbaaf81ee29","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The Albertina."}]}],"usage":{"incomplete":true}},"80e1e238-4049-449d-b57f-10899f7b948e":{"id":"80e1e238-4049-449d-b57f-10899f7b948e","parentId":"465bbde2-a457-4028-8753-381015542878","childrenIds":[],"role":"assistant","content":"The handbook says the Leopold.","done":true,"model":"research-assistant","timestamp":1795595639,"modelIdx":1,"meta":{"task_id":"310b2a18-1f2d-4337-83aa-1e4971bdf582","response_started_at":1795595639.3483715,"response_ended_at":1795595639.780631},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_c482545fc0ad474e9cf78470","call_id":"fc_c482545fc0ad474e9cf78470","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_5e14a06699f64ef1bf747199","call_id":"fc_c482545fc0ad474e9cf78470","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_3f4b0a008be34b6588eb95ac","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The handbook says the Leopold."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Which museum first?"}],"files":[],"tags":[],"timestamp":1795595639324}	f	{}	\N	null	\N	1795595639	1e788a35-3cf8-4367-b7a6-4b93de167426	{}	\N
ae10e2c0-b336-4289-b502-dc5cb5108256	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Museum day	1795595639	1795595641	\N	f	{"id":"ae10e2c0-b336-4289-b502-dc5cb5108256","title":"Museum day","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"c3728031-2348-4d90-9555-0a2d779eb9fc","messages":{"7d1aa0ac-f189-4b9d-a107-5592cf9f21d8":{"id":"7d1aa0ac-f189-4b9d-a107-5592cf9f21d8","parentId":null,"childrenIds":["c3728031-2348-4d90-9555-0a2d779eb9fc"],"role":"user","user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","content":"Plan my museum day.","models":["mock-model"],"timestamp":1795595639,"user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"c3728031-2348-4d90-9555-0a2d779eb9fc":{"id":"c3728031-2348-4d90-9555-0a2d779eb9fc","parentId":"7d1aa0ac-f189-4b9d-a107-5592cf9f21d8","childrenIds":[],"role":"assistant","content":"Start at the Albertina, then walk to the Leopold Museum.","done":true,"model":"mock-model","timestamp":1795595639,"modelIdx":0,"meta":{"task_id":"fbf42286-f1f8-4ea2-88ba-120bc935b56c","response_started_at":1795595639.8697567,"response_ended_at":1795595641.1249862},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_7bbfa97e5a2747d287d39365","call_id":"fc_7bbfa97e5a2747d287d39365","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_685ba586d3a34eeb8ebafbbb","call_id":"fc_7bbfa97e5a2747d287d39365","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"delegate_task","arguments":"{\\"task\\": \\"List three museums near the Ring.\\"}","status":"completed","started_at":1795595640.2839806,"ended_at":1795595640.7540677,"duration":0.47008743599872105,"tool_id":"builtin:delegate_task","tool_type":"builtin"},{"type":"function_call_output","id":"fco_9614ecf0a0344b7fa13f8445","call_id":"call_1","output":[{"type":"input_text","text":"Albertina, Leopold Museum and Kunsthistorisches Museum."}],"status":"completed"},{"type":"message","id":"msg_383fb51c69dc48e9a5093456","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Start at the Albertina, then walk to the Leopold Museum."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Plan my museum day."}],"files":[],"tags":[],"timestamp":1795595639853}	f	{}	\N	null	\N	1795595639	c3728031-2348-4d90-9555-0a2d779eb9fc	{}	\N
f12a4157-568d-4064-b3b9-862ad4ad9f2e	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Trains to Graz	1795595641	1795595641	\N	f	{"id":"f12a4157-568d-4064-b3b9-862ad4ad9f2e","title":"Trains to Graz","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"f9f4f144-743b-41fa-94b6-dd05713c7b98","messages":{"7e268e4a-b1c3-491d-a91b-d1f9df93ca3c":{"id":"7e268e4a-b1c3-491d-a91b-d1f9df93ca3c","parentId":null,"childrenIds":["f9f4f144-743b-41fa-94b6-dd05713c7b98"],"role":"user","user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","content":"Where do trains to Graz leave from?","models":["mock-model"],"timestamp":1795595641,"user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"f9f4f144-743b-41fa-94b6-dd05713c7b98":{"id":"f9f4f144-743b-41fa-94b6-dd05713c7b98","parentId":"7e268e4a-b1c3-491d-a91b-d1f9df93ca3c","childrenIds":[],"role":"assistant","content":"From Wien Hauptbahnhof.","done":true,"model":"mock-model","timestamp":1795595641,"modelIdx":0,"meta":{"task_id":"1b691382-8780-4397-a3f4-ca7827e59b7d","response_started_at":1795595641.330068,"response_ended_at":1795595641.7534466},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_b3579317e9d144a78fccd8bf","call_id":"fc_b3579317e9d144a78fccd8bf","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_3bf3b944395b4db88e9a1edb","call_id":"fc_b3579317e9d144a78fccd8bf","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_a65b8ccffd06414ebe7a80e1","status":"completed","role":"assistant","content":[{"type":"output_text","text":"From Wien Hauptbahnhof."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Where do trains to Graz leave from?"}],"files":[],"tags":[],"timestamp":1795595641306}	f	{}	1f5b88e7-32d5-4409-aa68-1300e3051170	null	\N	1795595641	f9f4f144-743b-41fa-94b6-dd05713c7b98	{}	\N
\.


--
-- Data for Name: chat_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_file (id, user_id, chat_id, file_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_message (id, chat_id, user_id, role, parent_id, content, output, model_id, files, sources, embeds, done, status_history, error, usage, created_at, updated_at, context_summary, meta) FROM stdin;
0d09fe46-67bd-406b-b955-4779a6a6c2ef-u1-0000-4000-8000-000000000000	0d09fe46-67bd-406b-b955-4779a6a6c2ef	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"What should I pack for Vienna?"	null	\N	[{"type":"file","id":"ccdbdb1f-d5d2-464e-b417-fcfd34542acd","name":"packing.txt","status":"uploaded"}]	null	null	t	null	null	null	1795595632	1795595632	\N	null
0d09fe46-67bd-406b-b955-4779a6a6c2ef-a1-0000-4000-8000-000000000000	0d09fe46-67bd-406b-b955-4779a6a6c2ef	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	u1-0000-4000-8000-000000000000	"Pack an umbrella."	null	mock-model	null	null	null	t	null	null	null	1795595633	1795595632	\N	null
0d09fe46-67bd-406b-b955-4779a6a6c2ef-a1b-0000-4000-8000-000000000000	0d09fe46-67bd-406b-b955-4779a6a6c2ef	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	u1-0000-4000-8000-000000000000	"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses."	null	mock-model	null	null	null	t	null	null	null	1795595634	1795595632	\N	null
0d09fe46-67bd-406b-b955-4779a6a6c2ef-u2-0000-4000-8000-000000000000	0d09fe46-67bd-406b-b955-4779a6a6c2ef	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	a1b-0000-4000-8000-000000000000	"And for the evening?"	null	\N	null	null	null	t	null	null	null	1795595635	1795595632	\N	null
0d09fe46-67bd-406b-b955-4779a6a6c2ef-a2-0000-4000-8000-000000000000	0d09fe46-67bd-406b-b955-4779a6a6c2ef	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	u2-0000-4000-8000-000000000000	"A light jacket."	null	mock-model	null	null	null	t	null	null	null	1795595636	1795595632	\N	null
a312cac5-d61d-4460-b514-d21f986c5c63-d392e665-e66e-40e7-9d3e-bd1d64891f0f	a312cac5-d61d-4460-b514-d21f986c5c63	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"What is a Schnitzel?"	null	\N	null	null	null	t	null	null	null	1795595632	1795595632	\N	null
d7625e57-13d2-4843-a4b0-ca2cee321c5f-5aefcf40-9b52-4a91-b328-438527397d17	d7625e57-13d2-4843-a4b0-ca2cee321c5f	1636581a-57a9-49a3-abd9-7079db647896	user	\N	"How do I get to the Prater?"	null	\N	null	null	null	t	null	null	null	1795595634	1795595634	\N	null
a312cac5-d61d-4460-b514-d21f986c5c63-036bbd5b-1f44-4ed7-8720-8cd91b0df331	a312cac5-d61d-4460-b514-d21f986c5c63	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	d392e665-e66e-40e7-9d3e-bd1d64891f0f	"Schnitzel is a breaded cutlet."	[{"type":"function_call","id":"fc_2a3c43aa65f64592a2b01f5c","call_id":"fc_2a3c43aa65f64592a2b01f5c","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_7cf9faf249704bc993a4453b","call_id":"fc_2a3c43aa65f64592a2b01f5c","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_1e451c15c20e4e018a312590","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Schnitzel is a breaded cutlet."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595632	1795595633	\N	{"task_id":"fcaff070-d9c0-4143-a18e-bd678508ac76","response_started_at":1795595632.7782192,"response_ended_at":1795595633.2541645}
a312cac5-d61d-4460-b514-d21f986c5c63-73ab61a0-b601-4288-b51e-425e91d1bb5b	a312cac5-d61d-4460-b514-d21f986c5c63	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	036bbd5b-1f44-4ed7-8720-8cd91b0df331	"How do I eat it?"	null	\N	null	null	null	t	null	null	null	1795595633	1795595633	\N	null
0f1f89a1-ad51-4992-9007-d27279807d50-3b7ad9c2-266a-4557-bee6-04dd1e252355	0f1f89a1-ad51-4992-9007-d27279807d50	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"What is the weather in Graz?"	null	\N	null	null	null	t	null	null	null	1795595636	1795595636	\N	null
32b8ab93-497c-4574-b6fb-7501e3236e1f-51d75adb-4ffa-4e09-8545-a4b760b5624b	32b8ab93-497c-4574-b6fb-7501e3236e1f	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	f5b9a4fd-fdd0-4bc6-8e13-2332ea4f45f5	"Behind the blue door [1]."	[{"type":"function_call","id":"fc_f467b04aaf154606b130e37c","call_id":"fc_f467b04aaf154606b130e37c","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_1dd3f616bc3f41ebb26bb08c","call_id":"fc_f467b04aaf154606b130e37c","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"query_knowledge_files","arguments":"{\\"query\\": \\"lighthouse key\\", \\"knowledge_ids\\": [\\"2e700ced-9c11-4e00-b64f-719db7f4e9e6\\"]}","status":"completed","started_at":1795595634.3292935,"ended_at":1795595634.341974,"duration":0.012680514002568088,"tool_id":"builtin:query_knowledge_files","tool_type":"builtin"},{"type":"function_call_output","id":"fco_a5074d4461fb4afe8a284c6e","call_id":"call_1","output":[{"type":"input_text","text":"[{\\"content\\":\\"The upgrade handbook says the lighthouse key hangs behind the blue door.\\",\\"source\\":\\"handbook.txt\\",\\"file_id\\":\\"8a88c64c-6825-475c-9d18-53791115fb4a\\",\\"distance\\":0.9999999403953552}]\\n\\n### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n<source id=\\"1\\" name=\\"handbook.txt\\" resource-type=\\"file\\" resource-id=\\"8a88c64c-6825-475c-9d18-53791115fb4a\\"></source>\\n</context>\\n"}],"status":"completed"},{"type":"message","id":"msg_2fb7f07c7d87469d99ab9eed","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Behind the blue door [1]."}]}]	mock-model	null	[{"source":{"id":"8a88c64c-6825-475c-9d18-53791115fb4a","name":"handbook.txt","type":"file"},"document":["The upgrade handbook says the lighthouse key hangs behind the blue door."],"metadata":[{"file_id":"8a88c64c-6825-475c-9d18-53791115fb4a","name":"handbook.txt","source":"handbook.txt"}],"distances":[0.9999999403953552]}]	null	t	null	null	{"incomplete":true}	1795595633	1795595634	\N	{"task_id":"ec260634-66a5-49a4-b03a-967f10425984","response_started_at":1795595633.8977861,"response_ended_at":1795595634.762565}
a312cac5-d61d-4460-b514-d21f986c5c63-e1f82a33-729b-4b7d-b65d-67cad33ff88d	a312cac5-d61d-4460-b514-d21f986c5c63	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	73ab61a0-b601-4288-b51e-425e91d1bb5b	"Try it with lemon."	[{"type":"message","id":"msg_6129daf4c9a044e88c05e294","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Try it with lemon."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595633	1795595633	\N	{"task_id":"566a9496-61a6-4bb0-8946-47632191bb47","response_started_at":1795595633.3850703,"response_ended_at":1795595633.8248253}
32b8ab93-497c-4574-b6fb-7501e3236e1f-f5b9a4fd-fdd0-4bc6-8e13-2332ea4f45f5	32b8ab93-497c-4574-b6fb-7501e3236e1f	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"Where does the lighthouse key hang?"	null	\N	[{"type":"collection","id":"2e700ced-9c11-4e00-b64f-719db7f4e9e6","name":"Handbook"}]	null	null	t	null	null	null	1795595633	1795595633	\N	null
d7625e57-13d2-4843-a4b0-ca2cee321c5f-c8035ec4-4eb2-41d9-a024-08c43aca7ad0	d7625e57-13d2-4843-a4b0-ca2cee321c5f	1636581a-57a9-49a3-abd9-7079db647896	user	4d2b80db-43e7-43c2-8fa8-5f766ea110ab	"And back?"	null	\N	null	null	null	t	null	null	null	1795595635	1795595635	\N	null
af9bc9d8-ca74-46db-b7d2-7a8aa44f6629-618721b6-5c8c-42ca-8d68-9ed36cac8c27	af9bc9d8-ca74-46db-b7d2-7a8aa44f6629	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"Name a castle near Vienna."	null	\N	null	null	null	t	null	null	null	1795595637	1795595637	\N	null
d7625e57-13d2-4843-a4b0-ca2cee321c5f-81c81420-f84f-4c3c-aeee-b0509192b78d	d7625e57-13d2-4843-a4b0-ca2cee321c5f	1636581a-57a9-49a3-abd9-7079db647896	assistant	c8035ec4-4eb2-41d9-a024-08c43aca7ad0	""	null	mock-model	null	null	null	t	null	{"content":"the provider is down"}	null	1795595635	1795595636	\N	{"task_id":"2b238a93-49a7-44b7-b244-3d3038bd6c3f","response_started_at":1795595635.5749235,"response_ended_at":1795595636.0036309}
d7625e57-13d2-4843-a4b0-ca2cee321c5f-4d2b80db-43e7-43c2-8fa8-5f766ea110ab	d7625e57-13d2-4843-a4b0-ca2cee321c5f	1636581a-57a9-49a3-abd9-7079db647896	assistant	5aefcf40-9b52-4a91-b328-438527397d17	"Take the U-Bahn."	[{"type":"function_call","id":"fc_4162e939544c466994db093e","call_id":"fc_4162e939544c466994db093e","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_10d8bb948b054c7fa0d7d4e7","call_id":"fc_4162e939544c466994db093e","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_211ad34cd04d4a27a0cecf61","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Take the U-Bahn."}]}]	mock-model	null	null	["<p>U2 to Praterstern</p>"]	t	null	null	{"input_tokens":12,"output_tokens":7,"total_tokens":19,"prompt_tokens":12,"completion_tokens":7}	1795595634	1795595636	\N	{"task_id":"41cd582c-8082-4179-a3d3-1e2f89373efa","response_started_at":1795595634.9648123,"response_ended_at":1795595635.422887}
af9bc9d8-ca74-46db-b7d2-7a8aa44f6629-6c85000b-060a-4ede-b87e-fc451b7d8a6c	af9bc9d8-ca74-46db-b7d2-7a8aa44f6629	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	618721b6-5c8c-42ca-8d68-9ed36cac8c27	"Burg Kreuzenstein, north of Vienna."	[{"type":"function_call","id":"fc_7493a0b5512949e9ba980f00","call_id":"fc_7493a0b5512949e9ba980f00","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_a48c4d099fc44576b3757e9d","call_id":"fc_7493a0b5512949e9ba980f00","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_f0cc4e7e678b48ccad3e8a57","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Burg Kreuzenstein, north of Vienna."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595637	1795595637	\N	{"task_id":"a299d60d-b266-4373-b9da-a6e6e738c471","response_started_at":1795595637.3194683,"response_ended_at":1795595637.7526093}
0f1f89a1-ad51-4992-9007-d27279807d50-0921fb70-ef05-434b-8327-fc7ea6b67fad	0f1f89a1-ad51-4992-9007-d27279807d50	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	3b7ad9c2-266a-4557-bee6-04dd1e252355	"It is sunny in Graz, so leave the umbrella at home."	[{"type":"function_call","id":"fc_c33573d258cc4ab3afc123f4","call_id":"fc_c33573d258cc4ab3afc123f4","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_74885fa12f604f1cb4d09cc3","call_id":"fc_c33573d258cc4ab3afc123f4","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"get_weather","arguments":"{\\"city\\": \\"Graz\\"}","status":"completed","started_at":1795595636.7800179,"ended_at":1795595636.7812085,"duration":0.0011906449944945052,"tool_id":"weather_tool"},{"type":"function_call_output","id":"fco_e5bc45b29d624c378b94ee5c","call_id":"call_1","output":[{"type":"input_text","text":"Sunny in Graz"}],"status":"completed"},{"type":"reasoning","id":"r_90ac9ca9d7d34f72b2af171f","status":"completed","start_tag":"<think>","end_tag":"</think>","attributes":{"type":"reasoning_content"},"content":[{"type":"output_text","text":"The weather tool says sunny, so no umbrella is needed."}],"summary":null,"started_at":1795595637.1908998,"ended_at":1795595637.191013,"duration":0},{"type":"message","id":"msg_aca895b6e0a64da88804fdb4","status":"completed","role":"assistant","content":[{"type":"output_text","text":"It is sunny in Graz, so leave the umbrella at home."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true,"input_tokens":42,"output_tokens":7,"total_tokens":49,"prompt_tokens":42,"completion_tokens":7}	1795595636	1795595637	\N	{"task_id":"d44b445b-1d9d-4dec-8e1a-b1ed6c10d899","response_started_at":1795595636.3402812,"response_ended_at":1795595637.1931596}
e8c5d683-8933-4b4b-b5be-a155c5719123-e92dcd22-ff76-4ae3-b06e-105f7eee5cdc	e8c5d683-8933-4b4b-b5be-a155c5719123	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"Suggest a day trip from Vienna."	null	\N	null	null	null	t	null	null	null	1795595637	1795595638	\N	null
e8c5d683-8933-4b4b-b5be-a155c5719123-521b3df0-77a8-4347-9682-6563d1b908aa	e8c5d683-8933-4b4b-b5be-a155c5719123	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	e92dcd22-ff76-4ae3-b06e-105f7eee5cdc	"The Wachau by bike."	[{"type":"function_call","id":"fc_abd40f73d8a4485b858ca0bc","call_id":"fc_abd40f73d8a4485b858ca0bc","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_2f3e81652c1249159465f278","call_id":"fc_abd40f73d8a4485b858ca0bc","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_913c8c23533642b4957ab3c1","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The Wachau by bike."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595638	1795595639	\N	{"task_id":"e6e72636-5d7a-44cf-ae95-346225501e64","response_started_at":1795595638.8350713,"response_ended_at":1795595639.2543952}
13d0c2da-c6ca-42e1-be99-3f11df8611a9-465bbde2-a457-4028-8753-381015542878	13d0c2da-c6ca-42e1-be99-3f11df8611a9	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"Which museum first?"	null	\N	null	null	null	t	null	null	null	1795595639	1795595639	\N	null
13d0c2da-c6ca-42e1-be99-3f11df8611a9-80e1e238-4049-449d-b57f-10899f7b948e	13d0c2da-c6ca-42e1-be99-3f11df8611a9	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	465bbde2-a457-4028-8753-381015542878	"The handbook says the Leopold."	[{"type":"function_call","id":"fc_c482545fc0ad474e9cf78470","call_id":"fc_c482545fc0ad474e9cf78470","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_5e14a06699f64ef1bf747199","call_id":"fc_c482545fc0ad474e9cf78470","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_3f4b0a008be34b6588eb95ac","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The handbook says the Leopold."}]}]	research-assistant	null	null	null	t	null	null	{"incomplete":true}	1795595639	1795595639	\N	{"task_id":"310b2a18-1f2d-4337-83aa-1e4971bdf582","response_started_at":1795595639.3483715,"response_ended_at":1795595639.780631}
ae10e2c0-b336-4289-b502-dc5cb5108256-7d1aa0ac-f189-4b9d-a107-5592cf9f21d8	ae10e2c0-b336-4289-b502-dc5cb5108256	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"Plan my museum day."	null	\N	null	null	null	t	null	null	null	1795595639	1795595639	\N	null
e8c5d683-8933-4b4b-b5be-a155c5719123-a980c506-f90a-4381-9c56-824443eebfc1	e8c5d683-8933-4b4b-b5be-a155c5719123	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	e92dcd22-ff76-4ae3-b06e-105f7eee5cdc	"Bratislava by boat."	[{"type":"function_call","id":"fc_fd3b337c8e95408c9a9bff04","call_id":"fc_fd3b337c8e95408c9a9bff04","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_4e5c52aeded14a8092536488","call_id":"fc_fd3b337c8e95408c9a9bff04","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_2088c538bda1438c9aa199bb","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Bratislava by boat."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595637	1795595639	\N	{"task_id":"d1e9dbe5-af38-4427-ad3a-cc43e91e14fd","response_started_at":1795595637.8520074,"response_ended_at":1795595638.28059}
ae10e2c0-b336-4289-b502-dc5cb5108256-c3728031-2348-4d90-9555-0a2d779eb9fc	ae10e2c0-b336-4289-b502-dc5cb5108256	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	7d1aa0ac-f189-4b9d-a107-5592cf9f21d8	"Start at the Albertina, then walk to the Leopold Museum."	[{"type":"function_call","id":"fc_7bbfa97e5a2747d287d39365","call_id":"fc_7bbfa97e5a2747d287d39365","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_685ba586d3a34eeb8ebafbbb","call_id":"fc_7bbfa97e5a2747d287d39365","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"delegate_task","arguments":"{\\"task\\": \\"List three museums near the Ring.\\"}","status":"completed","started_at":1795595640.2839806,"ended_at":1795595640.7540677,"duration":0.47008743599872105,"tool_id":"builtin:delegate_task","tool_type":"builtin"},{"type":"function_call_output","id":"fco_9614ecf0a0344b7fa13f8445","call_id":"call_1","output":[{"type":"input_text","text":"Albertina, Leopold Museum and Kunsthistorisches Museum."}],"status":"completed"},{"type":"message","id":"msg_383fb51c69dc48e9a5093456","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Start at the Albertina, then walk to the Leopold Museum."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595639	1795595641	\N	{"task_id":"fbf42286-f1f8-4ea2-88ba-120bc935b56c","response_started_at":1795595639.8697567,"response_ended_at":1795595641.1249862}
f12a4157-568d-4064-b3b9-862ad4ad9f2e-7e268e4a-b1c3-491d-a91b-d1f9df93ca3c	f12a4157-568d-4064-b3b9-862ad4ad9f2e	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"Where do trains to Graz leave from?"	null	\N	null	null	null	t	null	null	null	1795595641	1795595641	\N	null
13d0c2da-c6ca-42e1-be99-3f11df8611a9-1e788a35-3cf8-4367-b7a6-4b93de167426	13d0c2da-c6ca-42e1-be99-3f11df8611a9	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	465bbde2-a457-4028-8753-381015542878	"The Albertina."	[{"type":"function_call","id":"fc_77e97cc524d543e9bf21739d","call_id":"fc_77e97cc524d543e9bf21739d","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_aa3ef153c2e94bdc98352731","call_id":"fc_77e97cc524d543e9bf21739d","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_1b0e05c1b9a24bbaaf81ee29","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The Albertina."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595639	1795595639	\N	{"task_id":"1bdb394e-5ccc-4955-9cfd-bc51e8ef0399","response_started_at":1795595639.3454106,"response_ended_at":1795595639.7808566}
8faa427a-c740-422a-b204-b49e0b8ff2f5-d0844676-ea97-4a49-bc2c-cb78dac5e77d	8faa427a-c740-422a-b204-b49e0b8ff2f5	9e5a97c6-283b-4584-a48b-35f1b16fe74f	user	\N	"List three museums near the Ring."	null	\N	null	null	null	t	null	null	null	1795595640	1795595640	\N	null
8faa427a-c740-422a-b204-b49e0b8ff2f5-8ad944df-daed-467d-8a91-e0d4d06441d9	8faa427a-c740-422a-b204-b49e0b8ff2f5	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	d0844676-ea97-4a49-bc2c-cb78dac5e77d	"Albertina, Leopold Museum and Kunsthistorisches Museum."	[{"type":"function_call","id":"fc_83fb518620ae4cc4b0e0ac01","call_id":"fc_83fb518620ae4cc4b0e0ac01","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_93d597bf53d54e3f9e2b23e6","call_id":"fc_83fb518620ae4cc4b0e0ac01","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_15c46d6903054d0f9e9ccd12","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Albertina, Leopold Museum and Kunsthistorisches Museum."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595640	1795595640	\N	{"task_id":"9c4ec77e-b68a-4e4f-9fe0-e0ff0fe4fda6","response_started_at":1795595640.3195531,"response_ended_at":1795595640.7406678}
f12a4157-568d-4064-b3b9-862ad4ad9f2e-f9f4f144-743b-41fa-94b6-dd05713c7b98	f12a4157-568d-4064-b3b9-862ad4ad9f2e	9e5a97c6-283b-4584-a48b-35f1b16fe74f	assistant	7e268e4a-b1c3-491d-a91b-d1f9df93ca3c	"From Wien Hauptbahnhof."	[{"type":"function_call","id":"fc_b3579317e9d144a78fccd8bf","call_id":"fc_b3579317e9d144a78fccd8bf","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_3bf3b944395b4db88e9a1edb","call_id":"fc_b3579317e9d144a78fccd8bf","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_a65b8ccffd06414ebe7a80e1","status":"completed","role":"assistant","content":[{"type":"output_text","text":"From Wien Hauptbahnhof."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795595641	1795595641	\N	{"task_id":"1b691382-8780-4397-a3f4-ca7827e59b7d","response_started_at":1795595641.330068,"response_ended_at":1795595641.7534466}
\.


--
-- Data for Name: chat_view_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_view_state (user_id, chat_id, state, updated_at) FROM stdin;
\.


--
-- Data for Name: chatidtag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chatidtag (id, tag_name, chat_id, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment (id, user_id, resource_type, resource_id, parent_id, reply_to_id, content, target_type, target_id, meta, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: comment_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_reaction (id, user_id, comment_id, name, created_at) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config (key, value, updated_at) FROM stdin;
ollama.enable	false	1795595629
ollama.base_urls	["http://localhost:11434"]	1795595629
ollama.api_configs	{}	1795595629
openai.enable	true	1795595629
openai.api_keys	["sk-mock"]	1795595629
openai.api_base_urls	["http://127.0.0.1:44515/v1"]	1795595629
openai.api_configs	{}	1795595629
models.base_models_cache	false	1795595629
tool_server.connections	[]	1795595629
terminal_server.connections	[]	1795595629
code_execution.enable	true	1795595629
code_execution.engine	"pyodide"	1795595629
code_execution.jupyter.url	""	1795595629
code_execution.jupyter.auth	""	1795595629
code_execution.jupyter.auth_token	""	1795595629
code_execution.jupyter.auth_password	""	1795595629
code_execution.jupyter.timeout	60	1795595629
code_interpreter.enable	true	1795595629
memories.background_review.enable	false	1795595629
memories.review_interval_turns	10	1795595629
memories.user_char_limit	2000	1795595629
memories.context_char_limit	2000	1795595629
code_interpreter.engine	"pyodide"	1795595629
code_interpreter.prompt_template	""	1795595629
code_interpreter.jupyter.url	""	1795595629
code_interpreter.jupyter.auth	""	1795595629
code_interpreter.jupyter.auth_token	""	1795595629
code_interpreter.jupyter.auth_password	""	1795595629
code_interpreter.jupyter.timeout	60	1795595629
google_drive.enable	false	1795595629
google_drive.client_id	""	1795595629
google_drive.api_key	""	1795595629
onedrive.enable	false	1795595629
onedrive.sharepoint_url	""	1795595629
onedrive.sharepoint_tenant_id	""	1795595629
rag.content_extraction_engine	""	1795595629
rag.content_extraction.supported_media_mime_types	null	1795595629
rag.datalab_marker_api_key	""	1795595629
rag.datalab_marker_api_base_url	""	1795595629
rag.datalab_marker_additional_config	""	1795595629
rag.datalab_marker_use_llm	false	1795595629
rag.datalab_marker_skip_cache	false	1795595629
rag.datalab_marker_force_ocr	false	1795595629
rag.datalab_marker_paginate	false	1795595629
rag.datalab_marker_strip_existing_ocr	false	1795595629
rag.datalab_marker_disable_image_extraction	false	1795595629
rag.datalab_marker_format_lines	false	1795595629
rag.datalab_marker_output_format	"markdown"	1795595629
rag.mineru_api_mode	"local"	1795595629
rag.mineru_api_url	"http://localhost:8000"	1795595629
rag.mineru_api_timeout	"300"	1795595629
rag.mineru_api_key	""	1795595629
rag.mineru_params	{}	1795595629
rag.mineru_file_extensions	["pdf"]	1795595629
rag.external_document_loader_url	""	1795595629
rag.external_document_loader_api_key	""	1795595629
rag.external_document_loader_headers	{}	1795595629
rag.tika_server_url	"http://tika:9998"	1795595629
rag.tika_server_version	"3"	1795595629
rag.docling_server_url	"http://docling:5001"	1795595629
rag.docling_api_key	""	1795595629
rag.docling_params	{}	1795595629
rag.document_intelligence_endpoint	""	1795595629
rag.document_intelligence_key	""	1795595629
rag.document_intelligence_model	"prebuilt-layout"	1795595629
rag.mistral_ocr_api_base_url	"https://api.mistral.ai/v1"	1795595629
rag.mistral_ocr_api_key	""	1795595629
rag.mistral_ocr_use_base64	false	1795595629
rag.mistral_ocr_params	{}	1795595629
rag.paddleocr_vl_base_url	"http://localhost:8080"	1795595629
rag.paddleocr_vl_token	""	1795595629
rag.bypass_embedding_and_retrieval	false	1795595629
rag.top_k	10	1795595629
rag.top_k_reranker	10	1795595629
rag.relevance_threshold	0.0	1795595629
rag.hybrid_bm25_weight	0.5	1795595629
rag.enable_hybrid_search	false	1795595629
rag.enable_hybrid_search_enriched_texts	false	1795595629
rag.full_context	false	1795595629
rag.full_context_char_threshold	50000	1795595629
rag.file.max_count	null	1795595629
knowledge.max_upload_count	null	1795595629
knowledge.max_file_count	null	1795595629
knowledge.max_file_size	null	1795595629
rag.file.max_size	null	1795595629
file.image_compression_width	null	1795595629
file.image_compression_height	null	1795595629
rag.file.allowed_extensions	[]	1795595629
rag.embedding_engine	"openai"	1795595629
rag.pdf_extract_images	false	1795595629
rag.pdf_loader_mode	"page"	1795595629
rag.embedding_model	"sentence-transformers/all-MiniLM-L6-v2"	1795595629
rag.tokenizer_model	""	1795595629
rag.embedding_batch_size	1	1795595629
rag.embedding_query_prefix	null	1795595629
rag.embedding_content_prefix	null	1795595629
rag.enable_async_embedding	true	1795595629
rag.embedding_concurrent_requests	0	1795595629
rag.reranking_engine	""	1795595629
rag.reranking_model	""	1795595629
rag.reranking_batch_size	32	1795595629
rag.external_reranker_url	""	1795595629
rag.external_reranker_api_key	""	1795595629
rag.external_reranker_timeout	""	1795595629
rag.text_splitter	""	1795595629
rag.enable_markdown_header_text_splitter	true	1795595629
rag.tiktoken_encoding_name	"cl100k_base"	1795595629
rag.chunk_size	1024	1795595629
rag.chunk_min_size_target	0	1795595629
rag.chunk_overlap	100	1795595629
rag.template	"### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n{{CONTEXT}}\\n</context>\\n"	1795595629
rag.openai.api_base_url	"http://127.0.0.1:44515/v1"	1795595629
rag.openai.api_key	"sk-mock"	1795595629
rag.azure_openai.base_url	""	1795595629
rag.azure_openai.api_key	""	1795595629
rag.azure_openai.api_version	""	1795595629
rag.ollama.base_url	"http://localhost:11434"	1795595629
rag.ollama.api_key	""	1795595629
rag.youtube_loader_language	["en"]	1795595629
rag.youtube_loader_proxy_url	""	1795595629
web.search.enable	false	1795595629
web.search.confirmation.enable	false	1795595629
web.search.confirmation.content	"Your query will be sent to the configured web search provider."	1795595629
web.search.engine	""	1795595629
web.search.bypass_embedding_and_retrieval	false	1795595629
web.search.bypass_web_loader	false	1795595629
web.search.result_count	3	1795595629
web.search.domain.filter_list	[]	1795595629
web.search.concurrent_requests	0	1795595629
web.fetch.max_content_length	null	1795595629
web.loader.engine	""	1795595629
web.loader.concurrent_requests	10	1795595629
web.loader.timeout	""	1795595629
web.loader.ssl_verification	true	1795595629
web.search.trust_env	true	1795595629
web.search.ollama_cloud_api_key	""	1795595629
web.search.searxng_query_url	""	1795595629
web.search.openserp_base_url	"http://localhost:7000"	1795595629
web.search.searxng_language	"all"	1795595629
web.search.yacy_query_url	""	1795595629
web.search.yacy_username	""	1795595629
web.search.yacy_password	""	1795595629
web.search.google_pse_api_key	""	1795595629
web.search.google_pse_engine_id	""	1795595629
web.search.brave_search_api_key	""	1795595629
web.search.brave_search_context_tokens	8192	1795595629
web.search.kagi_search_api_key	""	1795595629
web.search.mojeek_search_api_key	""	1795595629
web.search.bocha_search_api_key	""	1795595629
web.search.serpstack_api_key	""	1795595629
web.search.serpstack_https	true	1795595629
web.search.serper_api_key	""	1795595629
web.search.serply_api_key	""	1795595629
web.search.serphouse_api_key	""	1795595629
web.search.serphouse_domain	"google.com"	1795595629
web.search.ddgs_backend	"auto"	1795595629
web.search.jina_api_key	""	1795595629
web.search.jina_api_base_url	""	1795595629
web.search.searchapi_api_key	""	1795595629
web.search.searchapi_engine	""	1795595629
web.search.serpapi_api_key	""	1795595629
web.search.serpapi_engine	""	1795595629
web.search.bing_search_v7_endpoint	"https://api.bing.microsoft.com/v7.0/search"	1795595629
web.search.bing_search_v7_subscription_key	""	1795595629
web.search.azure_ai_search_api_key	""	1795595629
web.search.azure_ai_search_endpoint	""	1795595629
web.search.azure_ai_search_index_name	""	1795595629
web.search.exa_api_key	""	1795595629
web.search.exa_max_content_length	null	1795595629
web.search.perplexity_api_key	""	1795595629
web.search.perplexity_model	"sonar"	1795595629
web.search.perplexity_search_context_usage	"medium"	1795595629
web.search.perplexity_search_api_url	"https://api.perplexity.ai/search"	1795595629
web.search.microsoft_web_iq_api_base_url	"https://api.microsoft.ai/v3"	1795595629
web.search.microsoft_web_iq_api_key	""	1795595629
web.search.microsoft_web_iq_language	"en"	1795595629
web.search.sougou_api_sid	""	1795595629
web.search.sougou_api_sk	""	1795595629
web.search.tavily_api_key	""	1795595629
web.search.tavily_extract_depth	"basic"	1795595629
web.search.tavily_search_depth	"basic"	1795595629
web.search.staan_api_key	""	1795595629
web.search.staan_market	"en-us"	1795595629
web.search.staan_max_snippets	0	1795595629
web.loader.playwright_ws_url	""	1795595629
web.loader.playwright_timeout	10000	1795595629
web.loader.firecrawl_api_key	""	1795595629
web.loader.firecrawl_api_url	"https://api.firecrawl.dev"	1795595629
web.loader.firecrawl_timeout	""	1795595629
web.search.external_web_search_url	""	1795595629
web.search.external_web_search_api_key	""	1795595629
web.loader.external_web_loader_url	""	1795595629
web.loader.external_web_loader_api_key	""	1795595629
web.search.yandex_web_search_url	""	1795595629
web.search.yandex_web_search_api_key	""	1795595629
web.search.yandex_web_search_config	""	1795595629
web.search.youcom_api_key	""	1795595629
web.search.linkup_api_key	""	1795595629
web.search.linkup_search_params	{}	1795595629
image_generation.enable	false	1795595629
image_generation.engine	"openai"	1795595629
image_generation.model	""	1795595629
image_generation.size	"512x512"	1795595629
image_generation.steps	50	1795595629
image_generation.prompt.enable	true	1795595629
image_generation.default_model	""	1795595629
image_generation.automatic1111.base_url	""	1795595629
image_generation.automatic1111.api_auth	""	1795595629
image_generation.automatic1111.api_params	{}	1795595629
image_generation.comfyui.base_url	""	1795595629
image_generation.comfyui.api_key	""	1795595629
image_generation.comfyui.workflow	"\\n{\\n  \\"3\\": {\\n    \\"inputs\\": {\\n      \\"seed\\": 0,\\n      \\"steps\\": 20,\\n      \\"cfg\\": 8,\\n      \\"sampler_name\\": \\"euler\\",\\n      \\"scheduler\\": \\"normal\\",\\n      \\"denoise\\": 1,\\n      \\"model\\": [\\n        \\"4\\",\\n        0\\n      ],\\n      \\"positive\\": [\\n        \\"6\\",\\n        0\\n      ],\\n      \\"negative\\": [\\n        \\"7\\",\\n        0\\n      ],\\n      \\"latent_image\\": [\\n        \\"5\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"KSampler\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"KSampler\\"\\n    }\\n  },\\n  \\"4\\": {\\n    \\"inputs\\": {\\n      \\"ckpt_name\\": \\"model.safetensors\\"\\n    },\\n    \\"class_type\\": \\"CheckpointLoaderSimple\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Load Checkpoint\\"\\n    }\\n  },\\n  \\"5\\": {\\n    \\"inputs\\": {\\n      \\"width\\": 512,\\n      \\"height\\": 512,\\n      \\"batch_size\\": 1\\n    },\\n    \\"class_type\\": \\"EmptyLatentImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Empty Latent Image\\"\\n    }\\n  },\\n  \\"6\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"Prompt\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"7\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"8\\": {\\n    \\"inputs\\": {\\n      \\"samples\\": [\\n        \\"3\\",\\n        0\\n      ],\\n      \\"vae\\": [\\n        \\"4\\",\\n        2\\n      ]\\n    },\\n    \\"class_type\\": \\"VAEDecode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"VAE Decode\\"\\n    }\\n  },\\n  \\"9\\": {\\n    \\"inputs\\": {\\n      \\"filename_prefix\\": \\"ComfyUI\\",\\n      \\"images\\": [\\n        \\"8\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"SaveImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Save Image\\"\\n    }\\n  }\\n}\\n"	1795595629
image_generation.comfyui.nodes	[]	1795595629
image_generation.openai.api_base_url	"https://api.openai.com/v1"	1795595629
image_generation.openai.api_version	""	1795595629
image_generation.openai.api_key	""	1795595629
image_generation.openai.params	{}	1795595629
image_generation.gemini.api_base_url	""	1795595629
image_generation.gemini.api_key	""	1795595629
image_generation.gemini.endpoint_method	""	1795595629
images.edit.enable	false	1795595629
images.edit.engine	"openai"	1795595629
images.edit.model	""	1795595629
images.edit.default_model	""	1795595629
video_generation.enable	false	1795595629
video_generation.default_model	""	1795595629
images.edit.size	""	1795595629
images.edit.openai.api_base_url	"https://api.openai.com/v1"	1795595629
images.edit.openai.api_version	""	1795595629
images.edit.openai.api_key	""	1795595629
images.edit.gemini.api_base_url	""	1795595629
images.edit.gemini.api_key	""	1795595629
images.edit.comfyui.base_url	""	1795595629
images.edit.comfyui.api_key	""	1795595629
images.edit.comfyui.workflow	""	1795595629
images.edit.comfyui.nodes	[]	1795595629
audio.stt.whisper_model	"base"	1795595629
audio.stt.deepgram.api_key	""	1795595629
audio.stt.openai.api_base_url	"https://api.openai.com/v1"	1795595629
audio.stt.openai.api_key	""	1795595629
audio.stt.openai.api_request_format	"multipart"	1795595629
audio.stt.engine	""	1795595629
audio.stt.model	""	1795595629
audio.stt.supported_content_types	[]	1795595629
audio.stt.allowed_extensions	["mp3","wav","m4a","webm","ogg","flac","mp4","mpga","mpeg"]	1795595629
audio.stt.azure.api_key	""	1795595629
audio.stt.azure.region	""	1795595629
audio.stt.azure.locales	""	1795595629
audio.stt.azure.base_url	""	1795595629
audio.stt.azure.max_speakers	""	1795595629
audio.stt.mistral.api_key	""	1795595629
audio.stt.mistral.api_base_url	"https://api.mistral.ai/v1"	1795595629
audio.stt.mistral.use_chat_completions	false	1795595629
audio.tts.openai.api_base_url	"https://api.openai.com/v1"	1795595629
audio.tts.openai.api_key	""	1795595629
audio.tts.openai.params	{}	1795595629
audio.tts.api_key	""	1795595629
audio.realtime.enabled	false	1795595629
audio.realtime.provider	"openai"	1795595629
audio.realtime.auth_type	"api_key"	1795595629
audio.realtime.openai.api_base_url	"https://api.openai.com/v1"	1795595629
audio.realtime.openai.api_key	""	1795595629
audio.realtime.model	"gpt-realtime-2.1-mini"	1795595629
audio.realtime.voice	"marin"	1795595629
audio.realtime.transcription_model	"gpt-transcribe"	1795595629
audio.realtime.input_params	null	1795595629
audio.realtime.prompt_template	null	1795595629
audio.tts.engine	""	1795595629
audio.tts.model	"tts-1"	1795595629
audio.tts.voice	"alloy"	1795595629
audio.tts.realtime.prompt_template	null	1795595629
audio.tts.split_on	"punctuation"	1795595629
audio.tts.azure.speech_region	""	1795595629
audio.tts.azure.speech_base_url	""	1795595629
audio.tts.azure.speech_output_format	"audio-24khz-160kbitrate-mono-mp3"	1795595629
audio.tts.mistral.api_key	""	1795595629
audio.tts.mistral.api_base_url	"https://api.mistral.ai/v1"	1795595629
ui.enable_password_change_form	true	1795595629
ui.default_locale	""	1795595629
ui.default_models	null	1795595629
ui.default_pinned_models	null	1795595629
ui.visibility	{}	1795595629
ui.prompt_suggestions	null	1795595629
ui.prompt_suggestions_i18n	{}	1795595629
ui.model_order_list	[]	1795595629
models.default_metadata	{}	1795595629
models.default_params	{}	1795595629
subagents.enable	true	1795595629
subagents.background_enabled	false	1795595629
subagents.max_concurrent	null	1795595629
subagents.max_async	null	1795595629
subagents.max_iterations	null	1795595629
subagents.max_output	null	1795595629
subagents.system_prompt	""	1795595629
automations.auth_token_expires_in	"1h"	1795595629
evaluation.arena.enable	false	1795595629
evaluation.arena.models	[]	1795595629
webhook_url	""	1795595629
task.model.default	""	1795595629
task.model.external	""	1795595629
task.model.params	{}	1795595629
chat.context_compaction.model	""	1795595629
chat.context_compaction.enable	false	1795595629
chat.context_compaction.token_threshold	80000	1795595629
chat.context_compaction.token_cap	null	1795595629
chat.context_compaction.retention_percentage	40	1795595629
chat.context_compaction.prompt_template	""	1795595629
chat.visualizations.prompt_template	""	1795595629
chat.tool_permissions.enable	false	1795595629
chat.tool_call_labels.enable	false	1795595629
chat.tool_permissions.auto.enable	false	1795595629
chat.tool_permissions.auto.engine	""	1795595629
chat.tool_permissions.auto.prompt	""	1795595629
chat.tool_permissions.auto.decisions.api_base_url	"https://api.openai.com/v1"	1795595629
chat.tool_permissions.auto.decisions.api_key	""	1795595629
chat.tool_permissions.auto.decisions.model	"gpt-6-luna"	1795595629
chat.tool_permissions.auto.decisions.threshold	0.5	1795595629
chat.tool_search.enable	false	1795595629
chat.tool_search.engine	"bm25"	1795595629
chat.tool_search.decisions.api_base_url	"https://api.openai.com/v1"	1795595629
chat.tool_search.decisions.api_key	""	1795595629
chat.tool_search.decisions.model	"gpt-6-luna"	1795595629
chat.tool_search.decisions.threshold	0.5	1795595629
chat.tool_search.decisions.prompt	""	1795595629
chat.tool_search.defer_threshold	400	1795595629
chat.tool_search.always_loaded	[]	1795595629
chat.tool_search.defer_builtin_tools	true	1795595629
task.title.prompt_template	""	1795595629
task.tags.prompt_template	""	1795595629
task.image.prompt_template	""	1795595629
task.follow_up.prompt_template	""	1795595629
task.follow_up.enable	false	1795595629
task.tags.enable	false	1795595629
task.title.enable	false	1795595629
task.query.search.enable	true	1795595629
task.query.retrieval.enable	true	1795595629
task.query.prompt_template	""	1795595629
task.autocomplete.enable	false	1795595629
task.autocomplete.input_max_length	-1	1795595629
task.autocomplete.prompt_template	""	1795595629
task.voice.prompt_template	""	1795595629
task.voice.prompt.enable	true	1795595629
task.tools.prompt_template	""	1795595629
apps.enable	false	1795595630
ui.i18n	{}	1795595630
user.permissions	{"workspace":{"models":false,"knowledge":false,"prompts":true,"tools":false,"skills":true,"models_import":false,"models_export":false,"models_hidden":false,"prompts_import":false,"prompts_export":false,"tools_import":false,"tools_export":false,"skills_import":false,"skills_export":false},"sharing":{"models":false,"public_models":false,"knowledge":false,"public_knowledge":false,"prompts":false,"public_prompts":false,"tools":false,"public_tools":false,"skills":true,"public_skills":false,"notes":true,"public_notes":false,"folders":false,"public_chats":false,"open_chats":false,"public_calendars":false},"access_grants":{"allow_users":true,"allow_groups":true},"chat":{"controls":true,"valves":true,"system_prompt":true,"params":true,"file_upload":true,"web_upload":true,"delete":false,"delete_message":true,"continue_response":true,"regenerate_response":true,"rate_response":true,"edit":true,"share":true,"export":true,"import":true,"stt":true,"tts":true,"call":true,"multiple_models":true,"temporary":true,"side_chat":false,"temporary_enforced":false},"features":{"api_keys":false,"notes":true,"channels":true,"encrypted_channels":false,"folders":true,"web_search":true,"image_generation":true,"video_generation":false,"code_interpreter":true,"memories":true,"subagents":true,"automations":false,"calendar":true,"webhooks":false},"settings":{"interface":true}}	1795595630
ui.banners	[{"i18n":null,"id":"upgrade-banner","type":"info","title":"Maintenance","content":"Maintenance on Sunday","dismissible":true,"timestamp":1700000000}]	1795595630
auth.session_expiry	"90d"	1795595629
ldap.enable	false	1795595629
ldap.server.label	"LDAP Server"	1795595629
ldap.server.host	"localhost"	1795595629
ldap.server.port	389	1795595629
ldap.server.attribute_for_mail	"mail"	1795595629
ldap.server.default_email_domain	""	1795595629
ldap.server.attribute_for_username	"uid"	1795595629
ldap.server.app_dn	""	1795595629
ldap.server.app_password	""	1795595629
ldap.server.users_dn	""	1795595629
ldap.server.search_filter	""	1795595629
ldap.server.use_tls	true	1795595629
ldap.server.ca_cert_file	""	1795595629
ldap.server.validate_cert	true	1795595629
ldap.server.ciphers	"ALL"	1795595629
ldap.group.enable_management	false	1795595629
ldap.group.enable_creation	false	1795595629
ldap.server.attribute_for_groups	"memberOf"	1795595629
images.connections	[]	1795595629
ui.enable_signup	false	1795595630
auth.admin.email	null	1795595630
auth.admin.show	true	1795595630
auth.api_key.allowed_endpoints	""	1795595630
auth.api_key.endpoint_restrictions	false	1795595630
auth.enable_api_keys	false	1795595630
auth.jwt_expiry	"4w"	1795595630
auth.mfa.allow_oauth_bypass	false	1795595630
auth.mfa.allow_trusted_header_bypass	false	1795595630
auth.mfa.enable	false	1795595630
automations.enable	true	1795595630
automations.max_count	""	1795595630
automations.min_interval	""	1795595630
calendar.enable	true	1795595630
channels.enable	true	1795595630
channels.encryption.enable	false	1795595630
channels.model_response_mode	"thread"	1795595630
chats.view_max_chars	null	1795595630
comments.enable	false	1795595630
folders.enable	true	1795595630
folders.max_file_count	""	1795595630
memories.enable	true	1795595630
memories.system_context.enable	true	1795595630
notes.enable	true	1795595630
notifications.enable	true	1795595630
skills.content_max_chars	null	1795595630
skills.lazy_loading.enable	false	1795595630
skills.preview_max_chars	null	1795595630
ui.default_group_id	""	1795595630
ui.default_interface_settings	{}	1795595630
ui.default_user_role	"user"	1795595630
ui.enable_community_sharing	false	1795595630
ui.enable_login_form	true	1795595630
ui.enable_message_rating	true	1795595630
ui.enable_user_webhooks	false	1795595630
ui.pending_user_overlay_content	""	1795595630
ui.pending_user_overlay_title	""	1795595630
ui.watermark	""	1795595630
users.enable_status	true	1795595630
webui.url	"https://chat.example.com"	1795595630
\.


--
-- Data for Name: config_old; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_old (id, data, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (collection_name, name, title, filename, content, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, user_id, version, type, data, meta, snapshot, created_at, updated_at) FROM stdin;
25b5e6bb-1f24-41d4-bc07-1c7ed2e22a89	9e5a97c6-283b-4584-a48b-35f1b16fe74f	0	rating	{"rating":1,"model_id":"mock-model","sibling_model_ids":null,"reason":"Accurate","comment":null}	{"chat_id":"a312cac5-d61d-4460-b514-d21f986c5c63","message_id":"036bbd5b-1f44-4ed7-8720-8cd91b0df331"}	{"chat":{}}	1795595634	1795595634
0802895b-c15b-4591-95d1-db092918768b	1636581a-57a9-49a3-abd9-7079db647896	0	rating	{"rating":1,"model_id":"mock-model","sibling_model_ids":null,"reason":"Accurate","comment":null}	{"chat_id":"d7625e57-13d2-4843-a4b0-ca2cee321c5f","message_id":"4d2b80db-43e7-43c2-8fa8-5f766ea110ab"}	{"chat":{}}	1795595636	1795595636
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, user_id, filename, meta, created_at, hash, data, updated_at, path) FROM stdin;
8a88c64c-6825-475c-9d18-53791115fb4a	41fa65e2-730a-4451-be4a-29363294205f	handbook.txt	{"name":"handbook.txt","content_type":"text/plain","size":72,"file_hash":"51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb","data":{},"collection_name":"2e700ced-9c11-4e00-b64f-719db7f4e9e6"}	1795595632	51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb	{"status":"completed","content":"The upgrade handbook says the lighthouse key hangs behind the blue door.","error":null}	1795595632	/home/tmp/seed-v0.13.4-zx92pbk7/data/uploads/8a88c64c-6825-475c-9d18-53791115fb4a_handbook.txt
ccdbdb1f-d5d2-464e-b417-fcfd34542acd	9e5a97c6-283b-4584-a48b-35f1b16fe74f	packing.txt	{"name":"packing.txt","content_type":"text/plain","size":59,"file_hash":"85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a","data":{},"collection_name":"file-ccdbdb1f-d5d2-464e-b417-fcfd34542acd"}	1795595632	85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a	{"status":"completed","content":"Packing list: umbrella, passport, a very old map of Vienna.","error":null}	1795595632	/home/tmp/seed-v0.13.4-zx92pbk7/data/uploads/ccdbdb1f-d5d2-464e-b417-fcfd34542acd_packing.txt
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder (id, parent_id, user_id, name, items, meta, is_expanded, created_at, updated_at, data) FROM stdin;
1f5b88e7-32d5-4409-aa68-1300e3051170	\N	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Trips	null	null	f	1795595632	1795595632	null
2dcd5fd8-dcbb-4100-bf78-2aef31256c9c	1f5b88e7-32d5-4409-aa68-1300e3051170	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Vienna	null	null	f	1795595632	1795595632	null
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function (id, user_id, name, type, content, meta, valves, is_active, is_global, updated_at, created_at, version_id) FROM stdin;
shout_filter	41fa65e2-730a-4451-be4a-29363294205f	Shout filter	filter	"""\ntitle: Shout filter\n"""\n\nfrom pydantic import BaseModel\n\n\nclass Filter:\n    class Valves(BaseModel):\n        suffix: str = "!"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def inlet(self, body: dict) -> dict:\n        return body\n	{"description":"Adds emphasis","manifest":{"title":"Shout filter"},"toggle":false}	{"suffix":"!!!"}	t	t	1795595630	1795595630	48652246-425a-4b91-9888-ce207f6c0b47
\.


--
-- Data for Name: function_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function_history (id, function_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
48652246-425a-4b91-9888-ce207f6c0b47	shout_filter	\N	{"name":"Shout filter","content":"\\"\\"\\"\\ntitle: Shout filter\\n\\"\\"\\"\\n\\nfrom pydantic import BaseModel\\n\\n\\nclass Filter:\\n    class Valves(BaseModel):\\n        suffix: str = \\"!\\"\\n\\n    def __init__(self):\\n        self.valves = self.Valves()\\n\\n    def inlet(self, body: dict) -> dict:\\n        return body\\n","meta":{"description":"Adds emphasis"}}	41fa65e2-730a-4451-be4a-29363294205f	\N	1795595630
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."group" (id, user_id, name, description, data, meta, permissions, created_at, updated_at, parent_group_id) FROM stdin;
1a9e8b27-82cc-4624-942c-1f93b14acc08	41fa65e2-730a-4451-be4a-29363294205f	Research	People who read the handbook	{"config":{"share":"members"}}	\N	{"workspace":{"models":true}}	1795595630	1795595630	\N
\.


--
-- Data for Name: group_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_member (id, group_id, user_id, created_at, updated_at) FROM stdin;
49a40912-d571-4691-b806-342b5f9f98fd	1a9e8b27-82cc-4624-942c-1f93b14acc08	1636581a-57a9-49a3-abd9-7079db647896	1795595630	1795595630
06d1c9db-a1d5-45e1-b2fa-109c36af172c	1a9e8b27-82cc-4624-942c-1f93b14acc08	9e5a97c6-283b-4584-a48b-35f1b16fe74f	1795595630	1795595630
\.


--
-- Data for Name: knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge (id, user_id, name, description, meta, created_at, updated_at, data) FROM stdin;
2e700ced-9c11-4e00-b64f-719db7f4e9e6	41fa65e2-730a-4451-be4a-29363294205f	Handbook	Where things are	null	1795595632	1795595632	\N
\.


--
-- Data for Name: knowledge_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_directory (id, knowledge_id, parent_id, name, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_file (id, user_id, knowledge_id, file_id, created_at, updated_at, directory_id) FROM stdin;
c8b361be-681e-479a-b80d-9da7dbdf641c	41fa65e2-730a-4451-be4a-29363294205f	2e700ced-9c11-4e00-b64f-719db7f4e9e6	8a88c64c-6825-475c-9d18-53791115fb4a	1795595632	1795595632	\N
\.


--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.memory (id, user_id, content, updated_at, created_at, type, path, meta) FROM stdin;
7fbb6732-9998-49a0-a14a-d8dbb292246e	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Alice is allergic to peanuts.	1795595641	1795595641	context	\N	{"created_by":"manual"}
18f52f49-463b-4e78-8586-face3a69a1c8	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Alice prefers window seats.	1795595641	1795595641	context	\N	{"created_by":"manual"}
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (id, user_id, channel_id, content, data, meta, created_at, updated_at, parent_id, reply_to_id, is_pinned, pinned_at, pinned_by, app_id) FROM stdin;
a856248c-1eb1-44d5-9544-8043b03d652b	9e5a97c6-283b-4584-a48b-35f1b16fe74f	c88311b7-4e54-4203-bfe4-927b32a3aa98	Who has the lighthouse key?	null	null	1795595641945641040	1795595641945641040	\N	\N	f	\N	\N	\N
da84879b-a74a-405e-838c-a8fd60bfd7cb	1636581a-57a9-49a3-abd9-7079db647896	c88311b7-4e54-4203-bfe4-927b32a3aa98	Behind the blue door.	null	null	1795595641992027625	1795595641992027625	a856248c-1eb1-44d5-9544-8043b03d652b	\N	f	\N	\N	\N
\.


--
-- Data for Name: message_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reaction (id, user_id, message_id, name, created_at) FROM stdin;
5fab5d54-35c6-4d6a-a3d6-3a0a6b816111	1636581a-57a9-49a3-abd9-7079db647896	a856248c-1eb1-44d5-9544-8043b03d652b	thumbsup	1795595642054904050
\.


--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model (id, user_id, base_model_id, name, params, meta, updated_at, created_at, is_active, version_id) FROM stdin;
research-assistant	41fa65e2-730a-4451-be4a-29363294205f	mock-model	Research assistant	{"system":"You answer from the handbook.","temperature":0.2}	{"profile_image_url":null,"background_image_url":null,"description":"Answers from the handbook","i18n":null,"capabilities":null,"knowledge":null,"subagents":null,"voice":null,"voice_avatar":null}	1795595630	1795595630	t	a4ad4c6c-138f-473d-b010-31e6e2ee837e
\.


--
-- Data for Name: model_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_history (id, model_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
a4ad4c6c-138f-473d-b010-31e6e2ee837e	research-assistant	\N	{"name":"Research assistant","base_model_id":"mock-model","params":{"system":"You answer from the handbook.","temperature":0.2},"meta":{"profile_image_url":null,"background_image_url":null,"description":"Answers from the handbook","i18n":null,"capabilities":null,"knowledge":null,"subagents":null,"voice":null,"voice_avatar":null}}	41fa65e2-730a-4451-be4a-29363294205f	\N	1795595630
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (id, user_id, title, data, meta, created_at, updated_at) FROM stdin;
a907d19c-5d38-4877-b9eb-e9af71935f26	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Groceries	{"content":{"md":"# Groceries\\n\\n- apples\\n- *dark* chocolate","html":"","json":null},"pages":[{"id":"main","title":"Groceries","content":{"md":"# Groceries\\n\\n- apples\\n- *dark* chocolate","html":"","json":null},"versions":[],"revision":0,"generation":0,"parent_id":null}],"pages_revision":0,"search_text":"Groceries\\n# Groceries\\n\\n- apples\\n- *dark* chocolate"}	null	1795595641852233469	1795595641852233730
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification (id, user_id, event_type, event_key, actor_type, actor_id, resource_type, resource_id, object_type, object_id, data, seen_at, read_at, created_at, updated_at) FROM stdin;
5797bcca-4194-4f68-b1a1-567dd10e09a6	9e5a97c6-283b-4584-a48b-35f1b16fe74f	channel.replied	message:da84879b-a74a-405e-838c-a8fd60bfd7cb:created	user	1636581a-57a9-49a3-abd9-7079db647896	channel	c88311b7-4e54-4203-bfe4-927b32a3aa98	message	da84879b-a74a-405e-838c-a8fd60bfd7cb	{}	\N	\N	1795595642014167904	1795595642014167904
\.


--
-- Data for Name: oauth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_session (id, user_id, provider, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pinned_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_note (id, user_id, note_id, created_at) FROM stdin;
\.


--
-- Data for Name: prompt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt (id, command, user_id, name, content, data, meta, is_active, version_id, tags, created_at, updated_at) FROM stdin;
8d5c917b-b8d5-45e1-ad9a-4aecab91c4ff	summarize	41fa65e2-730a-4451-be4a-29363294205f	Summarize	Summarize the following text in three bullet points.	{}	{}	t	8e762f47-51d4-4dbb-b525-63ebc891ab3e	[]	1795595630	1795595630
93145973-919f-4dfb-b55b-ed1cecc6cf42	alice-draft	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Alice's draft	Draft a polite reply to this email.	{}	{}	t	251380b1-3eb7-4300-903e-9c18916fb008	[]	1795595630	1795595630
\.


--
-- Data for Name: prompt_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt_history (id, prompt_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
8e762f47-51d4-4dbb-b525-63ebc891ab3e	8d5c917b-b8d5-45e1-ad9a-4aecab91c4ff	\N	{"name":"Summarize","content":"Summarize the following text in three bullet points.","command":"summarize","data":{},"meta":{},"tags":[],"access_grants":[{"id":"82faca8e-ff42-4765-af07-a95c5e4f0027","resource_type":"prompt","resource_id":"8d5c917b-b8d5-45e1-ad9a-4aecab91c4ff","principal_type":"group","principal_id":"1a9e8b27-82cc-4624-942c-1f93b14acc08","permission":"read","created_at":1795595630}]}	41fa65e2-730a-4451-be4a-29363294205f	Initial version	1795595630
251380b1-3eb7-4300-903e-9c18916fb008	93145973-919f-4dfb-b55b-ed1cecc6cf42	\N	{"name":"Alice's draft","content":"Draft a polite reply to this email.","command":"alice-draft","data":{},"meta":{},"tags":[],"access_grants":[]}	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Initial version	1795595630
\.


--
-- Data for Name: shared_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shared_chat (id, chat_id, user_id, title, chat, created_at, updated_at) FROM stdin;
44bac9fb-44c6-49c5-bd68-940ffc80020a	0d09fe46-67bd-406b-b955-4779a6a6c2ef	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Packing for Vienna	{"title":"Packing for Vienna","models":["mock-model"],"history":{"messages":{"u1-0000-4000-8000-000000000000":{"id":"u1-0000-4000-8000-000000000000","parentId":null,"childrenIds":["a1-0000-4000-8000-000000000000","a1b-0000-4000-8000-000000000000"],"role":"user","content":"What should I pack for Vienna?","files":[{"type":"file","id":"ccdbdb1f-d5d2-464e-b417-fcfd34542acd","name":"packing.txt","status":"uploaded"}],"timestamp":1795595632,"models":["mock-model"],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"a1-0000-4000-8000-000000000000":{"id":"a1-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"Pack an umbrella.","model":"mock-model","done":true,"timestamp":1795595633,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"},"a1b-0000-4000-8000-000000000000":{"id":"a1b-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":["u2-0000-4000-8000-000000000000"],"role":"assistant","content":"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.","model":"mock-model","done":true,"timestamp":1795595634,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"},"u2-0000-4000-8000-000000000000":{"id":"u2-0000-4000-8000-000000000000","parentId":"a1b-0000-4000-8000-000000000000","childrenIds":["a2-0000-4000-8000-000000000000"],"role":"user","content":"And for the evening?","timestamp":1795595635,"models":["mock-model"],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"a2-0000-4000-8000-000000000000":{"id":"a2-0000-4000-8000-000000000000","parentId":"u2-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"A light jacket.","model":"mock-model","done":true,"timestamp":1795595636,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"}},"currentId":"a2-0000-4000-8000-000000000000"},"messages":[{"id":"u1-0000-4000-8000-000000000000","parentId":null,"childrenIds":["a1-0000-4000-8000-000000000000","a1b-0000-4000-8000-000000000000"],"role":"user","content":"What should I pack for Vienna?","files":[{"type":"file","id":"ccdbdb1f-d5d2-464e-b417-fcfd34542acd","name":"packing.txt","status":"uploaded"}],"timestamp":1795595632,"models":["mock-model"],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},{"id":"a1b-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":["u2-0000-4000-8000-000000000000"],"role":"assistant","content":"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.","model":"mock-model","done":true,"timestamp":1795595634,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"},{"id":"u2-0000-4000-8000-000000000000","parentId":"a1b-0000-4000-8000-000000000000","childrenIds":["a2-0000-4000-8000-000000000000"],"role":"user","content":"And for the evening?","timestamp":1795595635,"models":["mock-model"],"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},{"id":"a2-0000-4000-8000-000000000000","parentId":"u2-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"A light jacket.","model":"mock-model","done":true,"timestamp":1795595636,"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f"}],"files":[{"type":"file","id":"ccdbdb1f-d5d2-464e-b417-fcfd34542acd","name":"packing.txt","status":"uploaded"}],"params":{},"share_mode":null}	1795595632	1795595632
b813eeb6-95f6-45f3-ae21-4ace825b337a	0f1f89a1-ad51-4992-9007-d27279807d50	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Weather in Graz	{"id":"0f1f89a1-ad51-4992-9007-d27279807d50","title":"Weather in Graz","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"0921fb70-ef05-434b-8327-fc7ea6b67fad","messages":{"3b7ad9c2-266a-4557-bee6-04dd1e252355":{"id":"3b7ad9c2-266a-4557-bee6-04dd1e252355","parentId":null,"childrenIds":["0921fb70-ef05-434b-8327-fc7ea6b67fad"],"role":"user","user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","content":"What is the weather in Graz?","models":["mock-model"],"timestamp":1795595636,"user":{"id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","name":"Alice Author"}},"0921fb70-ef05-434b-8327-fc7ea6b67fad":{"id":"0921fb70-ef05-434b-8327-fc7ea6b67fad","parentId":"3b7ad9c2-266a-4557-bee6-04dd1e252355","childrenIds":[],"role":"assistant","content":"It is sunny in Graz, so leave the umbrella at home.","done":true,"model":"mock-model","timestamp":1795595636,"modelIdx":0,"meta":{"task_id":"d44b445b-1d9d-4dec-8e1a-b1ed6c10d899","response_started_at":1795595636.3402812,"response_ended_at":1795595637.1931596},"user_id":"9e5a97c6-283b-4584-a48b-35f1b16fe74f","output":[{"type":"function_call","id":"fc_c33573d258cc4ab3afc123f4","call_id":"fc_c33573d258cc4ab3afc123f4","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_74885fa12f604f1cb4d09cc3","call_id":"fc_c33573d258cc4ab3afc123f4","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"get_weather","arguments":"{\\"city\\": \\"Graz\\"}","status":"completed","started_at":1795595636.7800179,"ended_at":1795595636.7812085,"duration":0.0011906449944945052,"tool_id":"weather_tool"},{"type":"function_call_output","id":"fco_e5bc45b29d624c378b94ee5c","call_id":"call_1","output":[{"type":"input_text","text":"Sunny in Graz"}],"status":"completed"},{"type":"reasoning","id":"r_90ac9ca9d7d34f72b2af171f","status":"completed","start_tag":"<think>","end_tag":"</think>","attributes":{"type":"reasoning_content"},"content":[{"type":"output_text","text":"The weather tool says sunny, so no umbrella is needed."}],"summary":null,"started_at":1795595637.1908998,"ended_at":1795595637.191013,"duration":0},{"type":"message","id":"msg_aca895b6e0a64da88804fdb4","status":"completed","role":"assistant","content":[{"type":"output_text","text":"It is sunny in Graz, so leave the umbrella at home."}]}],"usage":{"incomplete":true,"input_tokens":42,"output_tokens":7,"total_tokens":49,"prompt_tokens":42,"completion_tokens":7}}}},"messages":[{"role":"user","content":"What is the weather in Graz?"}],"files":[],"tags":[],"timestamp":1795595636318,"share_mode":"continue"}	1795595641	1795595641
\.


--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill (id, user_id, name, description, content, meta, is_active, updated_at, created_at, version_id, data) FROM stdin;
trip-planner	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Trip planner	Plans multi-city trips by train.	---\nname: trip-planner\ndescription: Plans multi-city trips by train.\n---\n\n# Trip planner\n\n1. Ask for the cities and the dates.\n2. Prefer night trains over flights.\n3. Keep every transfer above 40 minutes.\n4. Name the platform for every departure.\n	{"i18n":null,"tags":["travel"]}	t	1795595631	1795595630	2434dc64-5640-4825-aae3-1a2ffc31fd19	{"files":[{"path":"SKILL.md","content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n4. Name the platform for every departure.\\n"}]}
uebersetzer	9e5a97c6-283b-4584-a48b-35f1b16fe74f	Übersetzer 日本語 🚀		# Übersetzer 🌍\r\n\r\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\r\n\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \r\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\r\n	{"i18n":null,"tags":[]}	t	1795595632	1795595632	d6428ad9-c3bb-4757-8235-1a2733178c07	{"files":[{"path":"SKILL.md","content":"# Übersetzer 🌍\\r\\n\\r\\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\\r\\n\\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \\r\\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\\r\\n"}]}
old-habits	1636581a-57a9-49a3-abd9-7079db647896	Old habits	\N	Answer in Latin.	{"i18n":null,"tags":[]}	f	1795595632	1795595632	681584dc-e796-4b41-ba11-ab979103a5a4	{"files":[{"path":"SKILL.md","content":"Answer in Latin."}]}
house-style	41fa65e2-730a-4451-be4a-29363294205f	House style	How every answer is formatted.	Use sentence case headings and no exclamation marks.	{"i18n":null,"tags":[]}	t	1795595632	1795595632	982eb173-75a1-4065-8f60-fdb6e8c9efd8	{"files":[{"path":"SKILL.md","content":"Use sentence case headings and no exclamation marks."}]}
dave-notes	00a86e93-e16b-4046-a008-22ad76484b34	Dave's notes	Left behind.	Hand over to the next shift at six.	{"i18n":null,"tags":[]}	t	1795595632	1795595632	453d4ff3-37cd-4860-a956-b899439a81a4	{"files":[{"path":"SKILL.md","content":"Hand over to the next shift at six."}]}
\.


--
-- Data for Name: skill_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill_history (id, skill_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
14464e63-0a82-4ee5-9930-926aaedf47fc	trip-planner	\N	{"name":"Trip planner","description":"Plans multi-city trips by train.","meta":{"i18n":null,"tags":["travel"]},"content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n","data":{"files":[{"path":"SKILL.md","content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n"}]}}	9e5a97c6-283b-4584-a48b-35f1b16fe74f	\N	1795595630
2434dc64-5640-4825-aae3-1a2ffc31fd19	trip-planner	14464e63-0a82-4ee5-9930-926aaedf47fc	{"name":"Trip planner","description":"Plans multi-city trips by train.","meta":{"i18n":null,"tags":["travel"]},"data":{"files":[{"path":"SKILL.md","content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n4. Name the platform for every departure.\\n"}]},"content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n4. Name the platform for every departure.\\n"}	9e5a97c6-283b-4584-a48b-35f1b16fe74f	\N	1795595631
d6428ad9-c3bb-4757-8235-1a2733178c07	uebersetzer	\N	{"name":"Übersetzer 日本語 🚀","description":"","meta":{"i18n":null,"tags":[]},"content":"# Übersetzer 🌍\\r\\n\\r\\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\\r\\n\\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \\r\\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\\r\\n","data":{"files":[{"path":"SKILL.md","content":"# Übersetzer 🌍\\r\\n\\r\\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\\r\\n\\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \\r\\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\\r\\n"}]}}	9e5a97c6-283b-4584-a48b-35f1b16fe74f	\N	1795595632
681584dc-e796-4b41-ba11-ab979103a5a4	old-habits	\N	{"name":"Old habits","description":null,"meta":{"i18n":null,"tags":[]},"content":"Answer in Latin.","data":{"files":[{"path":"SKILL.md","content":"Answer in Latin."}]}}	1636581a-57a9-49a3-abd9-7079db647896	\N	1795595632
982eb173-75a1-4065-8f60-fdb6e8c9efd8	house-style	\N	{"name":"House style","description":"How every answer is formatted.","meta":{"i18n":null,"tags":[]},"content":"Use sentence case headings and no exclamation marks.","data":{"files":[{"path":"SKILL.md","content":"Use sentence case headings and no exclamation marks."}]}}	41fa65e2-730a-4451-be4a-29363294205f	\N	1795595632
453d4ff3-37cd-4860-a956-b899439a81a4	dave-notes	\N	{"name":"Dave's notes","description":"Left behind.","meta":{"i18n":null,"tags":[]},"content":"Hand over to the next shift at six.","data":{"files":[{"path":"SKILL.md","content":"Hand over to the next shift at six."}]}}	00a86e93-e16b-4046-a008-22ad76484b34	\N	1795595632
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tag (id, name, user_id, meta) FROM stdin;
travel	travel	9e5a97c6-283b-4584-a48b-35f1b16fe74f	\N
\.


--
-- Data for Name: tool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool (id, user_id, name, content, specs, meta, valves, updated_at, created_at, version_id, is_active) FROM stdin;
weather_tool	41fa65e2-730a-4451-be4a-29363294205f	Weather	"""\ntitle: Weather\n"""\n\n\nfrom pydantic import BaseModel\n\n\nclass Tools:\n    class Valves(BaseModel):\n        units: str = "metric"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def get_weather(self, city: str) -> str:\n        """Report the weather in a city."""\n        return f"Sunny in {city}"\n	[{"name":"get_weather","description":"Report the weather in a city.","parameters":{"properties":{"city":{"type":"string"}},"required":["city"],"type":"object"}}]	{"i18n":null,"description":"Weather lookups","manifest":{"title":"Weather"},"has_user_valves":false}	\N	1795595630	1795595630	6da10958-9454-49c8-b732-b24577220b1f	t
\.


--
-- Data for Name: tool_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool_history (id, tool_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
6da10958-9454-49c8-b732-b24577220b1f	weather_tool	\N	{"name":"Weather","content":"\\"\\"\\"\\ntitle: Weather\\n\\"\\"\\"\\n\\n\\nfrom pydantic import BaseModel\\n\\n\\nclass Tools:\\n    class Valves(BaseModel):\\n        units: str = \\"metric\\"\\n\\n    def __init__(self):\\n        self.valves = self.Valves()\\n\\n    def get_weather(self, city: str) -> str:\\n        \\"\\"\\"Report the weather in a city.\\"\\"\\"\\n        return f\\"Sunny in {city}\\"\\n","meta":{"description":"Weather lookups"}}	41fa65e2-730a-4451-be4a-29363294205f	\N	1795595630
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, role, profile_image_url, last_active_at, updated_at, created_at, settings, info, username, bio, gender, date_of_birth, profile_banner_image_url, timezone, presence_state, status_emoji, status_message, status_expires_at, oauth, scim, variables) FROM stdin;
41fa65e2-730a-4451-be4a-29363294205f	Ada Admin	admin@example.com	admin	/user.png	1795595630	1795595629	1795595629	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
6fc344c0-d10a-4731-80c1-4719e317424d	Carol Outsider	carol@example.com	user	/user.png	1795595630	1795595630	1795595630	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
9e5a97c6-283b-4584-a48b-35f1b16fe74f	Alice Author	alice@example.com	user	/user.png	1795595630	1795595630	1795595630	{"ui":{"theme":"dark","chatBubble":false,"notesSeen":3}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
1636581a-57a9-49a3-abd9-7079db647896	Bob Reader	bob@example.com	user	/user.png	1795595630	1795595630	1795595630	{"ui":{"models":["research-assistant"]}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
\.


--
-- Name: config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_id_seq', 1, false);


--
-- Name: access_grant access_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT access_grant_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_key UNIQUE (key);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: app app_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app
    ADD CONSTRAINT app_pkey PRIMARY KEY (id);


--
-- Name: app app_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app
    ADD CONSTRAINT app_slug_key UNIQUE (slug);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: auth_session auth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session
    ADD CONSTRAINT auth_session_pkey PRIMARY KEY (id);


--
-- Name: automation automation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation
    ADD CONSTRAINT automation_pkey PRIMARY KEY (id);


--
-- Name: automation_run automation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_run
    ADD CONSTRAINT automation_run_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendee calendar_event_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT calendar_event_attendee_pkey PRIMARY KEY (id);


--
-- Name: calendar_event calendar_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event
    ADD CONSTRAINT calendar_event_pkey PRIMARY KEY (id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (id);


--
-- Name: channel_file channel_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_pkey PRIMARY KEY (id);


--
-- Name: channel_member channel_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT channel_member_pkey PRIMARY KEY (id);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_webhook channel_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_pkey PRIMARY KEY (id);


--
-- Name: chat_file chat_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: chat chat_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_share_id_key UNIQUE (share_id);


--
-- Name: chat_view_state chat_view_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_view_state
    ADD CONSTRAINT chat_view_state_pkey PRIMARY KEY (user_id, chat_id);


--
-- Name: chatidtag chatidtag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chatidtag
    ADD CONSTRAINT chatidtag_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: comment_reaction comment_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_reaction
    ADD CONSTRAINT comment_reaction_pkey PRIMARY KEY (id);


--
-- Name: config_old config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey1 PRIMARY KEY (key);


--
-- Name: document document_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_name_key UNIQUE (name);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (collection_name);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id, user_id);


--
-- Name: function_history function_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function_history
    ADD CONSTRAINT function_history_pkey PRIMARY KEY (id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: group_member group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_pkey PRIMARY KEY (id);


--
-- Name: group group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pkey PRIMARY KEY (id);


--
-- Name: knowledge_directory knowledge_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_pkey PRIMARY KEY (id);


--
-- Name: knowledge_file knowledge_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_pkey PRIMARY KEY (id);


--
-- Name: knowledge knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge
    ADD CONSTRAINT knowledge_pkey PRIMARY KEY (id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: message_reaction message_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reaction
    ADD CONSTRAINT message_reaction_pkey PRIMARY KEY (id);


--
-- Name: model_history model_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_history
    ADD CONSTRAINT model_history_pkey PRIMARY KEY (id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: oauth_session oauth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_pkey PRIMARY KEY (id);


--
-- Name: pinned_note pinned_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_pkey PRIMARY KEY (id);


--
-- Name: tag pk_id_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_id_user_id PRIMARY KEY (id, user_id);


--
-- Name: prompt_history prompt_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt_history
    ADD CONSTRAINT prompt_history_pkey PRIMARY KEY (id);


--
-- Name: prompt prompt_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt
    ADD CONSTRAINT prompt_new_pkey PRIMARY KEY (id);


--
-- Name: shared_chat shared_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_pkey PRIMARY KEY (id);


--
-- Name: skill_history skill_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_history
    ADD CONSTRAINT skill_history_pkey PRIMARY KEY (id);


--
-- Name: skill skill_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_name_key UNIQUE (name);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- Name: tool_history tool_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_history
    ADD CONSTRAINT tool_history_pkey PRIMARY KEY (id);


--
-- Name: tool tool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool
    ADD CONSTRAINT tool_pkey PRIMARY KEY (id);


--
-- Name: access_grant uq_access_grant_grant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT uq_access_grant_grant UNIQUE (resource_type, resource_id, principal_type, principal_id, permission);


--
-- Name: channel_file uq_channel_file_channel_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT uq_channel_file_channel_file UNIQUE (channel_id, file_id);


--
-- Name: channel_member uq_channel_member_app; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT uq_channel_member_app UNIQUE (channel_id, app_id);


--
-- Name: chat_file uq_chat_file_chat_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT uq_chat_file_chat_file UNIQUE (chat_id, file_id);


--
-- Name: comment_reaction uq_comment_reaction; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_reaction
    ADD CONSTRAINT uq_comment_reaction UNIQUE (comment_id, user_id, name);


--
-- Name: calendar_event_attendee uq_event_attendee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT uq_event_attendee UNIQUE (event_id, user_id);


--
-- Name: group_member uq_group_member_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT uq_group_member_group_user UNIQUE (group_id, user_id);


--
-- Name: knowledge_directory uq_knowledge_directory_knowledge_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT uq_knowledge_directory_knowledge_parent_name UNIQUE (knowledge_id, parent_id, name);


--
-- Name: knowledge_file uq_knowledge_file_knowledge_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT uq_knowledge_file_knowledge_file UNIQUE (knowledge_id, file_id);


--
-- Name: notification uq_notification_occurrence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT uq_notification_occurrence UNIQUE (user_id, event_key);


--
-- Name: pinned_note uq_pinned_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT uq_pinned_note UNIQUE (user_id, note_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: chat_message_chat_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_parent_idx ON public.chat_message USING btree (chat_id, parent_id);


--
-- Name: chat_message_chat_role_done_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_role_done_idx ON public.chat_message USING btree (chat_id, role, done);


--
-- Name: chat_message_model_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_model_created_idx ON public.chat_message USING btree (model_id, created_at);


--
-- Name: chat_message_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_user_created_idx ON public.chat_message USING btree (user_id, created_at);


--
-- Name: file_pending_knowledge_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_pending_knowledge_idx ON public.file USING btree ((((meta -> 'data'::text) ->> 'knowledge_id'::text))) WHERE ((data ->> 'status'::text) = ANY (ARRAY['pending'::text, 'processing'::text]));


--
-- Name: folder_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_idx ON public.chat USING btree (folder_id);


--
-- Name: folder_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_user_id_idx ON public.chat USING btree (folder_id, user_id);


--
-- Name: idx_access_grant_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_principal ON public.access_grant USING btree (principal_type, principal_id);


--
-- Name: idx_access_grant_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_resource ON public.access_grant USING btree (resource_type, resource_id);


--
-- Name: idx_auth_session_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_session_expires ON public.auth_session USING btree (expires_at);


--
-- Name: idx_auth_session_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_session_user ON public.auth_session USING btree (user_id);


--
-- Name: idx_oauth_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_expires_at ON public.oauth_session USING btree (expires_at);


--
-- Name: idx_oauth_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_id ON public.oauth_session USING btree (user_id);


--
-- Name: idx_oauth_session_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_provider ON public.oauth_session USING btree (user_id, provider);


--
-- Name: idx_skill_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_updated_at ON public.skill USING btree (updated_at);


--
-- Name: idx_skill_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_user_id ON public.skill USING btree (user_id);


--
-- Name: is_global_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX is_global_idx ON public.function USING btree (is_global);


--
-- Name: ix_automation_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_next_run ON public.automation USING btree (next_run_at);


--
-- Name: ix_automation_run_automation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_run_automation_id ON public.automation_run USING btree (automation_id);


--
-- Name: ix_automation_user_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_user_folder ON public.automation USING btree (user_id, folder_id);


--
-- Name: ix_calendar_event_attendee_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_attendee_user ON public.calendar_event_attendee USING btree (user_id, status);


--
-- Name: ix_calendar_event_calendar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_calendar ON public.calendar_event USING btree (calendar_id, start_at);


--
-- Name: ix_calendar_event_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_user_date ON public.calendar_event USING btree (user_id, start_at);


--
-- Name: ix_calendar_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_user ON public.calendar USING btree (user_id);


--
-- Name: ix_channel_file_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_channel_id ON public.channel_file USING btree (channel_id);


--
-- Name: ix_channel_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_file_id ON public.channel_file USING btree (file_id);


--
-- Name: ix_channel_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_user_id ON public.channel_file USING btree (user_id);


--
-- Name: ix_channel_member_app_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_member_app_active ON public.channel_member USING btree (app_id, is_active);


--
-- Name: ix_chat_file_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_chat_id ON public.chat_file USING btree (chat_id);


--
-- Name: ix_chat_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_file_id ON public.chat_file USING btree (file_id);


--
-- Name: ix_chat_file_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_message_id ON public.chat_file USING btree (message_id);


--
-- Name: ix_chat_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_user_id ON public.chat_file USING btree (user_id);


--
-- Name: ix_chat_message_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_chat_id ON public.chat_message USING btree (chat_id);


--
-- Name: ix_chat_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_created_at ON public.chat_message USING btree (created_at);


--
-- Name: ix_chat_message_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_model_id ON public.chat_message USING btree (model_id);


--
-- Name: ix_chat_message_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_user_id ON public.chat_message USING btree (user_id);


--
-- Name: ix_chat_view_state_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_view_state_chat_id ON public.chat_view_state USING btree (chat_id);


--
-- Name: ix_comment_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_comment_parent ON public.comment USING btree (parent_id, created_at, id);


--
-- Name: ix_comment_reaction_comment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_comment_reaction_comment_id ON public.comment_reaction USING btree (comment_id);


--
-- Name: ix_comment_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_comment_resource ON public.comment USING btree (resource_type, resource_id, parent_id, created_at, id);


--
-- Name: ix_comment_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_comment_target ON public.comment USING btree (resource_type, resource_id, target_type, target_id);


--
-- Name: ix_function_history_function_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_function_history_function_id ON public.function_history USING btree (function_id);


--
-- Name: ix_group_member_user_id_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_group_member_user_id_group_id ON public.group_member USING btree (user_id, group_id);


--
-- Name: ix_group_parent_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_group_parent_group_id ON public."group" USING btree (parent_group_id);


--
-- Name: ix_knowledge_directory_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_knowledge_id ON public.knowledge_directory USING btree (knowledge_id);


--
-- Name: ix_knowledge_directory_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_parent_id ON public.knowledge_directory USING btree (parent_id);


--
-- Name: ix_knowledge_file_directory_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_directory_id ON public.knowledge_file USING btree (directory_id);


--
-- Name: ix_knowledge_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_file_id ON public.knowledge_file USING btree (file_id);


--
-- Name: ix_knowledge_file_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_knowledge_id ON public.knowledge_file USING btree (knowledge_id);


--
-- Name: ix_knowledge_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_user_id ON public.knowledge_file USING btree (user_id);


--
-- Name: ix_memory_id_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_id_user_id ON public.memory USING btree (id, user_id);


--
-- Name: ix_memory_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_type ON public.memory USING btree (type);


--
-- Name: ix_memory_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_user_id ON public.memory USING btree (user_id);


--
-- Name: ix_message_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_app ON public.message USING btree (app_id);


--
-- Name: ix_message_channel_parent_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_channel_parent_created ON public.message USING btree (channel_id, parent_id, created_at);


--
-- Name: ix_message_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_parent_id ON public.message USING btree (parent_id);


--
-- Name: ix_message_reaction_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_reaction_message_id ON public.message_reaction USING btree (message_id);


--
-- Name: ix_model_history_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_model_history_model_id ON public.model_history USING btree (model_id);


--
-- Name: ix_notification_object; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_object ON public.notification USING btree (object_type, object_id);


--
-- Name: ix_notification_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_resource ON public.notification USING btree (resource_type, resource_id);


--
-- Name: ix_notification_unseen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_unseen ON public.notification USING btree (user_id, created_at, id) WHERE (seen_at IS NULL);


--
-- Name: ix_notification_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_user_created ON public.notification USING btree (user_id, created_at, id);


--
-- Name: ix_prompt_history_prompt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompt_history_prompt_id ON public.prompt_history USING btree (prompt_id);


--
-- Name: ix_prompt_new_command; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_prompt_new_command ON public.prompt USING btree (command);


--
-- Name: ix_skill_history_skill_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_skill_history_skill_id ON public.skill_history USING btree (skill_id);


--
-- Name: ix_tool_history_tool_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tool_history_tool_id ON public.tool_history USING btree (tool_id);


--
-- Name: timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX timer_at_idx ON public.chat USING btree (timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: updated_at_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX updated_at_user_id_idx ON public.chat USING btree (updated_at, user_id);


--
-- Name: uq_user_email_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_user_email_lower ON public."user" USING btree (lower((email)::text)) WHERE (email IS NOT NULL);


--
-- Name: user_id_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_archived_idx ON public.chat USING btree (user_id, archived);


--
-- Name: user_id_folder_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_folder_unread_idx ON public.chat USING btree (user_id, folder_id, archived, updated_at, last_read_at, id);


--
-- Name: user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_idx ON public.tag USING btree (user_id);


--
-- Name: user_id_pinned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_pinned_idx ON public.chat USING btree (user_id, pinned);


--
-- Name: user_id_timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_timer_at_idx ON public.chat USING btree (user_id, timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: user_id_updated_at_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_updated_at_id_idx ON public.chat USING btree (user_id, updated_at DESC, id);


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: channel_webhook channel_webhook_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: chat_message chat_message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: channel_file fk_channel_file_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT fk_channel_file_message_id FOREIGN KEY (message_id) REFERENCES public.message(id) ON DELETE CASCADE;


--
-- Name: group fk_group_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT fk_group_parent FOREIGN KEY (parent_group_id) REFERENCES public."group"(id) ON DELETE SET NULL;


--
-- Name: knowledge_file fk_knowledge_file_directory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT fk_knowledge_file_directory_id FOREIGN KEY (directory_id) REFERENCES public.knowledge_directory(id) ON DELETE SET NULL;


--
-- Name: group_member group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: group_member group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_directory(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: oauth_session oauth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: pinned_note pinned_note_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id) ON DELETE CASCADE;


--
-- Name: shared_chat shared_chat_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

