--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_grant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_grant (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    user_id text,
    key text NOT NULL,
    data json,
    expires_at bigint,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: app; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    user_id text,
    is_active boolean DEFAULT false NOT NULL,
    data json NOT NULL,
    api_key text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth (
    id character varying NOT NULL,
    email character varying,
    password text,
    active boolean,
    mfa json,
    session_stamp text
);


--
-- Name: auth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_session (
    id text NOT NULL,
    user_id text,
    refresh_token_id text,
    data json NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    expires_at bigint NOT NULL
);


--
-- Name: automation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    data json NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    folder_id text
);


--
-- Name: automation_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_run (
    id text NOT NULL,
    automation_id text NOT NULL,
    chat_id text,
    status text NOT NULL,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    color text,
    is_default boolean NOT NULL,
    data json,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event (
    id text NOT NULL,
    calendar_id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    start_at bigint NOT NULL,
    end_at bigint,
    all_day boolean NOT NULL,
    rrule text,
    color text,
    location text,
    data json,
    meta json,
    is_cancelled boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event_attendee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendee (
    id text NOT NULL,
    event_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    type text,
    is_private boolean,
    archived_at bigint,
    archived_by text,
    deleted_at bigint,
    deleted_by text,
    updated_by text
);


--
-- Name: channel_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_file (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    message_id text
);


--
-- Name: channel_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_member (
    id text NOT NULL,
    channel_id text NOT NULL,
    user_id text,
    created_at bigint,
    status text,
    is_active boolean DEFAULT true NOT NULL,
    is_channel_muted boolean DEFAULT false NOT NULL,
    is_channel_pinned boolean DEFAULT false NOT NULL,
    data json,
    meta json,
    joined_at bigint NOT NULL,
    left_at bigint,
    last_read_at bigint,
    updated_at bigint,
    role text,
    invited_by text,
    invited_at bigint,
    app_id text,
    CONSTRAINT ck_channel_member_identity CHECK (((user_id IS NULL) <> (app_id IS NULL)))
);


--
-- Name: channel_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_webhook (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    profile_image_url text,
    token text NOT NULL,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    user_id character varying,
    title text,
    created_at bigint,
    updated_at bigint,
    share_id text,
    archived boolean,
    chat json,
    pinned boolean,
    meta json DEFAULT '{}'::json NOT NULL,
    folder_id text,
    tasks json,
    summary text,
    last_read_at bigint,
    current_message_id text,
    variables json,
    timer_at bigint
);


--
-- Name: chat_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_file (
    id text NOT NULL,
    user_id text NOT NULL,
    chat_id text NOT NULL,
    file_id text NOT NULL,
    message_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text,
    role text NOT NULL,
    parent_id text,
    content json,
    output json,
    model_id text,
    files json,
    sources json,
    embeds json,
    done boolean,
    status_history json,
    error json,
    usage json,
    created_at bigint,
    updated_at bigint,
    context_summary text,
    meta json
);


--
-- Name: chat_view_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_view_state (
    user_id text NOT NULL,
    chat_id text NOT NULL,
    state json NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chatidtag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chatidtag (
    id character varying NOT NULL,
    tag_name character varying,
    chat_id character varying,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: comment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment (
    id text NOT NULL,
    user_id text,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    parent_id text,
    reply_to_id text,
    content text NOT NULL,
    target_type text,
    target_id text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    deleted_at bigint
);


--
-- Name: comment_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.comment_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    comment_id text NOT NULL,
    name text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    key text NOT NULL,
    value json NOT NULL,
    updated_at bigint
);


--
-- Name: config_old; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_old (
    id integer NOT NULL,
    data json NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config_old.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    collection_name character varying NOT NULL,
    name character varying,
    title text,
    filename text,
    content text,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    user_id text,
    version bigint,
    type text,
    data json,
    meta json,
    snapshot json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id character varying NOT NULL,
    user_id character varying,
    filename text,
    meta json,
    created_at bigint,
    hash text,
    data json,
    updated_at bigint,
    path text
);


--
-- Name: folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder (
    id text NOT NULL,
    parent_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    items json,
    meta json,
    is_expanded boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    data json
);


--
-- Name: function; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    type text,
    content text,
    meta text,
    valves text,
    is_active boolean,
    is_global boolean,
    updated_at bigint,
    created_at bigint,
    version_id text
);


--
-- Name: function_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function_history (
    id text NOT NULL,
    function_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."group" (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    permissions json,
    created_at bigint,
    updated_at bigint,
    parent_group_id text
);


--
-- Name: group_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_member (
    id text NOT NULL,
    group_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    updated_at bigint
);


--
-- Name: knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint,
    data json
);


--
-- Name: knowledge_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_directory (
    id text NOT NULL,
    knowledge_id text NOT NULL,
    parent_id text,
    name text NOT NULL,
    user_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: knowledge_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_file (
    id text NOT NULL,
    user_id text NOT NULL,
    knowledge_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    directory_id text
);


--
-- Name: memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory (
    id character varying NOT NULL,
    user_id character varying,
    content text,
    updated_at bigint,
    created_at bigint,
    type character varying DEFAULT 'context'::character varying NOT NULL,
    path text,
    meta json
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    id text NOT NULL,
    user_id text,
    channel_id text,
    content text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    parent_id text,
    reply_to_id text,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at bigint,
    pinned_by text,
    app_id text
);


--
-- Name: message_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    message_id text NOT NULL,
    name text NOT NULL,
    created_at bigint
);


--
-- Name: model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model (
    id text NOT NULL,
    user_id text,
    base_model_id text,
    name text,
    params text,
    meta text,
    updated_at bigint,
    created_at bigint,
    is_active boolean DEFAULT true NOT NULL,
    version_id text
);


--
-- Name: model_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_history (
    id text NOT NULL,
    model_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    id text NOT NULL,
    user_id text,
    title text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: notification; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification (
    id text NOT NULL,
    user_id text NOT NULL,
    event_type text NOT NULL,
    event_key text NOT NULL,
    actor_type text NOT NULL,
    actor_id text,
    resource_type text,
    resource_id text,
    object_type text,
    object_id text,
    data json NOT NULL,
    seen_at bigint,
    read_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    CONSTRAINT ck_notification_actor CHECK ((actor_type = ANY (ARRAY['user'::text, 'system'::text]))),
    CONSTRAINT ck_notification_object CHECK (((object_type IS NULL) = (object_id IS NULL))),
    CONSTRAINT ck_notification_resource CHECK (((resource_type IS NULL) = (resource_id IS NULL)))
);


--
-- Name: oauth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_session (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pinned_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_note (
    id text NOT NULL,
    user_id text NOT NULL,
    note_id text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: prompt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt (
    id text NOT NULL,
    command character varying,
    user_id character varying NOT NULL,
    name text NOT NULL,
    content text NOT NULL,
    data json,
    meta json,
    is_active boolean DEFAULT true NOT NULL,
    version_id text,
    tags json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: prompt_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt_history (
    id text NOT NULL,
    prompt_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: shared_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_chat (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text NOT NULL,
    title text,
    chat json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    updated_at bigint NOT NULL,
    created_at bigint NOT NULL,
    version_id text,
    data json
);


--
-- Name: skill_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill_history (
    id text NOT NULL,
    skill_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tag (
    id character varying NOT NULL,
    name character varying,
    user_id character varying NOT NULL,
    meta json
);


--
-- Name: tool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    content text,
    specs text,
    meta text,
    valves text,
    updated_at bigint,
    created_at bigint,
    version_id text,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: tool_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool_history (
    id text NOT NULL,
    tool_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id character varying NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    profile_image_url text,
    last_active_at bigint,
    updated_at bigint,
    created_at bigint,
    settings json,
    info json,
    username character varying(50),
    bio text,
    gender text,
    date_of_birth date,
    profile_banner_image_url text,
    timezone character varying,
    presence_state character varying,
    status_emoji character varying,
    status_message text,
    status_expires_at bigint,
    oauth json,
    scim json,
    variables json
);


--
-- Name: config_old id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Data for Name: access_grant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_grant (id, resource_type, resource_id, principal_type, principal_id, permission, created_at) FROM stdin;
79be4c44-2612-4114-bf61-fc168ea0508b	prompt	b6d6abd3-6686-4858-8714-735488a3786d	group	445127d3-a506-4ee4-a2a9-618f26834f44	read	1795594918
74d89f63-7600-4719-9f57-6ad0b4c021ac	tool	weather_tool	group	445127d3-a506-4ee4-a2a9-618f26834f44	read	1795594918
ac46a3fe-2df1-4650-aaf1-61d98162188e	model	research-assistant	user	00b0add8-dc69-4860-a112-13e304932661	read	1795594918
d9cc79d2-cdfe-4c34-93a3-47b2393a9f0f	skill	trip-planner	group	445127d3-a506-4ee4-a2a9-618f26834f44	read	1795594919
2a74be01-9274-4255-b85e-c46e3cf6d7a2	skill	trip-planner	user	00b0add8-dc69-4860-a112-13e304932661	write	1795594919
093a1b87-b19b-43d1-8219-55f0e77a5b38	skill	house-style	user	*	read	1795594920
ba062498-7f8d-4aa7-8368-9a34b3754f20	skill	dave-notes	group	445127d3-a506-4ee4-a2a9-618f26834f44	read	1795594920
658a63d5-adb4-4d06-bd0d-61a2cc214c8f	knowledge	9f4537ad-8839-428e-8262-1510a4254caf	group	445127d3-a506-4ee4-a2a9-618f26834f44	read	1795594920
de9fc7e9-9411-4a5e-a975-ce8296a66e7d	shared_chat	5b8d58ea-c644-4061-af7e-b77a67f60e0a	user	00b0add8-dc69-4860-a112-13e304932661	read	1795594920
91f29b68-c5fc-4dbf-ae00-848522d2298f	shared_chat	8960f128-d8dc-4e34-84b7-2d2c7dfa8472	user	00b0add8-dc69-4860-a112-13e304932661	read	1795594929
b49b51a9-ca58-462c-b190-081b10f77122	note	02b90ebe-de12-4af8-9413-e175e0eb74c2	user	00b0add8-dc69-4860-a112-13e304932661	read	1795594929
015f37a4-1905-4632-8ebe-7292f535e429	note	02b90ebe-de12-4af8-9413-e175e0eb74c2	user	00b0add8-dc69-4860-a112-13e304932661	write	1795594929
da0a1764-ad68-445d-9296-017651a3682d	channel	2ca23e36-692b-43af-9884-50096fb1e2b7	group	445127d3-a506-4ee4-a2a9-618f26834f44	read	1795594929
66a3dde0-0b34-4dd2-a300-27f8ff55d6b8	channel	2ca23e36-692b-43af-9884-50096fb1e2b7	group	445127d3-a506-4ee4-a2a9-618f26834f44	write	1795594929
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
9f6c2a8d1b43
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, user_id, key, data, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: app; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.app (id, slug, name, user_id, is_active, data, api_key, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth (id, email, password, active, mfa, session_stamp) FROM stdin;
b6eefad0-3d9a-4207-8db1-ab436466c206	admin@example.com	$2b$12$f9a/hec/FWD.vePuc9iVreSQy6RL/RChXtQlk6FJByfEgKdYmZ2Am	t	\N	43b9b453-708b-4964-bf65-1970481f14ca
2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	alice@example.com	$2b$12$GEUcECNGKUjA3.ClW8scI.3okGaQyzjlJYLEgKFSU0I46mrCKa3wG	t	\N	7a96f9c0-706f-4ae9-bb61-136030876ea9
00b0add8-dc69-4860-a112-13e304932661	bob@example.com	$2b$12$S6hfAxRoXrmkw.23xMX9KO0T0Ktwib6hXWY2MT/YM8K8XHa5eCKDi	t	\N	4c45cf20-f205-4013-95cb-f3b971a417f6
2a252931-2f6c-45f3-9f7d-fb47c6b5eda1	carol@example.com	$2b$12$JuSku6ZQYbdFK.VVu/qxvu64pbriMn4W8ZRWux.D4GUR3OqVuPQjK	t	\N	9158b054-64a2-43e1-bce5-136fbc1860af
\.


--
-- Data for Name: auth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_session (id, user_id, refresh_token_id, data, created_at, updated_at, expires_at) FROM stdin;
\.


--
-- Data for Name: automation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation (id, user_id, name, data, meta, is_active, last_run_at, next_run_at, created_at, updated_at, folder_id) FROM stdin;
\.


--
-- Data for Name: automation_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_run (id, automation_id, chat_id, status, error, created_at) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar (id, user_id, name, color, is_default, data, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event (id, calendar_id, user_id, title, description, start_at, end_at, all_day, rrule, color, location, data, meta, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendee (id, event_id, user_id, status, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel (id, user_id, name, description, data, meta, created_at, updated_at, type, is_private, archived_at, archived_by, deleted_at, deleted_by, updated_by) FROM stdin;
2ca23e36-692b-43af-9884-50096fb1e2b7	b6eefad0-3d9a-4207-8db1-ab436466c206	lighthouse	Team chatter	null	null	1795594929129440317	1795594929129440668	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: channel_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_file (id, user_id, channel_id, file_id, created_at, updated_at, message_id) FROM stdin;
\.


--
-- Data for Name: channel_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_member (id, channel_id, user_id, created_at, status, is_active, is_channel_muted, is_channel_pinned, data, meta, joined_at, left_at, last_read_at, updated_at, role, invited_by, invited_at, app_id) FROM stdin;
722cec58-be71-460a-ad52-ac7616f32d0f	2ca23e36-692b-43af-9884-50096fb1e2b7	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	1795594929165577055	joined	t	f	f	null	null	1795594929165576324	\N	1795594929165576865	1795594929165577115	\N	\N	\N	\N
87cddb49-ec68-487b-908f-ca558ba6d204	2ca23e36-692b-43af-9884-50096fb1e2b7	00b0add8-dc69-4860-a112-13e304932661	1795594929229782305	joined	t	f	f	null	null	1795594929229781704	\N	1795594929229782075	1795594929229782395	\N	\N	\N	\N
\.


--
-- Data for Name: channel_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_webhook (id, user_id, channel_id, name, profile_image_url, token, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat (id, user_id, title, created_at, updated_at, share_id, archived, chat, pinned, meta, folder_id, tasks, summary, last_read_at, current_message_id, variables, timer_at) FROM stdin;
5b8d58ea-c644-4061-af7e-b77a67f60e0a	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Packing for Vienna	1795594920	1795594920	9c83a7b5-31a5-425c-9257-fa0761a585b8	f	{"title":"Packing for Vienna","models":["mock-model"],"history":{"messages":{"u1-0000-4000-8000-000000000000":{"id":"u1-0000-4000-8000-000000000000","parentId":null,"childrenIds":["a1-0000-4000-8000-000000000000","a1b-0000-4000-8000-000000000000"],"role":"user","content":"What should I pack for Vienna?","files":[{"type":"file","id":"4a55665b-dfff-4b79-aab1-b5670dd76e3d","name":"packing.txt","status":"uploaded"}],"timestamp":1795594920,"models":["mock-model"],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"a1-0000-4000-8000-000000000000":{"id":"a1-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"Pack an umbrella.","model":"mock-model","done":true,"timestamp":1795594921,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"},"a1b-0000-4000-8000-000000000000":{"id":"a1b-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":["u2-0000-4000-8000-000000000000"],"role":"assistant","content":"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.","model":"mock-model","done":true,"timestamp":1795594922,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"},"u2-0000-4000-8000-000000000000":{"id":"u2-0000-4000-8000-000000000000","parentId":"a1b-0000-4000-8000-000000000000","childrenIds":["a2-0000-4000-8000-000000000000"],"role":"user","content":"And for the evening?","timestamp":1795594923,"models":["mock-model"],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"a2-0000-4000-8000-000000000000":{"id":"a2-0000-4000-8000-000000000000","parentId":"u2-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"A light jacket.","model":"mock-model","done":true,"timestamp":1795594924,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"}},"currentId":"a2-0000-4000-8000-000000000000"},"messages":[{"id":"u1-0000-4000-8000-000000000000","parentId":null,"childrenIds":["a1-0000-4000-8000-000000000000","a1b-0000-4000-8000-000000000000"],"role":"user","content":"What should I pack for Vienna?","files":[{"type":"file","id":"4a55665b-dfff-4b79-aab1-b5670dd76e3d","name":"packing.txt","status":"uploaded"}],"timestamp":1795594920,"models":["mock-model"],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},{"id":"a1b-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":["u2-0000-4000-8000-000000000000"],"role":"assistant","content":"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.","model":"mock-model","done":true,"timestamp":1795594922,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"},{"id":"u2-0000-4000-8000-000000000000","parentId":"a1b-0000-4000-8000-000000000000","childrenIds":["a2-0000-4000-8000-000000000000"],"role":"user","content":"And for the evening?","timestamp":1795594923,"models":["mock-model"],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},{"id":"a2-0000-4000-8000-000000000000","parentId":"u2-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"A light jacket.","model":"mock-model","done":true,"timestamp":1795594924,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"}],"files":[{"type":"file","id":"4a55665b-dfff-4b79-aab1-b5670dd76e3d","name":"packing.txt","status":"uploaded"}],"params":{}}	t	{"tags":["travel"]}	06ea4d6d-f53e-4076-ad16-8d3a81a340a4	null	\N	1795594920	a2-0000-4000-8000-000000000000	{}	\N
4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Schnitzel questions	1795594920	1795594922	\N	f	{"id":"4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6","title":"Schnitzel questions","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"7269c001-f08f-42ec-9081-67d0f2de3874","messages":{"29770218-bb04-4c86-89a9-fb1ae83b3211":{"id":"29770218-bb04-4c86-89a9-fb1ae83b3211","parentId":null,"childrenIds":["bed89f31-1737-4581-b28f-078bc65d6274"],"role":"user","content":"What is a Schnitzel?","models":["mock-model"],"timestamp":1795594920,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"bed89f31-1737-4581-b28f-078bc65d6274":{"id":"bed89f31-1737-4581-b28f-078bc65d6274","parentId":"29770218-bb04-4c86-89a9-fb1ae83b3211","childrenIds":["a1e94ea8-7873-431a-af85-7168608fb483"],"role":"assistant","content":"Schnitzel is a breaded cutlet.","done":true,"model":"mock-model","timestamp":1795594920,"meta":{"task_id":"8d8328c4-5f19-40e3-9b0f-ed9439fa2549","response_started_at":1795594920.9721107,"response_ended_at":1795594921.4555874},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_eb272439a8bd4d2581d1ec44","call_id":"fc_eb272439a8bd4d2581d1ec44","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_7bce85dee0a74b49931809af","call_id":"fc_eb272439a8bd4d2581d1ec44","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_bb96a84357914412b56584d4","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Schnitzel is a breaded cutlet."}]}],"usage":{"incomplete":true}},"a1e94ea8-7873-431a-af85-7168608fb483":{"id":"a1e94ea8-7873-431a-af85-7168608fb483","parentId":"bed89f31-1737-4581-b28f-078bc65d6274","childrenIds":["7269c001-f08f-42ec-9081-67d0f2de3874"],"role":"user","content":"How do I eat it?","models":["mock-model"],"timestamp":1795594921,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"7269c001-f08f-42ec-9081-67d0f2de3874":{"id":"7269c001-f08f-42ec-9081-67d0f2de3874","parentId":"a1e94ea8-7873-431a-af85-7168608fb483","childrenIds":[],"role":"assistant","content":"Try it with lemon.","done":true,"model":"mock-model","modelIdx":null,"timestamp":1795594921,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","meta":{"task_id":"169ae0f9-9950-4a2e-af45-72a1aec39ade","response_started_at":1795594921.5965645,"response_ended_at":1795594922.0552182},"output":[{"type":"message","id":"msg_e351338352934b83b5bb9f36","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Try it with lemon."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"What is a Schnitzel?"}],"files":[],"tags":[],"timestamp":1795594920949}	f	{}	\N	null	\N	1795594920	7269c001-f08f-42ec-9081-67d0f2de3874	{}	\N
f50accd6-64f3-462a-b149-dc69a09a6f55	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Old plans	1795594923	1795594923	\N	t	{"title":"Old plans","models":["mock-model"],"history":{}}	f	{}	\N	null	\N	1795594923	\N	{}	\N
05d048e4-5195-4cbd-b474-5dee9a7250e0	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Lighthouse key	1795594922	1795594923	\N	f	{"id":"05d048e4-5195-4cbd-b474-5dee9a7250e0","title":"Lighthouse key","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"bc25e157-4028-4025-a0ea-3b7989eb5f56","messages":{"22c500f0-3d71-4b51-a3f8-bfc045e58ef0":{"id":"22c500f0-3d71-4b51-a3f8-bfc045e58ef0","parentId":null,"childrenIds":["bc25e157-4028-4025-a0ea-3b7989eb5f56"],"role":"user","content":"Where does the lighthouse key hang?","models":["mock-model"],"timestamp":1795594922,"files":[{"type":"collection","id":"9f4537ad-8839-428e-8262-1510a4254caf","name":"Handbook"}],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"bc25e157-4028-4025-a0ea-3b7989eb5f56":{"id":"bc25e157-4028-4025-a0ea-3b7989eb5f56","parentId":"22c500f0-3d71-4b51-a3f8-bfc045e58ef0","childrenIds":[],"role":"assistant","content":"Behind the blue door [1].","done":true,"model":"mock-model","timestamp":1795594922,"meta":{"task_id":"9d084709-b644-4c72-9044-717d97e41bdf","response_started_at":1795594922.2279687,"response_ended_at":1795594923.104273},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","sources":[{"source":{"id":"2db66796-5178-4156-ab6c-7d550999c66f","name":"handbook.txt","type":"file"},"document":["The upgrade handbook says the lighthouse key hangs behind the blue door."],"metadata":[{"file_id":"2db66796-5178-4156-ab6c-7d550999c66f","name":"handbook.txt","source":"handbook.txt"}],"distances":[0.9999999403953552]}],"output":[{"type":"function_call","id":"fc_a9f44a369e8446f78853ae9a","call_id":"fc_a9f44a369e8446f78853ae9a","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_ae89df25487c4923b01a043b","call_id":"fc_a9f44a369e8446f78853ae9a","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"query_knowledge_files","arguments":"{\\"query\\": \\"lighthouse key\\", \\"knowledge_ids\\": [\\"9f4537ad-8839-428e-8262-1510a4254caf\\"]}","status":"completed","started_at":1795594922.6599302,"ended_at":1795594922.6714964,"duration":0.011567073001060635,"tool_id":"builtin:query_knowledge_files","tool_type":"builtin"},{"type":"function_call_output","id":"fco_c9583af79cef477785a59fe0","call_id":"call_1","output":[{"type":"input_text","text":"[{\\"content\\":\\"The upgrade handbook says the lighthouse key hangs behind the blue door.\\",\\"source\\":\\"handbook.txt\\",\\"file_id\\":\\"2db66796-5178-4156-ab6c-7d550999c66f\\",\\"distance\\":0.9999999403953552}]\\n\\n### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n<source id=\\"1\\" name=\\"handbook.txt\\" resource-type=\\"file\\" resource-id=\\"2db66796-5178-4156-ab6c-7d550999c66f\\"></source>\\n</context>\\n"}],"status":"completed"},{"type":"message","id":"msg_a353303192d84f7083825767","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Behind the blue door [1]."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Where does the lighthouse key hang?"}],"files":[{"type":"collection","id":"9f4537ad-8839-428e-8262-1510a4254caf","name":"Handbook"}],"tags":[],"timestamp":1795594922205}	f	{}	\N	null	\N	1795594922	bc25e157-4028-4025-a0ea-3b7989eb5f56	{}	\N
24ae07f9-213e-4baa-ab2b-d7113f640427	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Castle near Vienna	1795594924	1795594924	\N	f	{"id":"24ae07f9-213e-4baa-ab2b-d7113f640427","title":"Castle near Vienna","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"4563d519-f69c-49d2-8370-6efba662c350","messages":{"76c0dd61-1ab6-4d52-9fea-1c5911a1112f":{"id":"76c0dd61-1ab6-4d52-9fea-1c5911a1112f","parentId":null,"childrenIds":["4563d519-f69c-49d2-8370-6efba662c350"],"role":"user","user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","content":"Name a castle near Vienna.","models":["mock-model"],"timestamp":1795594924,"user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"4563d519-f69c-49d2-8370-6efba662c350":{"id":"4563d519-f69c-49d2-8370-6efba662c350","parentId":"76c0dd61-1ab6-4d52-9fea-1c5911a1112f","childrenIds":[],"role":"assistant","content":"Burg Kreuzenstein, north of Vienna.","done":true,"model":"mock-model","timestamp":1795594924,"modelIdx":0,"meta":{"task_id":"adb42d72-d4d2-4e07-9f29-45002e2aadd3","response_started_at":1795594924.21403,"response_ended_at":1795594924.645215},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_8fc33863eda14396bcd802a5","call_id":"fc_8fc33863eda14396bcd802a5","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_8c3ba69168da41869c93b125","call_id":"fc_8fc33863eda14396bcd802a5","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_0241e614b53640078ae648ed","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Burg Kreuzenstein, north of Vienna."}]}],"usage":{"incomplete":true}}}},"messages":[{"id":"76c0dd61-1ab6-4d52-9fea-1c5911a1112f","parentId":null,"childrenIds":["4563d519-f69c-49d2-8370-6efba662c350"],"role":"user","user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","content":"Name a castle near Vienna.","models":["mock-model"],"timestamp":1795594924,"user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},{"id":"4563d519-f69c-49d2-8370-6efba662c350","parentId":"76c0dd61-1ab6-4d52-9fea-1c5911a1112f","childrenIds":[],"role":"assistant","content":"Burg Kreuzenstein, north of Vienna.","done":true,"model":"mock-model","timestamp":1795594924,"modelIdx":0,"meta":{"task_id":"adb42d72-d4d2-4e07-9f29-45002e2aadd3","response_started_at":1795594924.21403,"response_ended_at":1795594924.645215},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_8fc33863eda14396bcd802a5","call_id":"fc_8fc33863eda14396bcd802a5","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_8c3ba69168da41869c93b125","call_id":"fc_8fc33863eda14396bcd802a5","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_0241e614b53640078ae648ed","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Burg Kreuzenstein, north of Vienna."}]}],"usage":{"incomplete":true}}],"files":[],"tags":[],"timestamp":1795594924192}	f	{}	\N	null	\N	1795594924	4563d519-f69c-49d2-8370-6efba662c350	{}	\N
0bb2790f-5d41-48e8-bbe6-1dde157936ed	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Museum day	1795594927	1795594928	\N	f	{"id":"0bb2790f-5d41-48e8-bbe6-1dde157936ed","title":"Museum day","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"f3ce40f4-e5f8-4446-bc11-c6474638a8b7","messages":{"ccd9e9f4-c3bf-4bc9-9fa3-9df0d4a6bbde":{"id":"ccd9e9f4-c3bf-4bc9-9fa3-9df0d4a6bbde","parentId":null,"childrenIds":["f3ce40f4-e5f8-4446-bc11-c6474638a8b7"],"role":"user","user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","content":"Plan my museum day.","models":["mock-model"],"timestamp":1795594927,"user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"f3ce40f4-e5f8-4446-bc11-c6474638a8b7":{"id":"f3ce40f4-e5f8-4446-bc11-c6474638a8b7","parentId":"ccd9e9f4-c3bf-4bc9-9fa3-9df0d4a6bbde","childrenIds":[],"role":"assistant","content":"Start at the Albertina, then walk to the Leopold Museum.","done":true,"model":"mock-model","timestamp":1795594927,"modelIdx":0,"meta":{"task_id":"edcdb049-97c4-4b45-87fb-645e14dbdd50","response_started_at":1795594927.0537064,"response_ended_at":1795594928.3448665},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_80d0e6bdfcdd4e8cb54833a1","call_id":"fc_80d0e6bdfcdd4e8cb54833a1","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_33f039f83a164773aae40774","call_id":"fc_80d0e6bdfcdd4e8cb54833a1","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"delegate_task","arguments":"{\\"task\\": \\"List three museums near the Ring.\\"}","status":"completed","started_at":1795594927.4827056,"ended_at":1795594927.9757168,"duration":0.4930113719892688,"tool_id":"builtin:delegate_task","tool_type":"builtin"},{"type":"function_call_output","id":"fco_80a131d067044ee58bf16828","call_id":"call_1","output":[{"type":"input_text","text":"Albertina, Leopold Museum and Kunsthistorisches Museum."}],"status":"completed"},{"type":"message","id":"msg_7fa8cd13a02e4de2b5b5a5c7","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Start at the Albertina, then walk to the Leopold Museum."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Plan my museum day."}],"files":[],"tags":[],"timestamp":1795594927029}	f	{}	\N	null	\N	1795594927	f3ce40f4-e5f8-4446-bc11-c6474638a8b7	{}	\N
8960f128-d8dc-4e34-84b7-2d2c7dfa8472	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Weather in Graz	1795594923	1795594924	5209511f-72ab-45d2-a966-acb2b73fcb23	f	{"id":"8960f128-d8dc-4e34-84b7-2d2c7dfa8472","title":"Weather in Graz","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"8d83861a-d4f2-4ae2-b9fb-dfc15158f172","messages":{"627a5423-0b58-4cad-a7ac-4a2b440c7201":{"id":"627a5423-0b58-4cad-a7ac-4a2b440c7201","parentId":null,"childrenIds":["8d83861a-d4f2-4ae2-b9fb-dfc15158f172"],"role":"user","user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","content":"What is the weather in Graz?","models":["mock-model"],"timestamp":1795594923,"user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"8d83861a-d4f2-4ae2-b9fb-dfc15158f172":{"id":"8d83861a-d4f2-4ae2-b9fb-dfc15158f172","parentId":"627a5423-0b58-4cad-a7ac-4a2b440c7201","childrenIds":[],"role":"assistant","content":"It is sunny in Graz, so leave the umbrella at home.","done":true,"model":"mock-model","timestamp":1795594923,"modelIdx":0,"meta":{"task_id":"ddb1bbd3-60d1-4dae-aafa-ba766ea662ff","response_started_at":1795594923.251919,"response_ended_at":1795594924.0969543},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_64f116a1c96e47c9be3c3044","call_id":"fc_64f116a1c96e47c9be3c3044","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_67b2ff718b404205b205158b","call_id":"fc_64f116a1c96e47c9be3c3044","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"get_weather","arguments":"{\\"city\\": \\"Graz\\"}","status":"completed","started_at":1795594923.6778452,"ended_at":1795594923.679571,"duration":0.0017249950033146888,"tool_id":"weather_tool"},{"type":"function_call_output","id":"fco_1bde288db1e649a5bf12acdd","call_id":"call_1","output":[{"type":"input_text","text":"Sunny in Graz"}],"status":"completed"},{"type":"reasoning","id":"r_47d5cc30be8c4d13bb54abcb","status":"completed","start_tag":"<think>","end_tag":"</think>","attributes":{"type":"reasoning_content"},"content":[{"type":"output_text","text":"The weather tool says sunny, so no umbrella is needed."}],"summary":null,"started_at":1795594924.0948687,"ended_at":1795594924.0949998,"duration":0},{"type":"message","id":"msg_67c8d74b0a1b47c28107bb74","status":"completed","role":"assistant","content":[{"type":"output_text","text":"It is sunny in Graz, so leave the umbrella at home."}]}],"usage":{"incomplete":true,"input_tokens":42,"output_tokens":7,"total_tokens":49,"prompt_tokens":42,"completion_tokens":7}}}},"messages":[{"role":"user","content":"What is the weather in Graz?"}],"files":[],"tags":[],"timestamp":1795594923233}	f	{}	\N	null	\N	1795594923	8d83861a-d4f2-4ae2-b9fb-dfc15158f172	{}	\N
455bbbc5-fff6-4976-a070-1027fa375e86	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Sub-agent: List three museums near the Ring.	1795594927	1795594927	\N	f	{"id":"455bbbc5-fff6-4976-a070-1027fa375e86","title":"Sub-agent: List three museums near the Ring.","models":["mock-model"],"history":{"currentId":"7c7d7632-92ca-4996-b35a-5893dbe725ac","messages":{"e73657ba-8b59-49ca-814d-b4af23dcb2f1":{"id":"e73657ba-8b59-49ca-814d-b4af23dcb2f1","parentId":null,"childrenIds":["7c7d7632-92ca-4996-b35a-5893dbe725ac"],"role":"user","content":"List three museums near the Ring.","timestamp":1795594927,"models":["mock-model"]},"7c7d7632-92ca-4996-b35a-5893dbe725ac":{"id":"7c7d7632-92ca-4996-b35a-5893dbe725ac","parentId":"e73657ba-8b59-49ca-814d-b4af23dcb2f1","childrenIds":[],"role":"assistant","content":"Albertina, Leopold Museum and Kunsthistorisches Museum.","done":true,"model":"mock-model","timestamp":1795594927,"modelIdx":null,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","meta":{"task_id":"4966bead-9b31-4e39-8e91-9a271f7bace9","response_started_at":1795594927.5091376,"response_ended_at":1795594927.9644809},"output":[{"type":"function_call","id":"fc_a5746140f02b4feda91d5a17","call_id":"fc_a5746140f02b4feda91d5a17","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_605d87d5566d4e45a4c43e57","call_id":"fc_a5746140f02b4feda91d5a17","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_0e95c117d9b346759ea0ca9e","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Albertina, Leopold Museum and Kunsthistorisches Museum."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"List three museums near the Ring."}],"files":[]}	f	{"internal":true,"type":"subagent","parent_chat_id":"0bb2790f-5d41-48e8-bbe6-1dde157936ed","parent_message_id":"f3ce40f4-e5f8-4446-bc11-c6474638a8b7","delegation_id":"deleg_63ea5f1b","mode":"foreground"}	\N	null	\N	1795594927	7c7d7632-92ca-4996-b35a-5893dbe725ac	{}	\N
7442e35e-8d99-4cad-b3cf-4bbcc5d544b2	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Day trip	1795594924	1795594926	\N	f	{"id":"7442e35e-8d99-4cad-b3cf-4bbcc5d544b2","title":"Day trip","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"9e5de77d-f0b7-48d0-bdc3-e53a4a6b6aac","messages":{"771ff1b5-6d6f-428b-871c-afa865db6129":{"id":"771ff1b5-6d6f-428b-871c-afa865db6129","parentId":null,"childrenIds":["6451f00a-ad42-415e-a5ee-d6f0b92a3f2f","9e5de77d-f0b7-48d0-bdc3-e53a4a6b6aac"],"role":"user","user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","content":"Suggest a day trip from Vienna.","models":["mock-model"],"timestamp":1795594924,"user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"6451f00a-ad42-415e-a5ee-d6f0b92a3f2f":{"id":"6451f00a-ad42-415e-a5ee-d6f0b92a3f2f","parentId":"771ff1b5-6d6f-428b-871c-afa865db6129","childrenIds":[],"role":"assistant","content":"Bratislava by boat.","done":true,"model":"mock-model","timestamp":1795594924,"modelIdx":0,"meta":{"task_id":"fdbd4059-2943-4083-a98d-7baebd37d184","response_started_at":1795594924.7716377,"response_ended_at":1795594925.205372},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_d0642f25a4044916b63a09f1","call_id":"fc_d0642f25a4044916b63a09f1","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_11ff6524894c4e7782e857f8","call_id":"fc_d0642f25a4044916b63a09f1","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_e9ba2ffa4a1f448b93c4972b","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Bratislava by boat."}]}],"usage":{"incomplete":true}},"9e5de77d-f0b7-48d0-bdc3-e53a4a6b6aac":{"id":"9e5de77d-f0b7-48d0-bdc3-e53a4a6b6aac","parentId":"771ff1b5-6d6f-428b-871c-afa865db6129","childrenIds":[],"role":"assistant","content":"The Wachau by bike.","done":true,"model":"mock-model","modelIdx":0,"timestamp":1795594925,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","meta":{"task_id":"0855bee8-88df-425c-a3a3-8f304af0bd4c","response_started_at":1795594925.8106313,"response_ended_at":1795594926.2462916},"output":[{"type":"function_call","id":"fc_b090c2279a7841ccbcff9313","call_id":"fc_b090c2279a7841ccbcff9313","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_73b4c780616b4f32b798a217","call_id":"fc_b090c2279a7841ccbcff9313","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_71038f35d7c8442f8fcbe15b","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The Wachau by bike."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Suggest a day trip from Vienna."}],"files":[],"tags":[],"timestamp":1795594924745}	f	{}	\N	null	\N	1795594924	9e5de77d-f0b7-48d0-bdc3-e53a4a6b6aac	{}	\N
7db6453f-04cb-414f-a7e7-ee68ab4a30d6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Museum order	1795594926	1795594926	\N	f	{"id":"7db6453f-04cb-414f-a7e7-ee68ab4a30d6","title":"Museum order","models":["mock-model","research-assistant"],"terminal_id":null,"working_directory":"","history":{"currentId":"e797aec9-375f-486f-9138-33da8fb8b2d3","messages":{"19a27e66-81ce-4aec-b6db-e6597d571db0":{"id":"19a27e66-81ce-4aec-b6db-e6597d571db0","parentId":null,"childrenIds":["e797aec9-375f-486f-9138-33da8fb8b2d3","0d568127-6841-4d8b-8c8f-d95db4049f54"],"role":"user","user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","content":"Which museum first?","models":["mock-model","research-assistant"],"timestamp":1795594926,"user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"e797aec9-375f-486f-9138-33da8fb8b2d3":{"id":"e797aec9-375f-486f-9138-33da8fb8b2d3","parentId":"19a27e66-81ce-4aec-b6db-e6597d571db0","childrenIds":[],"role":"assistant","content":"The Albertina.","done":true,"model":"mock-model","timestamp":1795594926,"modelIdx":0,"meta":{"task_id":"614759c6-c4ae-4973-8e66-ca0e300ebdf5","response_started_at":1795594926.3853204,"response_ended_at":1795594926.8510582},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_32d13cd2616e45c0b263fc29","call_id":"fc_32d13cd2616e45c0b263fc29","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_4206f0d219044720955f2677","call_id":"fc_32d13cd2616e45c0b263fc29","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_ffd4ddf56c6d4081aa2a9e23","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The Albertina."}]}],"usage":{"incomplete":true}},"0d568127-6841-4d8b-8c8f-d95db4049f54":{"id":"0d568127-6841-4d8b-8c8f-d95db4049f54","parentId":"19a27e66-81ce-4aec-b6db-e6597d571db0","childrenIds":[],"role":"assistant","content":"The handbook says the Leopold.","done":true,"model":"research-assistant","timestamp":1795594926,"modelIdx":1,"meta":{"task_id":"7d1e7262-0b37-4eb5-81ee-788a72c22d2e","response_started_at":1795594926.3882744,"response_ended_at":1795594926.8569703},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_89c876f383f04739839bcfb1","call_id":"fc_89c876f383f04739839bcfb1","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_50c17d78c4694762966befc0","call_id":"fc_89c876f383f04739839bcfb1","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_273e5249b8024096a6a15ba5","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The handbook says the Leopold."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Which museum first?"}],"files":[],"tags":[],"timestamp":1795594926347}	f	{}	\N	null	\N	1795594926	e797aec9-375f-486f-9138-33da8fb8b2d3	{}	\N
e8a5f02b-c3da-4b1b-918c-1944c1626984	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Trains to Graz	1795594928	1795594928	\N	f	{"id":"e8a5f02b-c3da-4b1b-918c-1944c1626984","title":"Trains to Graz","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"0bb415e7-f2e0-4246-97b2-dbbabd2b8760","messages":{"e0badce3-3f56-4ef1-927a-b624573520b4":{"id":"e0badce3-3f56-4ef1-927a-b624573520b4","parentId":null,"childrenIds":["0bb415e7-f2e0-4246-97b2-dbbabd2b8760"],"role":"user","user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","content":"Where do trains to Graz leave from?","models":["mock-model"],"timestamp":1795594928,"user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"0bb415e7-f2e0-4246-97b2-dbbabd2b8760":{"id":"0bb415e7-f2e0-4246-97b2-dbbabd2b8760","parentId":"e0badce3-3f56-4ef1-927a-b624573520b4","childrenIds":[],"role":"assistant","content":"From Wien Hauptbahnhof.","done":true,"model":"mock-model","timestamp":1795594928,"modelIdx":0,"meta":{"task_id":"f525a50b-1fac-46e0-a426-b012d41a5679","response_started_at":1795594928.503035,"response_ended_at":1795594928.9323218},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_671faabdfc5143e591270069","call_id":"fc_671faabdfc5143e591270069","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_9217affb10cf4a3a85b5f4e1","call_id":"fc_671faabdfc5143e591270069","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_91acf84c71fe47989f658d88","status":"completed","role":"assistant","content":[{"type":"output_text","text":"From Wien Hauptbahnhof."}]}],"usage":{"incomplete":true}}}},"messages":[{"role":"user","content":"Where do trains to Graz leave from?"}],"files":[],"tags":[],"timestamp":1795594928481}	f	{}	32e65f0a-b3e9-4109-a2ec-19d3d264eac6	null	\N	1795594928	0bb415e7-f2e0-4246-97b2-dbbabd2b8760	{}	\N
\.


--
-- Data for Name: chat_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_file (id, user_id, chat_id, file_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_message (id, chat_id, user_id, role, parent_id, content, output, model_id, files, sources, embeds, done, status_history, error, usage, created_at, updated_at, context_summary, meta) FROM stdin;
5b8d58ea-c644-4061-af7e-b77a67f60e0a-u1-0000-4000-8000-000000000000	5b8d58ea-c644-4061-af7e-b77a67f60e0a	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"What should I pack for Vienna?"	null	\N	[{"type":"file","id":"4a55665b-dfff-4b79-aab1-b5670dd76e3d","name":"packing.txt","status":"uploaded"}]	null	null	t	null	null	null	1795594920	1795594920	\N	null
5b8d58ea-c644-4061-af7e-b77a67f60e0a-a1-0000-4000-8000-000000000000	5b8d58ea-c644-4061-af7e-b77a67f60e0a	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	u1-0000-4000-8000-000000000000	"Pack an umbrella."	null	mock-model	null	null	null	t	null	null	null	1795594921	1795594920	\N	null
5b8d58ea-c644-4061-af7e-b77a67f60e0a-a1b-0000-4000-8000-000000000000	5b8d58ea-c644-4061-af7e-b77a67f60e0a	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	u1-0000-4000-8000-000000000000	"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses."	null	mock-model	null	null	null	t	null	null	null	1795594922	1795594920	\N	null
5b8d58ea-c644-4061-af7e-b77a67f60e0a-u2-0000-4000-8000-000000000000	5b8d58ea-c644-4061-af7e-b77a67f60e0a	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	a1b-0000-4000-8000-000000000000	"And for the evening?"	null	\N	null	null	null	t	null	null	null	1795594923	1795594920	\N	null
5b8d58ea-c644-4061-af7e-b77a67f60e0a-a2-0000-4000-8000-000000000000	5b8d58ea-c644-4061-af7e-b77a67f60e0a	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	u2-0000-4000-8000-000000000000	"A light jacket."	null	mock-model	null	null	null	t	null	null	null	1795594924	1795594920	\N	null
4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6-29770218-bb04-4c86-89a9-fb1ae83b3211	4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"What is a Schnitzel?"	null	\N	null	null	null	t	null	null	null	1795594920	1795594920	\N	null
8960f128-d8dc-4e34-84b7-2d2c7dfa8472-627a5423-0b58-4cad-a7ac-4a2b440c7201	8960f128-d8dc-4e34-84b7-2d2c7dfa8472	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"What is the weather in Graz?"	null	\N	null	null	null	t	null	null	null	1795594923	1795594923	\N	null
4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6-bed89f31-1737-4581-b28f-078bc65d6274	4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	29770218-bb04-4c86-89a9-fb1ae83b3211	"Schnitzel is a breaded cutlet."	[{"type":"function_call","id":"fc_eb272439a8bd4d2581d1ec44","call_id":"fc_eb272439a8bd4d2581d1ec44","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_7bce85dee0a74b49931809af","call_id":"fc_eb272439a8bd4d2581d1ec44","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_bb96a84357914412b56584d4","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Schnitzel is a breaded cutlet."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594920	1795594921	\N	{"task_id":"8d8328c4-5f19-40e3-9b0f-ed9439fa2549","response_started_at":1795594920.9721107,"response_ended_at":1795594921.4555874}
4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6-a1e94ea8-7873-431a-af85-7168608fb483	4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	bed89f31-1737-4581-b28f-078bc65d6274	"How do I eat it?"	null	\N	null	null	null	t	null	null	null	1795594921	1795594921	\N	null
24ae07f9-213e-4baa-ab2b-d7113f640427-76c0dd61-1ab6-4d52-9fea-1c5911a1112f	24ae07f9-213e-4baa-ab2b-d7113f640427	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"Name a castle near Vienna."	null	\N	null	null	null	t	null	null	null	1795594924	1795594924	\N	null
05d048e4-5195-4cbd-b474-5dee9a7250e0-bc25e157-4028-4025-a0ea-3b7989eb5f56	05d048e4-5195-4cbd-b474-5dee9a7250e0	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	22c500f0-3d71-4b51-a3f8-bfc045e58ef0	"Behind the blue door [1]."	[{"type":"function_call","id":"fc_a9f44a369e8446f78853ae9a","call_id":"fc_a9f44a369e8446f78853ae9a","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_ae89df25487c4923b01a043b","call_id":"fc_a9f44a369e8446f78853ae9a","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"query_knowledge_files","arguments":"{\\"query\\": \\"lighthouse key\\", \\"knowledge_ids\\": [\\"9f4537ad-8839-428e-8262-1510a4254caf\\"]}","status":"completed","started_at":1795594922.6599302,"ended_at":1795594922.6714964,"duration":0.011567073001060635,"tool_id":"builtin:query_knowledge_files","tool_type":"builtin"},{"type":"function_call_output","id":"fco_c9583af79cef477785a59fe0","call_id":"call_1","output":[{"type":"input_text","text":"[{\\"content\\":\\"The upgrade handbook says the lighthouse key hangs behind the blue door.\\",\\"source\\":\\"handbook.txt\\",\\"file_id\\":\\"2db66796-5178-4156-ab6c-7d550999c66f\\",\\"distance\\":0.9999999403953552}]\\n\\n### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n<source id=\\"1\\" name=\\"handbook.txt\\" resource-type=\\"file\\" resource-id=\\"2db66796-5178-4156-ab6c-7d550999c66f\\"></source>\\n</context>\\n"}],"status":"completed"},{"type":"message","id":"msg_a353303192d84f7083825767","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Behind the blue door [1]."}]}]	mock-model	null	[{"source":{"id":"2db66796-5178-4156-ab6c-7d550999c66f","name":"handbook.txt","type":"file"},"document":["The upgrade handbook says the lighthouse key hangs behind the blue door."],"metadata":[{"file_id":"2db66796-5178-4156-ab6c-7d550999c66f","name":"handbook.txt","source":"handbook.txt"}],"distances":[0.9999999403953552]}]	null	t	null	null	{"incomplete":true}	1795594922	1795594923	\N	{"task_id":"9d084709-b644-4c72-9044-717d97e41bdf","response_started_at":1795594922.2279687,"response_ended_at":1795594923.104273}
4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6-7269c001-f08f-42ec-9081-67d0f2de3874	4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	a1e94ea8-7873-431a-af85-7168608fb483	"Try it with lemon."	[{"type":"message","id":"msg_e351338352934b83b5bb9f36","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Try it with lemon."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594921	1795594922	\N	{"task_id":"169ae0f9-9950-4a2e-af45-72a1aec39ade","response_started_at":1795594921.5965645,"response_ended_at":1795594922.0552182}
05d048e4-5195-4cbd-b474-5dee9a7250e0-22c500f0-3d71-4b51-a3f8-bfc045e58ef0	05d048e4-5195-4cbd-b474-5dee9a7250e0	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"Where does the lighthouse key hang?"	null	\N	[{"type":"collection","id":"9f4537ad-8839-428e-8262-1510a4254caf","name":"Handbook"}]	null	null	t	null	null	null	1795594922	1795594922	\N	null
7db6453f-04cb-414f-a7e7-ee68ab4a30d6-19a27e66-81ce-4aec-b6db-e6597d571db0	7db6453f-04cb-414f-a7e7-ee68ab4a30d6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"Which museum first?"	null	\N	null	null	null	t	null	null	null	1795594926	1795594926	\N	null
8960f128-d8dc-4e34-84b7-2d2c7dfa8472-8d83861a-d4f2-4ae2-b9fb-dfc15158f172	8960f128-d8dc-4e34-84b7-2d2c7dfa8472	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	627a5423-0b58-4cad-a7ac-4a2b440c7201	"It is sunny in Graz, so leave the umbrella at home."	[{"type":"function_call","id":"fc_64f116a1c96e47c9be3c3044","call_id":"fc_64f116a1c96e47c9be3c3044","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_67b2ff718b404205b205158b","call_id":"fc_64f116a1c96e47c9be3c3044","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"get_weather","arguments":"{\\"city\\": \\"Graz\\"}","status":"completed","started_at":1795594923.6778452,"ended_at":1795594923.679571,"duration":0.0017249950033146888,"tool_id":"weather_tool"},{"type":"function_call_output","id":"fco_1bde288db1e649a5bf12acdd","call_id":"call_1","output":[{"type":"input_text","text":"Sunny in Graz"}],"status":"completed"},{"type":"reasoning","id":"r_47d5cc30be8c4d13bb54abcb","status":"completed","start_tag":"<think>","end_tag":"</think>","attributes":{"type":"reasoning_content"},"content":[{"type":"output_text","text":"The weather tool says sunny, so no umbrella is needed."}],"summary":null,"started_at":1795594924.0948687,"ended_at":1795594924.0949998,"duration":0},{"type":"message","id":"msg_67c8d74b0a1b47c28107bb74","status":"completed","role":"assistant","content":[{"type":"output_text","text":"It is sunny in Graz, so leave the umbrella at home."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true,"input_tokens":42,"output_tokens":7,"total_tokens":49,"prompt_tokens":42,"completion_tokens":7}	1795594923	1795594924	\N	{"task_id":"ddb1bbd3-60d1-4dae-aafa-ba766ea662ff","response_started_at":1795594923.251919,"response_ended_at":1795594924.0969543}
24ae07f9-213e-4baa-ab2b-d7113f640427-4563d519-f69c-49d2-8370-6efba662c350	24ae07f9-213e-4baa-ab2b-d7113f640427	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	76c0dd61-1ab6-4d52-9fea-1c5911a1112f	"Burg Kreuzenstein, north of Vienna."	[{"type":"function_call","id":"fc_8fc33863eda14396bcd802a5","call_id":"fc_8fc33863eda14396bcd802a5","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_8c3ba69168da41869c93b125","call_id":"fc_8fc33863eda14396bcd802a5","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_0241e614b53640078ae648ed","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Burg Kreuzenstein, north of Vienna."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594924	1795594924	\N	{"task_id":"adb42d72-d4d2-4e07-9f29-45002e2aadd3","response_started_at":1795594924.21403,"response_ended_at":1795594924.645215}
7442e35e-8d99-4cad-b3cf-4bbcc5d544b2-771ff1b5-6d6f-428b-871c-afa865db6129	7442e35e-8d99-4cad-b3cf-4bbcc5d544b2	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"Suggest a day trip from Vienna."	null	\N	null	null	null	t	null	null	null	1795594924	1795594925	\N	null
7db6453f-04cb-414f-a7e7-ee68ab4a30d6-e797aec9-375f-486f-9138-33da8fb8b2d3	7db6453f-04cb-414f-a7e7-ee68ab4a30d6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	19a27e66-81ce-4aec-b6db-e6597d571db0	"The Albertina."	[{"type":"function_call","id":"fc_32d13cd2616e45c0b263fc29","call_id":"fc_32d13cd2616e45c0b263fc29","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_4206f0d219044720955f2677","call_id":"fc_32d13cd2616e45c0b263fc29","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_ffd4ddf56c6d4081aa2a9e23","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The Albertina."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594926	1795594926	\N	{"task_id":"614759c6-c4ae-4973-8e66-ca0e300ebdf5","response_started_at":1795594926.3853204,"response_ended_at":1795594926.8510582}
455bbbc5-fff6-4976-a070-1027fa375e86-e73657ba-8b59-49ca-814d-b4af23dcb2f1	455bbbc5-fff6-4976-a070-1027fa375e86	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"List three museums near the Ring."	null	\N	null	null	null	t	null	null	null	1795594927	1795594927	\N	null
0bb2790f-5d41-48e8-bbe6-1dde157936ed-ccd9e9f4-c3bf-4bc9-9fa3-9df0d4a6bbde	0bb2790f-5d41-48e8-bbe6-1dde157936ed	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"Plan my museum day."	null	\N	null	null	null	t	null	null	null	1795594927	1795594927	\N	null
7442e35e-8d99-4cad-b3cf-4bbcc5d544b2-9e5de77d-f0b7-48d0-bdc3-e53a4a6b6aac	7442e35e-8d99-4cad-b3cf-4bbcc5d544b2	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	771ff1b5-6d6f-428b-871c-afa865db6129	"The Wachau by bike."	[{"type":"function_call","id":"fc_b090c2279a7841ccbcff9313","call_id":"fc_b090c2279a7841ccbcff9313","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_73b4c780616b4f32b798a217","call_id":"fc_b090c2279a7841ccbcff9313","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_71038f35d7c8442f8fcbe15b","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The Wachau by bike."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594925	1795594926	\N	{"task_id":"0855bee8-88df-425c-a3a3-8f304af0bd4c","response_started_at":1795594925.8106313,"response_ended_at":1795594926.2462916}
7db6453f-04cb-414f-a7e7-ee68ab4a30d6-0d568127-6841-4d8b-8c8f-d95db4049f54	7db6453f-04cb-414f-a7e7-ee68ab4a30d6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	19a27e66-81ce-4aec-b6db-e6597d571db0	"The handbook says the Leopold."	[{"type":"function_call","id":"fc_89c876f383f04739839bcfb1","call_id":"fc_89c876f383f04739839bcfb1","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_50c17d78c4694762966befc0","call_id":"fc_89c876f383f04739839bcfb1","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_273e5249b8024096a6a15ba5","status":"completed","role":"assistant","content":[{"type":"output_text","text":"The handbook says the Leopold."}]}]	research-assistant	null	null	null	t	null	null	{"incomplete":true}	1795594926	1795594926	\N	{"task_id":"7d1e7262-0b37-4eb5-81ee-788a72c22d2e","response_started_at":1795594926.3882744,"response_ended_at":1795594926.8569703}
7442e35e-8d99-4cad-b3cf-4bbcc5d544b2-6451f00a-ad42-415e-a5ee-d6f0b92a3f2f	7442e35e-8d99-4cad-b3cf-4bbcc5d544b2	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	771ff1b5-6d6f-428b-871c-afa865db6129	"Bratislava by boat."	[{"type":"function_call","id":"fc_d0642f25a4044916b63a09f1","call_id":"fc_d0642f25a4044916b63a09f1","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_11ff6524894c4e7782e857f8","call_id":"fc_d0642f25a4044916b63a09f1","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_e9ba2ffa4a1f448b93c4972b","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Bratislava by boat."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594924	1795594926	\N	{"task_id":"fdbd4059-2943-4083-a98d-7baebd37d184","response_started_at":1795594924.7716377,"response_ended_at":1795594925.205372}
455bbbc5-fff6-4976-a070-1027fa375e86-7c7d7632-92ca-4996-b35a-5893dbe725ac	455bbbc5-fff6-4976-a070-1027fa375e86	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	e73657ba-8b59-49ca-814d-b4af23dcb2f1	"Albertina, Leopold Museum and Kunsthistorisches Museum."	[{"type":"function_call","id":"fc_a5746140f02b4feda91d5a17","call_id":"fc_a5746140f02b4feda91d5a17","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_605d87d5566d4e45a4c43e57","call_id":"fc_a5746140f02b4feda91d5a17","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_0e95c117d9b346759ea0ca9e","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Albertina, Leopold Museum and Kunsthistorisches Museum."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594927	1795594927	\N	{"task_id":"4966bead-9b31-4e39-8e91-9a271f7bace9","response_started_at":1795594927.5091376,"response_ended_at":1795594927.9644809}
0bb2790f-5d41-48e8-bbe6-1dde157936ed-f3ce40f4-e5f8-4446-bc11-c6474638a8b7	0bb2790f-5d41-48e8-bbe6-1dde157936ed	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	ccd9e9f4-c3bf-4bc9-9fa3-9df0d4a6bbde	"Start at the Albertina, then walk to the Leopold Museum."	[{"type":"function_call","id":"fc_80d0e6bdfcdd4e8cb54833a1","call_id":"fc_80d0e6bdfcdd4e8cb54833a1","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_33f039f83a164773aae40774","call_id":"fc_80d0e6bdfcdd4e8cb54833a1","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"delegate_task","arguments":"{\\"task\\": \\"List three museums near the Ring.\\"}","status":"completed","started_at":1795594927.4827056,"ended_at":1795594927.9757168,"duration":0.4930113719892688,"tool_id":"builtin:delegate_task","tool_type":"builtin"},{"type":"function_call_output","id":"fco_80a131d067044ee58bf16828","call_id":"call_1","output":[{"type":"input_text","text":"Albertina, Leopold Museum and Kunsthistorisches Museum."}],"status":"completed"},{"type":"message","id":"msg_7fa8cd13a02e4de2b5b5a5c7","status":"completed","role":"assistant","content":[{"type":"output_text","text":"Start at the Albertina, then walk to the Leopold Museum."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594927	1795594928	\N	{"task_id":"edcdb049-97c4-4b45-87fb-645e14dbdd50","response_started_at":1795594927.0537064,"response_ended_at":1795594928.3448665}
e8a5f02b-c3da-4b1b-918c-1944c1626984-e0badce3-3f56-4ef1-927a-b624573520b4	e8a5f02b-c3da-4b1b-918c-1944c1626984	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	user	\N	"Where do trains to Graz leave from?"	null	\N	null	null	null	t	null	null	null	1795594928	1795594928	\N	null
e8a5f02b-c3da-4b1b-918c-1944c1626984-0bb415e7-f2e0-4246-97b2-dbbabd2b8760	e8a5f02b-c3da-4b1b-918c-1944c1626984	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	assistant	e0badce3-3f56-4ef1-927a-b624573520b4	"From Wien Hauptbahnhof."	[{"type":"function_call","id":"fc_671faabdfc5143e591270069","call_id":"fc_671faabdfc5143e591270069","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_9217affb10cf4a3a85b5f4e1","call_id":"fc_671faabdfc5143e591270069","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"message","id":"msg_91acf84c71fe47989f658d88","status":"completed","role":"assistant","content":[{"type":"output_text","text":"From Wien Hauptbahnhof."}]}]	mock-model	null	null	null	t	null	null	{"incomplete":true}	1795594928	1795594928	\N	{"task_id":"f525a50b-1fac-46e0-a426-b012d41a5679","response_started_at":1795594928.503035,"response_ended_at":1795594928.9323218}
\.


--
-- Data for Name: chat_view_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_view_state (user_id, chat_id, state, updated_at) FROM stdin;
\.


--
-- Data for Name: chatidtag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chatidtag (id, tag_name, chat_id, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: comment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment (id, user_id, resource_type, resource_id, parent_id, reply_to_id, content, target_type, target_id, meta, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: comment_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.comment_reaction (id, user_id, comment_id, name, created_at) FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config (key, value, updated_at) FROM stdin;
ollama.enable	false	1795594917
ollama.base_urls	["http://localhost:11434"]	1795594917
ollama.api_configs	{}	1795594917
openai.enable	true	1795594917
openai.api_keys	["sk-mock"]	1795594917
openai.api_base_urls	["http://127.0.0.1:42561/v1"]	1795594917
openai.api_configs	{}	1795594917
models.base_models_cache	false	1795594917
tool_server.connections	[]	1795594917
terminal_server.connections	[]	1795594917
code_execution.enable	true	1795594917
code_execution.engine	"pyodide"	1795594917
code_execution.jupyter.url	""	1795594917
code_execution.jupyter.auth	""	1795594917
code_execution.jupyter.auth_token	""	1795594917
code_execution.jupyter.auth_password	""	1795594917
code_execution.jupyter.timeout	60	1795594917
code_interpreter.enable	true	1795594917
memories.background_review.enable	false	1795594917
memories.review_interval_turns	10	1795594917
memories.user_char_limit	2000	1795594917
memories.context_char_limit	2000	1795594917
code_interpreter.engine	"pyodide"	1795594917
code_interpreter.prompt_template	""	1795594917
code_interpreter.jupyter.url	""	1795594917
code_interpreter.jupyter.auth	""	1795594917
code_interpreter.jupyter.auth_token	""	1795594917
code_interpreter.jupyter.auth_password	""	1795594917
code_interpreter.jupyter.timeout	60	1795594917
google_drive.enable	false	1795594917
google_drive.client_id	""	1795594917
google_drive.api_key	""	1795594917
onedrive.enable	false	1795594917
onedrive.sharepoint_url	""	1795594917
onedrive.sharepoint_tenant_id	""	1795594917
rag.content_extraction_engine	""	1795594917
rag.content_extraction.supported_media_mime_types	null	1795594917
rag.datalab_marker_api_key	""	1795594917
rag.datalab_marker_api_base_url	""	1795594917
rag.datalab_marker_additional_config	""	1795594917
rag.datalab_marker_use_llm	false	1795594917
rag.datalab_marker_skip_cache	false	1795594917
rag.datalab_marker_force_ocr	false	1795594917
rag.datalab_marker_paginate	false	1795594917
rag.datalab_marker_strip_existing_ocr	false	1795594917
rag.datalab_marker_disable_image_extraction	false	1795594917
rag.datalab_marker_format_lines	false	1795594917
rag.datalab_marker_output_format	"markdown"	1795594917
rag.mineru_api_mode	"local"	1795594917
rag.mineru_api_url	"http://localhost:8000"	1795594917
rag.mineru_api_timeout	"300"	1795594917
rag.mineru_api_key	""	1795594917
rag.mineru_params	{}	1795594917
rag.mineru_file_extensions	["pdf"]	1795594917
rag.external_document_loader_url	""	1795594917
rag.external_document_loader_api_key	""	1795594917
rag.external_document_loader_headers	{}	1795594917
rag.tika_server_url	"http://tika:9998"	1795594917
rag.tika_server_version	"3"	1795594917
rag.docling_server_url	"http://docling:5001"	1795594917
rag.docling_api_key	""	1795594917
rag.docling_params	{}	1795594917
rag.document_intelligence_endpoint	""	1795594917
rag.document_intelligence_key	""	1795594917
rag.document_intelligence_model	"prebuilt-layout"	1795594917
rag.mistral_ocr_api_base_url	"https://api.mistral.ai/v1"	1795594917
rag.mistral_ocr_api_key	""	1795594917
rag.mistral_ocr_use_base64	false	1795594917
rag.mistral_ocr_params	{}	1795594917
rag.paddleocr_vl_base_url	"http://localhost:8080"	1795594917
rag.paddleocr_vl_token	""	1795594917
rag.bypass_embedding_and_retrieval	false	1795594917
rag.top_k	10	1795594917
rag.top_k_reranker	10	1795594917
rag.relevance_threshold	0.0	1795594917
rag.hybrid_bm25_weight	0.5	1795594917
rag.enable_hybrid_search	false	1795594917
rag.enable_hybrid_search_enriched_texts	false	1795594917
rag.full_context	false	1795594917
rag.full_context_char_threshold	50000	1795594917
rag.file.max_count	null	1795594917
knowledge.max_upload_count	null	1795594917
knowledge.max_file_count	null	1795594917
knowledge.max_file_size	null	1795594917
rag.file.max_size	null	1795594917
file.image_compression_width	null	1795594917
file.image_compression_height	null	1795594917
rag.file.allowed_extensions	[]	1795594917
rag.embedding_engine	"openai"	1795594917
rag.pdf_extract_images	false	1795594917
rag.pdf_loader_mode	"page"	1795594917
rag.embedding_model	"sentence-transformers/all-MiniLM-L6-v2"	1795594917
rag.tokenizer_model	""	1795594917
rag.embedding_batch_size	1	1795594917
rag.embedding_query_prefix	null	1795594917
rag.embedding_content_prefix	null	1795594917
rag.enable_async_embedding	true	1795594917
rag.embedding_concurrent_requests	0	1795594917
rag.reranking_engine	""	1795594917
rag.reranking_model	""	1795594917
rag.reranking_batch_size	32	1795594917
rag.external_reranker_url	""	1795594917
rag.external_reranker_api_key	""	1795594917
rag.external_reranker_timeout	""	1795594917
rag.text_splitter	""	1795594917
rag.enable_markdown_header_text_splitter	true	1795594917
rag.tiktoken_encoding_name	"cl100k_base"	1795594917
rag.chunk_size	1024	1795594917
rag.chunk_min_size_target	0	1795594917
rag.chunk_overlap	100	1795594917
rag.template	"### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n{{CONTEXT}}\\n</context>\\n"	1795594917
rag.openai.api_base_url	"http://127.0.0.1:42561/v1"	1795594917
rag.openai.api_key	"sk-mock"	1795594917
rag.azure_openai.base_url	""	1795594917
rag.azure_openai.api_key	""	1795594917
rag.azure_openai.api_version	""	1795594917
rag.ollama.base_url	"http://localhost:11434"	1795594917
rag.ollama.api_key	""	1795594917
rag.youtube_loader_language	["en"]	1795594917
rag.youtube_loader_proxy_url	""	1795594917
web.search.enable	false	1795594917
web.search.confirmation.enable	false	1795594917
web.search.confirmation.content	"Your query will be sent to the configured web search provider."	1795594917
web.search.engine	""	1795594917
web.search.bypass_embedding_and_retrieval	false	1795594917
web.search.bypass_web_loader	false	1795594917
web.search.result_count	3	1795594917
web.search.domain.filter_list	[]	1795594917
web.search.concurrent_requests	0	1795594917
web.fetch.max_content_length	null	1795594917
web.loader.engine	""	1795594917
web.loader.concurrent_requests	10	1795594917
web.loader.timeout	""	1795594917
web.loader.ssl_verification	true	1795594917
web.search.trust_env	true	1795594917
web.search.ollama_cloud_api_key	""	1795594917
web.search.searxng_query_url	""	1795594917
web.search.openserp_base_url	"http://localhost:7000"	1795594917
web.search.searxng_language	"all"	1795594917
web.search.yacy_query_url	""	1795594917
web.search.yacy_username	""	1795594917
web.search.yacy_password	""	1795594917
web.search.google_pse_api_key	""	1795594917
web.search.google_pse_engine_id	""	1795594917
web.search.brave_search_api_key	""	1795594917
web.search.brave_search_context_tokens	8192	1795594917
web.search.kagi_search_api_key	""	1795594917
web.search.mojeek_search_api_key	""	1795594917
web.search.bocha_search_api_key	""	1795594917
web.search.serpstack_api_key	""	1795594917
web.search.serpstack_https	true	1795594917
web.search.serper_api_key	""	1795594917
web.search.serply_api_key	""	1795594917
web.search.serphouse_api_key	""	1795594917
web.search.serphouse_domain	"google.com"	1795594917
web.search.ddgs_backend	"auto"	1795594917
web.search.jina_api_key	""	1795594917
web.search.jina_api_base_url	""	1795594917
web.search.searchapi_api_key	""	1795594917
web.search.searchapi_engine	""	1795594917
web.search.serpapi_api_key	""	1795594917
web.search.serpapi_engine	""	1795594917
web.search.bing_search_v7_endpoint	"https://api.bing.microsoft.com/v7.0/search"	1795594917
web.search.bing_search_v7_subscription_key	""	1795594917
web.search.azure_ai_search_api_key	""	1795594917
web.search.azure_ai_search_endpoint	""	1795594917
web.search.azure_ai_search_index_name	""	1795594917
web.search.exa_api_key	""	1795594917
web.search.exa_max_content_length	null	1795594917
web.search.perplexity_api_key	""	1795594917
web.search.perplexity_model	"sonar"	1795594917
web.search.perplexity_search_context_usage	"medium"	1795594917
web.search.perplexity_search_api_url	"https://api.perplexity.ai/search"	1795594917
web.search.microsoft_web_iq_api_base_url	"https://api.microsoft.ai/v3"	1795594917
web.search.microsoft_web_iq_api_key	""	1795594917
web.search.microsoft_web_iq_language	"en"	1795594917
web.search.sougou_api_sid	""	1795594917
web.search.sougou_api_sk	""	1795594917
web.search.tavily_api_key	""	1795594917
web.search.tavily_extract_depth	"basic"	1795594917
web.search.tavily_search_depth	"basic"	1795594917
web.search.staan_api_key	""	1795594917
web.search.staan_market	"en-us"	1795594917
web.search.staan_max_snippets	0	1795594917
web.loader.playwright_ws_url	""	1795594917
web.loader.playwright_timeout	10000	1795594917
web.loader.firecrawl_api_key	""	1795594917
web.loader.firecrawl_api_url	"https://api.firecrawl.dev"	1795594917
web.loader.firecrawl_timeout	""	1795594917
web.search.external_web_search_url	""	1795594917
web.search.external_web_search_api_key	""	1795594917
web.loader.external_web_loader_url	""	1795594917
web.loader.external_web_loader_api_key	""	1795594917
web.search.yandex_web_search_url	""	1795594917
web.search.yandex_web_search_api_key	""	1795594917
web.search.yandex_web_search_config	""	1795594917
web.search.youcom_api_key	""	1795594917
web.search.linkup_api_key	""	1795594917
web.search.linkup_search_params	{}	1795594917
image_generation.enable	false	1795594917
image_generation.engine	"openai"	1795594917
image_generation.model	""	1795594917
image_generation.size	"512x512"	1795594917
image_generation.steps	50	1795594917
image_generation.prompt.enable	true	1795594917
image_generation.default_model	""	1795594917
image_generation.automatic1111.base_url	""	1795594917
image_generation.automatic1111.api_auth	""	1795594917
image_generation.automatic1111.api_params	{}	1795594917
image_generation.comfyui.base_url	""	1795594917
image_generation.comfyui.api_key	""	1795594917
image_generation.comfyui.workflow	"\\n{\\n  \\"3\\": {\\n    \\"inputs\\": {\\n      \\"seed\\": 0,\\n      \\"steps\\": 20,\\n      \\"cfg\\": 8,\\n      \\"sampler_name\\": \\"euler\\",\\n      \\"scheduler\\": \\"normal\\",\\n      \\"denoise\\": 1,\\n      \\"model\\": [\\n        \\"4\\",\\n        0\\n      ],\\n      \\"positive\\": [\\n        \\"6\\",\\n        0\\n      ],\\n      \\"negative\\": [\\n        \\"7\\",\\n        0\\n      ],\\n      \\"latent_image\\": [\\n        \\"5\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"KSampler\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"KSampler\\"\\n    }\\n  },\\n  \\"4\\": {\\n    \\"inputs\\": {\\n      \\"ckpt_name\\": \\"model.safetensors\\"\\n    },\\n    \\"class_type\\": \\"CheckpointLoaderSimple\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Load Checkpoint\\"\\n    }\\n  },\\n  \\"5\\": {\\n    \\"inputs\\": {\\n      \\"width\\": 512,\\n      \\"height\\": 512,\\n      \\"batch_size\\": 1\\n    },\\n    \\"class_type\\": \\"EmptyLatentImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Empty Latent Image\\"\\n    }\\n  },\\n  \\"6\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"Prompt\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"7\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"8\\": {\\n    \\"inputs\\": {\\n      \\"samples\\": [\\n        \\"3\\",\\n        0\\n      ],\\n      \\"vae\\": [\\n        \\"4\\",\\n        2\\n      ]\\n    },\\n    \\"class_type\\": \\"VAEDecode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"VAE Decode\\"\\n    }\\n  },\\n  \\"9\\": {\\n    \\"inputs\\": {\\n      \\"filename_prefix\\": \\"ComfyUI\\",\\n      \\"images\\": [\\n        \\"8\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"SaveImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Save Image\\"\\n    }\\n  }\\n}\\n"	1795594917
image_generation.comfyui.nodes	[]	1795594917
image_generation.openai.api_base_url	"https://api.openai.com/v1"	1795594917
image_generation.openai.api_version	""	1795594917
image_generation.openai.api_key	""	1795594917
image_generation.openai.params	{}	1795594917
image_generation.gemini.api_base_url	""	1795594917
image_generation.gemini.api_key	""	1795594917
image_generation.gemini.endpoint_method	""	1795594917
images.edit.enable	false	1795594917
images.edit.engine	"openai"	1795594917
images.edit.model	""	1795594917
images.edit.default_model	""	1795594917
video_generation.enable	false	1795594917
video_generation.default_model	""	1795594917
images.edit.size	""	1795594917
images.edit.openai.api_base_url	"https://api.openai.com/v1"	1795594917
images.edit.openai.api_version	""	1795594917
images.edit.openai.api_key	""	1795594917
images.edit.gemini.api_base_url	""	1795594917
images.edit.gemini.api_key	""	1795594917
images.edit.comfyui.base_url	""	1795594917
images.edit.comfyui.api_key	""	1795594917
images.edit.comfyui.workflow	""	1795594917
images.edit.comfyui.nodes	[]	1795594917
audio.stt.whisper_model	"base"	1795594917
audio.stt.deepgram.api_key	""	1795594917
audio.stt.openai.api_base_url	"https://api.openai.com/v1"	1795594917
audio.stt.openai.api_key	""	1795594917
audio.stt.openai.api_request_format	"multipart"	1795594917
audio.stt.engine	""	1795594917
audio.stt.model	""	1795594917
audio.stt.supported_content_types	[]	1795594917
audio.stt.allowed_extensions	["mp3","wav","m4a","webm","ogg","flac","mp4","mpga","mpeg"]	1795594917
audio.stt.azure.api_key	""	1795594917
audio.stt.azure.region	""	1795594917
audio.stt.azure.locales	""	1795594917
audio.stt.azure.base_url	""	1795594917
audio.stt.azure.max_speakers	""	1795594917
audio.stt.mistral.api_key	""	1795594917
audio.stt.mistral.api_base_url	"https://api.mistral.ai/v1"	1795594917
audio.stt.mistral.use_chat_completions	false	1795594917
audio.tts.openai.api_base_url	"https://api.openai.com/v1"	1795594917
audio.tts.openai.api_key	""	1795594917
audio.tts.openai.params	{}	1795594917
audio.tts.api_key	""	1795594917
audio.realtime.enabled	false	1795594917
audio.realtime.provider	"openai"	1795594917
audio.realtime.auth_type	"api_key"	1795594917
audio.realtime.openai.api_base_url	"https://api.openai.com/v1"	1795594917
audio.realtime.openai.api_key	""	1795594917
audio.realtime.model	"gpt-realtime-2.1-mini"	1795594917
audio.realtime.voice	"marin"	1795594917
audio.realtime.transcription_model	"gpt-transcribe"	1795594917
audio.realtime.input_params	null	1795594917
audio.realtime.prompt_template	null	1795594917
audio.tts.engine	""	1795594917
audio.tts.model	"tts-1"	1795594917
audio.tts.voice	"alloy"	1795594917
audio.tts.realtime.prompt_template	null	1795594917
audio.tts.split_on	"punctuation"	1795594917
audio.tts.azure.speech_region	""	1795594917
audio.tts.azure.speech_base_url	""	1795594917
audio.tts.azure.speech_output_format	"audio-24khz-160kbitrate-mono-mp3"	1795594917
audio.tts.mistral.api_key	""	1795594917
audio.tts.mistral.api_base_url	"https://api.mistral.ai/v1"	1795594917
ui.enable_password_change_form	true	1795594917
ui.default_locale	""	1795594917
ui.default_models	null	1795594917
ui.default_pinned_models	null	1795594917
ui.visibility	{}	1795594917
ui.prompt_suggestions	null	1795594917
ui.prompt_suggestions_i18n	{}	1795594917
ui.model_order_list	[]	1795594917
models.default_metadata	{}	1795594917
models.default_params	{}	1795594917
subagents.enable	true	1795594917
subagents.background_enabled	false	1795594917
subagents.max_concurrent	null	1795594917
subagents.max_async	null	1795594917
subagents.max_iterations	null	1795594917
subagents.max_output	null	1795594917
subagents.system_prompt	""	1795594917
automations.auth_token_expires_in	"1h"	1795594917
evaluation.arena.enable	false	1795594917
evaluation.arena.models	[]	1795594917
webhook_url	""	1795594917
task.model.default	""	1795594917
task.model.external	""	1795594917
task.model.params	{}	1795594917
chat.context_compaction.model	""	1795594917
chat.context_compaction.enable	false	1795594917
chat.context_compaction.token_threshold	80000	1795594917
chat.context_compaction.token_cap	null	1795594917
chat.context_compaction.retention_percentage	40	1795594917
chat.context_compaction.prompt_template	""	1795594917
chat.visualizations.prompt_template	""	1795594917
chat.tool_permissions.enable	false	1795594917
chat.tool_call_labels.enable	false	1795594917
chat.tool_permissions.auto.enable	false	1795594917
chat.tool_permissions.auto.engine	""	1795594917
chat.tool_permissions.auto.prompt	""	1795594917
chat.tool_permissions.auto.decisions.api_base_url	"https://api.openai.com/v1"	1795594917
chat.tool_permissions.auto.decisions.api_key	""	1795594917
chat.tool_permissions.auto.decisions.model	"gpt-6-luna"	1795594917
chat.tool_permissions.auto.decisions.threshold	0.5	1795594917
chat.tool_search.enable	false	1795594917
chat.tool_search.engine	"bm25"	1795594917
chat.tool_search.decisions.api_base_url	"https://api.openai.com/v1"	1795594917
chat.tool_search.decisions.api_key	""	1795594917
chat.tool_search.decisions.model	"gpt-6-luna"	1795594917
chat.tool_search.decisions.threshold	0.5	1795594917
chat.tool_search.decisions.prompt	""	1795594917
chat.tool_search.defer_threshold	400	1795594917
chat.tool_search.always_loaded	[]	1795594917
chat.tool_search.defer_builtin_tools	true	1795594917
task.title.prompt_template	""	1795594917
task.tags.prompt_template	""	1795594917
task.image.prompt_template	""	1795594917
task.follow_up.prompt_template	""	1795594917
task.follow_up.enable	false	1795594917
task.tags.enable	false	1795594917
task.title.enable	false	1795594917
task.query.search.enable	true	1795594917
task.query.retrieval.enable	true	1795594917
task.query.prompt_template	""	1795594917
task.autocomplete.enable	false	1795594917
task.autocomplete.input_max_length	-1	1795594917
task.autocomplete.prompt_template	""	1795594917
task.voice.prompt_template	""	1795594917
task.voice.prompt.enable	true	1795594917
task.tools.prompt_template	""	1795594917
apps.enable	false	1795594918
ui.i18n	{}	1795594918
user.permissions	{"workspace":{"models":false,"knowledge":false,"prompts":true,"tools":false,"skills":true,"models_import":false,"models_export":false,"models_hidden":false,"prompts_import":false,"prompts_export":false,"tools_import":false,"tools_export":false,"skills_import":false,"skills_export":false},"sharing":{"models":false,"public_models":false,"knowledge":false,"public_knowledge":false,"prompts":false,"public_prompts":false,"tools":false,"public_tools":false,"skills":true,"public_skills":false,"notes":true,"public_notes":false,"folders":false,"public_chats":false,"open_chats":false,"public_calendars":false},"access_grants":{"allow_users":true,"allow_groups":true},"chat":{"controls":true,"valves":true,"system_prompt":true,"params":true,"file_upload":true,"web_upload":true,"delete":false,"delete_message":true,"continue_response":true,"regenerate_response":true,"rate_response":true,"edit":true,"share":true,"export":true,"import":true,"stt":true,"tts":true,"call":true,"multiple_models":true,"temporary":true,"side_chat":false,"temporary_enforced":false},"features":{"api_keys":false,"notes":true,"channels":true,"encrypted_channels":false,"folders":true,"web_search":true,"image_generation":true,"video_generation":false,"code_interpreter":true,"memories":true,"subagents":true,"automations":false,"calendar":true,"webhooks":false},"settings":{"interface":true}}	1795594918
ui.banners	[{"i18n":null,"id":"upgrade-banner","type":"info","title":"Maintenance","content":"Maintenance on Sunday","dismissible":true,"timestamp":1700000000}]	1795594918
auth.session_expiry	"90d"	1795594917
ldap.enable	false	1795594917
ldap.server.label	"LDAP Server"	1795594917
ldap.server.host	"localhost"	1795594917
ldap.server.port	389	1795594917
ldap.server.attribute_for_mail	"mail"	1795594917
ldap.server.default_email_domain	""	1795594917
ldap.server.attribute_for_username	"uid"	1795594917
ldap.server.app_dn	""	1795594917
ldap.server.app_password	""	1795594917
ldap.server.users_dn	""	1795594917
ldap.server.search_filter	""	1795594917
ldap.server.use_tls	true	1795594917
ldap.server.ca_cert_file	""	1795594917
ldap.server.validate_cert	true	1795594917
ldap.server.ciphers	"ALL"	1795594917
ldap.group.enable_management	false	1795594917
ldap.group.enable_creation	false	1795594917
ldap.server.attribute_for_groups	"memberOf"	1795594917
images.connections	[]	1795594917
ui.enable_signup	false	1795594918
auth.admin.email	null	1795594918
auth.admin.show	true	1795594918
auth.api_key.allowed_endpoints	""	1795594918
auth.api_key.endpoint_restrictions	false	1795594918
auth.enable_api_keys	false	1795594918
auth.jwt_expiry	"4w"	1795594918
auth.mfa.allow_oauth_bypass	false	1795594918
auth.mfa.allow_trusted_header_bypass	false	1795594918
auth.mfa.enable	false	1795594918
automations.enable	true	1795594918
automations.max_count	""	1795594918
automations.min_interval	""	1795594918
calendar.enable	true	1795594918
channels.enable	true	1795594918
channels.encryption.enable	false	1795594918
channels.model_response_mode	"thread"	1795594918
chats.view_max_chars	null	1795594918
comments.enable	false	1795594918
folders.enable	true	1795594918
folders.max_file_count	""	1795594918
memories.enable	true	1795594918
memories.system_context.enable	true	1795594918
notes.enable	true	1795594918
notifications.enable	true	1795594918
skills.content_max_chars	null	1795594918
skills.lazy_loading.enable	false	1795594918
skills.preview_max_chars	null	1795594918
ui.default_group_id	""	1795594918
ui.default_interface_settings	{}	1795594918
ui.default_user_role	"user"	1795594918
ui.enable_community_sharing	false	1795594918
ui.enable_login_form	true	1795594918
ui.enable_message_rating	true	1795594918
ui.enable_user_webhooks	false	1795594918
ui.pending_user_overlay_content	""	1795594918
ui.pending_user_overlay_title	""	1795594918
ui.watermark	""	1795594918
users.enable_status	true	1795594918
webui.url	"https://chat.example.com"	1795594918
\.


--
-- Data for Name: config_old; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_old (id, data, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (collection_name, name, title, filename, content, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, user_id, version, type, data, meta, snapshot, created_at, updated_at) FROM stdin;
da1b27e6-5462-40aa-a75c-706001e73912	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	0	rating	{"rating":1,"model_id":"mock-model","sibling_model_ids":null,"reason":"Accurate","comment":null}	{"chat_id":"4bb0e1b1-3e82-401c-ae64-f5cbeba56ee6","message_id":"bed89f31-1737-4581-b28f-078bc65d6274"}	{"chat":{}}	1795594923	1795594923
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, user_id, filename, meta, created_at, hash, data, updated_at, path) FROM stdin;
2db66796-5178-4156-ab6c-7d550999c66f	b6eefad0-3d9a-4207-8db1-ab436466c206	handbook.txt	{"name":"handbook.txt","content_type":"text/plain","size":72,"file_hash":"51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb","data":{},"collection_name":"9f4537ad-8839-428e-8262-1510a4254caf"}	1795594920	51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb	{"status":"completed","content":"The upgrade handbook says the lighthouse key hangs behind the blue door.","error":null}	1795594920	/home/tmp/seed0134-tmp/seed-v0.13.4-8_eb__1t/data/uploads/2db66796-5178-4156-ab6c-7d550999c66f_handbook.txt
4a55665b-dfff-4b79-aab1-b5670dd76e3d	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	packing.txt	{"name":"packing.txt","content_type":"text/plain","size":59,"file_hash":"85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a","data":{},"collection_name":"file-4a55665b-dfff-4b79-aab1-b5670dd76e3d"}	1795594920	85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a	{"status":"completed","content":"Packing list: umbrella, passport, a very old map of Vienna.","error":null}	1795594920	/home/tmp/seed0134-tmp/seed-v0.13.4-8_eb__1t/data/uploads/4a55665b-dfff-4b79-aab1-b5670dd76e3d_packing.txt
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder (id, parent_id, user_id, name, items, meta, is_expanded, created_at, updated_at, data) FROM stdin;
32e65f0a-b3e9-4109-a2ec-19d3d264eac6	\N	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Trips	null	null	f	1795594920	1795594920	null
06ea4d6d-f53e-4076-ad16-8d3a81a340a4	32e65f0a-b3e9-4109-a2ec-19d3d264eac6	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Vienna	null	null	f	1795594920	1795594920	null
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function (id, user_id, name, type, content, meta, valves, is_active, is_global, updated_at, created_at, version_id) FROM stdin;
shout_filter	b6eefad0-3d9a-4207-8db1-ab436466c206	Shout filter	filter	"""\ntitle: Shout filter\n"""\n\nfrom pydantic import BaseModel\n\n\nclass Filter:\n    class Valves(BaseModel):\n        suffix: str = "!"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def inlet(self, body: dict) -> dict:\n        return body\n	{"description":"Adds emphasis","manifest":{"title":"Shout filter"},"toggle":false}	{"suffix":"!!!"}	t	t	1795594918	1795594918	77094794-2d80-4c46-b252-45c7d751fbe2
\.


--
-- Data for Name: function_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function_history (id, function_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
77094794-2d80-4c46-b252-45c7d751fbe2	shout_filter	\N	{"name":"Shout filter","content":"\\"\\"\\"\\ntitle: Shout filter\\n\\"\\"\\"\\n\\nfrom pydantic import BaseModel\\n\\n\\nclass Filter:\\n    class Valves(BaseModel):\\n        suffix: str = \\"!\\"\\n\\n    def __init__(self):\\n        self.valves = self.Valves()\\n\\n    def inlet(self, body: dict) -> dict:\\n        return body\\n","meta":{"description":"Adds emphasis"}}	b6eefad0-3d9a-4207-8db1-ab436466c206	\N	1795594918
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."group" (id, user_id, name, description, data, meta, permissions, created_at, updated_at, parent_group_id) FROM stdin;
445127d3-a506-4ee4-a2a9-618f26834f44	b6eefad0-3d9a-4207-8db1-ab436466c206	Research	People who read the handbook	{"config":{"share":"members"}}	\N	{"workspace":{"models":true}}	1795594918	1795594918	\N
\.


--
-- Data for Name: group_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_member (id, group_id, user_id, created_at, updated_at) FROM stdin;
c17d61b9-a78f-4972-ad5a-41a7d43561e4	445127d3-a506-4ee4-a2a9-618f26834f44	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	1795594918	1795594918
8dfe6b50-ae41-4b0f-9cb0-4121db7f8309	445127d3-a506-4ee4-a2a9-618f26834f44	00b0add8-dc69-4860-a112-13e304932661	1795594918	1795594918
\.


--
-- Data for Name: knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge (id, user_id, name, description, meta, created_at, updated_at, data) FROM stdin;
9f4537ad-8839-428e-8262-1510a4254caf	b6eefad0-3d9a-4207-8db1-ab436466c206	Handbook	Where things are	null	1795594920	1795594920	\N
\.


--
-- Data for Name: knowledge_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_directory (id, knowledge_id, parent_id, name, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_file (id, user_id, knowledge_id, file_id, created_at, updated_at, directory_id) FROM stdin;
88586355-abde-4b54-a3fb-2efbb4a125aa	b6eefad0-3d9a-4207-8db1-ab436466c206	9f4537ad-8839-428e-8262-1510a4254caf	2db66796-5178-4156-ab6c-7d550999c66f	1795594920	1795594920	\N
\.


--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.memory (id, user_id, content, updated_at, created_at, type, path, meta) FROM stdin;
6002719a-1b37-440d-b91b-bd821b5d740f	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Alice is allergic to peanuts.	1795594929	1795594929	context	\N	{"created_by":"manual"}
12179782-b14b-4e4c-a4c4-bb6a0c160c59	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Alice prefers window seats.	1795594929	1795594929	context	\N	{"created_by":"manual"}
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (id, user_id, channel_id, content, data, meta, created_at, updated_at, parent_id, reply_to_id, is_pinned, pinned_at, pinned_by, app_id) FROM stdin;
71c7a169-2347-4e47-b5e1-a4ce6389e663	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	2ca23e36-692b-43af-9884-50096fb1e2b7	Who has the lighthouse key?	null	null	1795594929168486010	1795594929168486010	\N	\N	f	\N	\N	\N
7ea701c0-8530-440d-8646-efd2b8f316d2	00b0add8-dc69-4860-a112-13e304932661	2ca23e36-692b-43af-9884-50096fb1e2b7	Behind the blue door.	null	null	1795594929231584484	1795594929231584484	71c7a169-2347-4e47-b5e1-a4ce6389e663	\N	f	\N	\N	\N
\.


--
-- Data for Name: message_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reaction (id, user_id, message_id, name, created_at) FROM stdin;
c2ae0dde-822c-4057-b352-d98f96bb7bee	00b0add8-dc69-4860-a112-13e304932661	71c7a169-2347-4e47-b5e1-a4ce6389e663	thumbsup	1795594929307563061
\.


--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model (id, user_id, base_model_id, name, params, meta, updated_at, created_at, is_active, version_id) FROM stdin;
research-assistant	b6eefad0-3d9a-4207-8db1-ab436466c206	mock-model	Research assistant	{"system":"You answer from the handbook.","temperature":0.2}	{"profile_image_url":null,"background_image_url":null,"description":"Answers from the handbook","i18n":null,"capabilities":null,"knowledge":null,"subagents":null,"voice":null,"voice_avatar":null}	1795594918	1795594918	t	4f165a70-490d-41b2-bfaf-ef1993fd9e14
\.


--
-- Data for Name: model_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_history (id, model_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
4f165a70-490d-41b2-bfaf-ef1993fd9e14	research-assistant	\N	{"name":"Research assistant","base_model_id":"mock-model","params":{"system":"You answer from the handbook.","temperature":0.2},"meta":{"profile_image_url":null,"background_image_url":null,"description":"Answers from the handbook","i18n":null,"capabilities":null,"knowledge":null,"subagents":null,"voice":null,"voice_avatar":null}}	b6eefad0-3d9a-4207-8db1-ab436466c206	\N	1795594918
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (id, user_id, title, data, meta, created_at, updated_at) FROM stdin;
02b90ebe-de12-4af8-9413-e175e0eb74c2	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Groceries	{"content":{"md":"# Groceries\\n\\n- apples\\n- *dark* chocolate","html":"","json":null},"pages":[{"id":"main","title":"Groceries","content":{"md":"# Groceries\\n\\n- apples\\n- *dark* chocolate","html":"","json":null},"versions":[],"revision":0,"generation":0,"parent_id":null}],"pages_revision":0,"search_text":"Groceries\\n# Groceries\\n\\n- apples\\n- *dark* chocolate"}	null	1795594929052381653	1795594929052382134
\.


--
-- Data for Name: notification; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification (id, user_id, event_type, event_key, actor_type, actor_id, resource_type, resource_id, object_type, object_id, data, seen_at, read_at, created_at, updated_at) FROM stdin;
4a99f733-fcb4-40b9-b9eb-0f3481316397	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	channel.replied	message:7ea701c0-8530-440d-8646-efd2b8f316d2:created	user	00b0add8-dc69-4860-a112-13e304932661	channel	2ca23e36-692b-43af-9884-50096fb1e2b7	message	7ea701c0-8530-440d-8646-efd2b8f316d2	{}	\N	\N	1795594929252469902	1795594929252469902
\.


--
-- Data for Name: oauth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_session (id, user_id, provider, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pinned_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_note (id, user_id, note_id, created_at) FROM stdin;
\.


--
-- Data for Name: prompt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt (id, command, user_id, name, content, data, meta, is_active, version_id, tags, created_at, updated_at) FROM stdin;
b6d6abd3-6686-4858-8714-735488a3786d	summarize	b6eefad0-3d9a-4207-8db1-ab436466c206	Summarize	Summarize the following text in three bullet points.	{}	{}	t	248fb069-3ae9-4b54-b760-1077eb0d4687	[]	1795594918	1795594918
499df8aa-ab36-47eb-b347-5cc1c7ffed79	alice-draft	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Alice's draft	Draft a polite reply to this email.	{}	{}	t	ccdd9948-4467-4495-9fb3-bb2d7c17a1c7	[]	1795594919	1795594919
\.


--
-- Data for Name: prompt_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt_history (id, prompt_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
248fb069-3ae9-4b54-b760-1077eb0d4687	b6d6abd3-6686-4858-8714-735488a3786d	\N	{"name":"Summarize","content":"Summarize the following text in three bullet points.","command":"summarize","data":{},"meta":{},"tags":[],"access_grants":[{"id":"79be4c44-2612-4114-bf61-fc168ea0508b","resource_type":"prompt","resource_id":"b6d6abd3-6686-4858-8714-735488a3786d","principal_type":"group","principal_id":"445127d3-a506-4ee4-a2a9-618f26834f44","permission":"read","created_at":1795594918}]}	b6eefad0-3d9a-4207-8db1-ab436466c206	Initial version	1795594918
ccdd9948-4467-4495-9fb3-bb2d7c17a1c7	499df8aa-ab36-47eb-b347-5cc1c7ffed79	\N	{"name":"Alice's draft","content":"Draft a polite reply to this email.","command":"alice-draft","data":{},"meta":{},"tags":[],"access_grants":[]}	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Initial version	1795594919
\.


--
-- Data for Name: shared_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shared_chat (id, chat_id, user_id, title, chat, created_at, updated_at) FROM stdin;
9c83a7b5-31a5-425c-9257-fa0761a585b8	5b8d58ea-c644-4061-af7e-b77a67f60e0a	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Packing for Vienna	{"title":"Packing for Vienna","models":["mock-model"],"history":{"messages":{"u1-0000-4000-8000-000000000000":{"id":"u1-0000-4000-8000-000000000000","parentId":null,"childrenIds":["a1-0000-4000-8000-000000000000","a1b-0000-4000-8000-000000000000"],"role":"user","content":"What should I pack for Vienna?","files":[{"type":"file","id":"4a55665b-dfff-4b79-aab1-b5670dd76e3d","name":"packing.txt","status":"uploaded"}],"timestamp":1795594920,"models":["mock-model"],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"a1-0000-4000-8000-000000000000":{"id":"a1-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"Pack an umbrella.","model":"mock-model","done":true,"timestamp":1795594921,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"},"a1b-0000-4000-8000-000000000000":{"id":"a1b-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":["u2-0000-4000-8000-000000000000"],"role":"assistant","content":"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.","model":"mock-model","done":true,"timestamp":1795594922,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"},"u2-0000-4000-8000-000000000000":{"id":"u2-0000-4000-8000-000000000000","parentId":"a1b-0000-4000-8000-000000000000","childrenIds":["a2-0000-4000-8000-000000000000"],"role":"user","content":"And for the evening?","timestamp":1795594923,"models":["mock-model"],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"a2-0000-4000-8000-000000000000":{"id":"a2-0000-4000-8000-000000000000","parentId":"u2-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"A light jacket.","model":"mock-model","done":true,"timestamp":1795594924,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"}},"currentId":"a2-0000-4000-8000-000000000000"},"messages":[{"id":"u1-0000-4000-8000-000000000000","parentId":null,"childrenIds":["a1-0000-4000-8000-000000000000","a1b-0000-4000-8000-000000000000"],"role":"user","content":"What should I pack for Vienna?","files":[{"type":"file","id":"4a55665b-dfff-4b79-aab1-b5670dd76e3d","name":"packing.txt","status":"uploaded"}],"timestamp":1795594920,"models":["mock-model"],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},{"id":"a1b-0000-4000-8000-000000000000","parentId":"u1-0000-4000-8000-000000000000","childrenIds":["u2-0000-4000-8000-000000000000"],"role":"assistant","content":"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.","model":"mock-model","done":true,"timestamp":1795594922,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"},{"id":"u2-0000-4000-8000-000000000000","parentId":"a1b-0000-4000-8000-000000000000","childrenIds":["a2-0000-4000-8000-000000000000"],"role":"user","content":"And for the evening?","timestamp":1795594923,"models":["mock-model"],"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},{"id":"a2-0000-4000-8000-000000000000","parentId":"u2-0000-4000-8000-000000000000","childrenIds":[],"role":"assistant","content":"A light jacket.","model":"mock-model","done":true,"timestamp":1795594924,"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55"}],"files":[{"type":"file","id":"4a55665b-dfff-4b79-aab1-b5670dd76e3d","name":"packing.txt","status":"uploaded"}],"params":{},"share_mode":null}	1795594920	1795594920
5209511f-72ab-45d2-a966-acb2b73fcb23	8960f128-d8dc-4e34-84b7-2d2c7dfa8472	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Weather in Graz	{"id":"8960f128-d8dc-4e34-84b7-2d2c7dfa8472","title":"Weather in Graz","models":["mock-model"],"terminal_id":null,"working_directory":"","history":{"currentId":"8d83861a-d4f2-4ae2-b9fb-dfc15158f172","messages":{"627a5423-0b58-4cad-a7ac-4a2b440c7201":{"id":"627a5423-0b58-4cad-a7ac-4a2b440c7201","parentId":null,"childrenIds":["8d83861a-d4f2-4ae2-b9fb-dfc15158f172"],"role":"user","user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","content":"What is the weather in Graz?","models":["mock-model"],"timestamp":1795594923,"user":{"id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","name":"Alice Author"}},"8d83861a-d4f2-4ae2-b9fb-dfc15158f172":{"id":"8d83861a-d4f2-4ae2-b9fb-dfc15158f172","parentId":"627a5423-0b58-4cad-a7ac-4a2b440c7201","childrenIds":[],"role":"assistant","content":"It is sunny in Graz, so leave the umbrella at home.","done":true,"model":"mock-model","timestamp":1795594923,"modelIdx":0,"meta":{"task_id":"ddb1bbd3-60d1-4dae-aafa-ba766ea662ff","response_started_at":1795594923.251919,"response_ended_at":1795594924.0969543},"user_id":"2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55","output":[{"type":"function_call","id":"fc_64f116a1c96e47c9be3c3044","call_id":"fc_64f116a1c96e47c9be3c3044","name":"list_available_skills","hidden":true,"arguments":"{}","status":"completed"},{"type":"function_call_output","id":"fco_67b2ff718b404205b205158b","call_id":"fc_64f116a1c96e47c9be3c3044","output":[{"type":"input_text","text":"<available_skills>\\n<skill>\\n<id>dave-notes</id>\\n<name>Dave's notes</name>\\n<description>Left behind.</description>\\n</skill>\\n<skill>\\n<id>house-style</id>\\n<name>House style</name>\\n<description>How every answer is formatted.</description>\\n</skill>\\n<skill>\\n<id>trip-planner</id>\\n<name>Trip planner</name>\\n<description>Plans multi-city trips by train.</description>\\n</skill>\\n<skill>\\n<id>uebersetzer</id>\\n<name>Übersetzer 日本語 🚀</name>\\n<description></description>\\n</skill>\\n</available_skills>"}],"status":"completed"},{"type":"function_call","id":"call_1","call_id":"call_1","name":"get_weather","arguments":"{\\"city\\": \\"Graz\\"}","status":"completed","started_at":1795594923.6778452,"ended_at":1795594923.679571,"duration":0.0017249950033146888,"tool_id":"weather_tool"},{"type":"function_call_output","id":"fco_1bde288db1e649a5bf12acdd","call_id":"call_1","output":[{"type":"input_text","text":"Sunny in Graz"}],"status":"completed"},{"type":"reasoning","id":"r_47d5cc30be8c4d13bb54abcb","status":"completed","start_tag":"<think>","end_tag":"</think>","attributes":{"type":"reasoning_content"},"content":[{"type":"output_text","text":"The weather tool says sunny, so no umbrella is needed."}],"summary":null,"started_at":1795594924.0948687,"ended_at":1795594924.0949998,"duration":0},{"type":"message","id":"msg_67c8d74b0a1b47c28107bb74","status":"completed","role":"assistant","content":[{"type":"output_text","text":"It is sunny in Graz, so leave the umbrella at home."}]}],"usage":{"incomplete":true,"input_tokens":42,"output_tokens":7,"total_tokens":49,"prompt_tokens":42,"completion_tokens":7}}}},"messages":[{"role":"user","content":"What is the weather in Graz?"}],"files":[],"tags":[],"timestamp":1795594923233,"share_mode":"continue"}	1795594929	1795594929
\.


--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill (id, user_id, name, description, content, meta, is_active, updated_at, created_at, version_id, data) FROM stdin;
trip-planner	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Trip planner	Plans multi-city trips by train.	---\nname: trip-planner\ndescription: Plans multi-city trips by train.\n---\n\n# Trip planner\n\n1. Ask for the cities and the dates.\n2. Prefer night trains over flights.\n3. Keep every transfer above 40 minutes.\n4. Name the platform for every departure.\n	{"i18n":null,"tags":["travel"]}	t	1795594920	1795594919	dcc29977-01df-4391-b9bf-543789ee7d74	{"files":[{"path":"SKILL.md","content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n4. Name the platform for every departure.\\n"}]}
uebersetzer	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Übersetzer 日本語 🚀		# Übersetzer 🌍\r\n\r\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\r\n\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \r\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\r\n	{"i18n":null,"tags":[]}	t	1795594920	1795594920	b87d8ab3-559e-4c86-adce-ae19699bfb44	{"files":[{"path":"SKILL.md","content":"# Übersetzer 🌍\\r\\n\\r\\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\\r\\n\\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \\r\\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\\r\\n"}]}
old-habits	00b0add8-dc69-4860-a112-13e304932661	Old habits	\N	Answer in Latin.	{"i18n":null,"tags":[]}	f	1795594920	1795594920	10d7c31f-42a1-4dda-a5dc-9cd7fd4d3556	{"files":[{"path":"SKILL.md","content":"Answer in Latin."}]}
house-style	b6eefad0-3d9a-4207-8db1-ab436466c206	House style	How every answer is formatted.	Use sentence case headings and no exclamation marks.	{"i18n":null,"tags":[]}	t	1795594920	1795594920	74953fc2-1d06-453a-8cd4-ae2e30413a96	{"files":[{"path":"SKILL.md","content":"Use sentence case headings and no exclamation marks."}]}
dave-notes	d57b689e-5c86-4274-b616-1bdc96f762fd	Dave's notes	Left behind.	Hand over to the next shift at six.	{"i18n":null,"tags":[]}	t	1795594920	1795594920	65e55957-30a7-4c95-92f4-19de588b8927	{"files":[{"path":"SKILL.md","content":"Hand over to the next shift at six."}]}
\.


--
-- Data for Name: skill_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill_history (id, skill_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
d53f0622-856b-4cb0-83f4-ef0cfdf6f0fc	trip-planner	\N	{"name":"Trip planner","description":"Plans multi-city trips by train.","meta":{"i18n":null,"tags":["travel"]},"content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n","data":{"files":[{"path":"SKILL.md","content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n"}]}}	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	\N	1795594919
dcc29977-01df-4391-b9bf-543789ee7d74	trip-planner	d53f0622-856b-4cb0-83f4-ef0cfdf6f0fc	{"name":"Trip planner","description":"Plans multi-city trips by train.","meta":{"i18n":null,"tags":["travel"]},"data":{"files":[{"path":"SKILL.md","content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n4. Name the platform for every departure.\\n"}]},"content":"---\\nname: trip-planner\\ndescription: Plans multi-city trips by train.\\n---\\n\\n# Trip planner\\n\\n1. Ask for the cities and the dates.\\n2. Prefer night trains over flights.\\n3. Keep every transfer above 40 minutes.\\n4. Name the platform for every departure.\\n"}	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	\N	1795594920
b87d8ab3-559e-4c86-adce-ae19699bfb44	uebersetzer	\N	{"name":"Übersetzer 日本語 🚀","description":"","meta":{"i18n":null,"tags":[]},"content":"# Übersetzer 🌍\\r\\n\\r\\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\\r\\n\\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \\r\\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\\r\\n","data":{"files":[{"path":"SKILL.md","content":"# Übersetzer 🌍\\r\\n\\r\\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\\r\\n\\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \\r\\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\\r\\n"}]}}	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	\N	1795594920
10d7c31f-42a1-4dda-a5dc-9cd7fd4d3556	old-habits	\N	{"name":"Old habits","description":null,"meta":{"i18n":null,"tags":[]},"content":"Answer in Latin.","data":{"files":[{"path":"SKILL.md","content":"Answer in Latin."}]}}	00b0add8-dc69-4860-a112-13e304932661	\N	1795594920
74953fc2-1d06-453a-8cd4-ae2e30413a96	house-style	\N	{"name":"House style","description":"How every answer is formatted.","meta":{"i18n":null,"tags":[]},"content":"Use sentence case headings and no exclamation marks.","data":{"files":[{"path":"SKILL.md","content":"Use sentence case headings and no exclamation marks."}]}}	b6eefad0-3d9a-4207-8db1-ab436466c206	\N	1795594920
65e55957-30a7-4c95-92f4-19de588b8927	dave-notes	\N	{"name":"Dave's notes","description":"Left behind.","meta":{"i18n":null,"tags":[]},"content":"Hand over to the next shift at six.","data":{"files":[{"path":"SKILL.md","content":"Hand over to the next shift at six."}]}}	d57b689e-5c86-4274-b616-1bdc96f762fd	\N	1795594920
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tag (id, name, user_id, meta) FROM stdin;
travel	travel	2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	\N
\.


--
-- Data for Name: tool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool (id, user_id, name, content, specs, meta, valves, updated_at, created_at, version_id, is_active) FROM stdin;
weather_tool	b6eefad0-3d9a-4207-8db1-ab436466c206	Weather	"""\ntitle: Weather\n"""\n\n\nfrom pydantic import BaseModel\n\n\nclass Tools:\n    class Valves(BaseModel):\n        units: str = "metric"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def get_weather(self, city: str) -> str:\n        """Report the weather in a city."""\n        return f"Sunny in {city}"\n	[{"name":"get_weather","description":"Report the weather in a city.","parameters":{"properties":{"city":{"type":"string"}},"required":["city"],"type":"object"}}]	{"i18n":null,"description":"Weather lookups","manifest":{"title":"Weather"},"has_user_valves":false}	\N	1795594918	1795594918	11e6e031-f709-4006-91ac-ef094c7a3df8	t
\.


--
-- Data for Name: tool_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool_history (id, tool_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
11e6e031-f709-4006-91ac-ef094c7a3df8	weather_tool	\N	{"name":"Weather","content":"\\"\\"\\"\\ntitle: Weather\\n\\"\\"\\"\\n\\n\\nfrom pydantic import BaseModel\\n\\n\\nclass Tools:\\n    class Valves(BaseModel):\\n        units: str = \\"metric\\"\\n\\n    def __init__(self):\\n        self.valves = self.Valves()\\n\\n    def get_weather(self, city: str) -> str:\\n        \\"\\"\\"Report the weather in a city.\\"\\"\\"\\n        return f\\"Sunny in {city}\\"\\n","meta":{"description":"Weather lookups"}}	b6eefad0-3d9a-4207-8db1-ab436466c206	\N	1795594918
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, role, profile_image_url, last_active_at, updated_at, created_at, settings, info, username, bio, gender, date_of_birth, profile_banner_image_url, timezone, presence_state, status_emoji, status_message, status_expires_at, oauth, scim, variables) FROM stdin;
b6eefad0-3d9a-4207-8db1-ab436466c206	Ada Admin	admin@example.com	admin	/user.png	1795594918	1795594918	1795594918	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
2a252931-2f6c-45f3-9f7d-fb47c6b5eda1	Carol Outsider	carol@example.com	user	/user.png	1795594918	1795594918	1795594918	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
2799a0e6-c7b3-480c-9bb0-1d6f2c3d9d55	Alice Author	alice@example.com	user	/user.png	1795594918	1795594918	1795594918	{"ui":{"theme":"dark","chatBubble":false,"notesSeen":3}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
00b0add8-dc69-4860-a112-13e304932661	Bob Reader	bob@example.com	user	/user.png	1795594918	1795594918	1795594918	{"ui":{"models":["research-assistant"]}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
\.


--
-- Name: config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_id_seq', 1, false);


--
-- Name: access_grant access_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT access_grant_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_key UNIQUE (key);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: app app_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app
    ADD CONSTRAINT app_pkey PRIMARY KEY (id);


--
-- Name: app app_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app
    ADD CONSTRAINT app_slug_key UNIQUE (slug);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: auth_session auth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_session
    ADD CONSTRAINT auth_session_pkey PRIMARY KEY (id);


--
-- Name: automation automation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation
    ADD CONSTRAINT automation_pkey PRIMARY KEY (id);


--
-- Name: automation_run automation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_run
    ADD CONSTRAINT automation_run_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendee calendar_event_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT calendar_event_attendee_pkey PRIMARY KEY (id);


--
-- Name: calendar_event calendar_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event
    ADD CONSTRAINT calendar_event_pkey PRIMARY KEY (id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (id);


--
-- Name: channel_file channel_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_pkey PRIMARY KEY (id);


--
-- Name: channel_member channel_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT channel_member_pkey PRIMARY KEY (id);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_webhook channel_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_pkey PRIMARY KEY (id);


--
-- Name: chat_file chat_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: chat chat_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_share_id_key UNIQUE (share_id);


--
-- Name: chat_view_state chat_view_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_view_state
    ADD CONSTRAINT chat_view_state_pkey PRIMARY KEY (user_id, chat_id);


--
-- Name: chatidtag chatidtag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chatidtag
    ADD CONSTRAINT chatidtag_pkey PRIMARY KEY (id);


--
-- Name: comment comment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment
    ADD CONSTRAINT comment_pkey PRIMARY KEY (id);


--
-- Name: comment_reaction comment_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_reaction
    ADD CONSTRAINT comment_reaction_pkey PRIMARY KEY (id);


--
-- Name: config_old config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey1 PRIMARY KEY (key);


--
-- Name: document document_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_name_key UNIQUE (name);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (collection_name);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id, user_id);


--
-- Name: function_history function_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function_history
    ADD CONSTRAINT function_history_pkey PRIMARY KEY (id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: group_member group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_pkey PRIMARY KEY (id);


--
-- Name: group group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pkey PRIMARY KEY (id);


--
-- Name: knowledge_directory knowledge_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_pkey PRIMARY KEY (id);


--
-- Name: knowledge_file knowledge_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_pkey PRIMARY KEY (id);


--
-- Name: knowledge knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge
    ADD CONSTRAINT knowledge_pkey PRIMARY KEY (id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: message_reaction message_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reaction
    ADD CONSTRAINT message_reaction_pkey PRIMARY KEY (id);


--
-- Name: model_history model_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_history
    ADD CONSTRAINT model_history_pkey PRIMARY KEY (id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: notification notification_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT notification_pkey PRIMARY KEY (id);


--
-- Name: oauth_session oauth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_pkey PRIMARY KEY (id);


--
-- Name: pinned_note pinned_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_pkey PRIMARY KEY (id);


--
-- Name: tag pk_id_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_id_user_id PRIMARY KEY (id, user_id);


--
-- Name: prompt_history prompt_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt_history
    ADD CONSTRAINT prompt_history_pkey PRIMARY KEY (id);


--
-- Name: prompt prompt_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt
    ADD CONSTRAINT prompt_new_pkey PRIMARY KEY (id);


--
-- Name: shared_chat shared_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_pkey PRIMARY KEY (id);


--
-- Name: skill_history skill_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill_history
    ADD CONSTRAINT skill_history_pkey PRIMARY KEY (id);


--
-- Name: skill skill_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_name_key UNIQUE (name);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- Name: tool_history tool_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool_history
    ADD CONSTRAINT tool_history_pkey PRIMARY KEY (id);


--
-- Name: tool tool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool
    ADD CONSTRAINT tool_pkey PRIMARY KEY (id);


--
-- Name: access_grant uq_access_grant_grant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT uq_access_grant_grant UNIQUE (resource_type, resource_id, principal_type, principal_id, permission);


--
-- Name: channel_file uq_channel_file_channel_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT uq_channel_file_channel_file UNIQUE (channel_id, file_id);


--
-- Name: channel_member uq_channel_member_app; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT uq_channel_member_app UNIQUE (channel_id, app_id);


--
-- Name: chat_file uq_chat_file_chat_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT uq_chat_file_chat_file UNIQUE (chat_id, file_id);


--
-- Name: comment_reaction uq_comment_reaction; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.comment_reaction
    ADD CONSTRAINT uq_comment_reaction UNIQUE (comment_id, user_id, name);


--
-- Name: calendar_event_attendee uq_event_attendee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT uq_event_attendee UNIQUE (event_id, user_id);


--
-- Name: group_member uq_group_member_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT uq_group_member_group_user UNIQUE (group_id, user_id);


--
-- Name: knowledge_directory uq_knowledge_directory_knowledge_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT uq_knowledge_directory_knowledge_parent_name UNIQUE (knowledge_id, parent_id, name);


--
-- Name: knowledge_file uq_knowledge_file_knowledge_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT uq_knowledge_file_knowledge_file UNIQUE (knowledge_id, file_id);


--
-- Name: notification uq_notification_occurrence; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification
    ADD CONSTRAINT uq_notification_occurrence UNIQUE (user_id, event_key);


--
-- Name: pinned_note uq_pinned_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT uq_pinned_note UNIQUE (user_id, note_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: chat_message_chat_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_parent_idx ON public.chat_message USING btree (chat_id, parent_id);


--
-- Name: chat_message_chat_role_done_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_role_done_idx ON public.chat_message USING btree (chat_id, role, done);


--
-- Name: chat_message_model_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_model_created_idx ON public.chat_message USING btree (model_id, created_at);


--
-- Name: chat_message_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_user_created_idx ON public.chat_message USING btree (user_id, created_at);


--
-- Name: file_pending_knowledge_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX file_pending_knowledge_idx ON public.file USING btree ((((meta -> 'data'::text) ->> 'knowledge_id'::text))) WHERE ((data ->> 'status'::text) = ANY (ARRAY['pending'::text, 'processing'::text]));


--
-- Name: folder_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_idx ON public.chat USING btree (folder_id);


--
-- Name: folder_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_user_id_idx ON public.chat USING btree (folder_id, user_id);


--
-- Name: idx_access_grant_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_principal ON public.access_grant USING btree (principal_type, principal_id);


--
-- Name: idx_access_grant_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_resource ON public.access_grant USING btree (resource_type, resource_id);


--
-- Name: idx_auth_session_expires; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_session_expires ON public.auth_session USING btree (expires_at);


--
-- Name: idx_auth_session_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_session_user ON public.auth_session USING btree (user_id);


--
-- Name: idx_oauth_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_expires_at ON public.oauth_session USING btree (expires_at);


--
-- Name: idx_oauth_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_id ON public.oauth_session USING btree (user_id);


--
-- Name: idx_oauth_session_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_provider ON public.oauth_session USING btree (user_id, provider);


--
-- Name: idx_skill_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_updated_at ON public.skill USING btree (updated_at);


--
-- Name: idx_skill_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_user_id ON public.skill USING btree (user_id);


--
-- Name: is_global_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX is_global_idx ON public.function USING btree (is_global);


--
-- Name: ix_automation_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_next_run ON public.automation USING btree (next_run_at);


--
-- Name: ix_automation_run_automation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_run_automation_id ON public.automation_run USING btree (automation_id);


--
-- Name: ix_automation_user_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_user_folder ON public.automation USING btree (user_id, folder_id);


--
-- Name: ix_calendar_event_attendee_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_attendee_user ON public.calendar_event_attendee USING btree (user_id, status);


--
-- Name: ix_calendar_event_calendar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_calendar ON public.calendar_event USING btree (calendar_id, start_at);


--
-- Name: ix_calendar_event_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_user_date ON public.calendar_event USING btree (user_id, start_at);


--
-- Name: ix_calendar_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_user ON public.calendar USING btree (user_id);


--
-- Name: ix_channel_file_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_channel_id ON public.channel_file USING btree (channel_id);


--
-- Name: ix_channel_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_file_id ON public.channel_file USING btree (file_id);


--
-- Name: ix_channel_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_user_id ON public.channel_file USING btree (user_id);


--
-- Name: ix_channel_member_app_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_member_app_active ON public.channel_member USING btree (app_id, is_active);


--
-- Name: ix_chat_file_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_chat_id ON public.chat_file USING btree (chat_id);


--
-- Name: ix_chat_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_file_id ON public.chat_file USING btree (file_id);


--
-- Name: ix_chat_file_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_message_id ON public.chat_file USING btree (message_id);


--
-- Name: ix_chat_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_user_id ON public.chat_file USING btree (user_id);


--
-- Name: ix_chat_message_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_chat_id ON public.chat_message USING btree (chat_id);


--
-- Name: ix_chat_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_created_at ON public.chat_message USING btree (created_at);


--
-- Name: ix_chat_message_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_model_id ON public.chat_message USING btree (model_id);


--
-- Name: ix_chat_message_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_user_id ON public.chat_message USING btree (user_id);


--
-- Name: ix_chat_view_state_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_view_state_chat_id ON public.chat_view_state USING btree (chat_id);


--
-- Name: ix_comment_parent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_comment_parent ON public.comment USING btree (parent_id, created_at, id);


--
-- Name: ix_comment_reaction_comment_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_comment_reaction_comment_id ON public.comment_reaction USING btree (comment_id);


--
-- Name: ix_comment_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_comment_resource ON public.comment USING btree (resource_type, resource_id, parent_id, created_at, id);


--
-- Name: ix_comment_target; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_comment_target ON public.comment USING btree (resource_type, resource_id, target_type, target_id);


--
-- Name: ix_function_history_function_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_function_history_function_id ON public.function_history USING btree (function_id);


--
-- Name: ix_group_member_user_id_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_group_member_user_id_group_id ON public.group_member USING btree (user_id, group_id);


--
-- Name: ix_group_parent_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_group_parent_group_id ON public."group" USING btree (parent_group_id);


--
-- Name: ix_knowledge_directory_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_knowledge_id ON public.knowledge_directory USING btree (knowledge_id);


--
-- Name: ix_knowledge_directory_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_parent_id ON public.knowledge_directory USING btree (parent_id);


--
-- Name: ix_knowledge_file_directory_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_directory_id ON public.knowledge_file USING btree (directory_id);


--
-- Name: ix_knowledge_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_file_id ON public.knowledge_file USING btree (file_id);


--
-- Name: ix_knowledge_file_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_knowledge_id ON public.knowledge_file USING btree (knowledge_id);


--
-- Name: ix_knowledge_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_user_id ON public.knowledge_file USING btree (user_id);


--
-- Name: ix_memory_id_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_id_user_id ON public.memory USING btree (id, user_id);


--
-- Name: ix_memory_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_type ON public.memory USING btree (type);


--
-- Name: ix_memory_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_user_id ON public.memory USING btree (user_id);


--
-- Name: ix_message_app; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_app ON public.message USING btree (app_id);


--
-- Name: ix_message_channel_parent_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_channel_parent_created ON public.message USING btree (channel_id, parent_id, created_at);


--
-- Name: ix_message_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_parent_id ON public.message USING btree (parent_id);


--
-- Name: ix_message_reaction_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_message_reaction_message_id ON public.message_reaction USING btree (message_id);


--
-- Name: ix_model_history_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_model_history_model_id ON public.model_history USING btree (model_id);


--
-- Name: ix_notification_object; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_object ON public.notification USING btree (object_type, object_id);


--
-- Name: ix_notification_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_resource ON public.notification USING btree (resource_type, resource_id);


--
-- Name: ix_notification_unseen; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_unseen ON public.notification USING btree (user_id, created_at, id) WHERE (seen_at IS NULL);


--
-- Name: ix_notification_user_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_notification_user_created ON public.notification USING btree (user_id, created_at, id);


--
-- Name: ix_prompt_history_prompt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompt_history_prompt_id ON public.prompt_history USING btree (prompt_id);


--
-- Name: ix_prompt_new_command; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_prompt_new_command ON public.prompt USING btree (command);


--
-- Name: ix_skill_history_skill_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_skill_history_skill_id ON public.skill_history USING btree (skill_id);


--
-- Name: ix_tool_history_tool_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_tool_history_tool_id ON public.tool_history USING btree (tool_id);


--
-- Name: timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX timer_at_idx ON public.chat USING btree (timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: updated_at_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX updated_at_user_id_idx ON public.chat USING btree (updated_at, user_id);


--
-- Name: uq_user_email_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_user_email_lower ON public."user" USING btree (lower((email)::text)) WHERE (email IS NOT NULL);


--
-- Name: user_id_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_archived_idx ON public.chat USING btree (user_id, archived);


--
-- Name: user_id_folder_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_folder_unread_idx ON public.chat USING btree (user_id, folder_id, archived, updated_at, last_read_at, id);


--
-- Name: user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_idx ON public.tag USING btree (user_id);


--
-- Name: user_id_pinned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_pinned_idx ON public.chat USING btree (user_id, pinned);


--
-- Name: user_id_timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_timer_at_idx ON public.chat USING btree (user_id, timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: user_id_updated_at_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_updated_at_id_idx ON public.chat USING btree (user_id, updated_at DESC, id);


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: channel_webhook channel_webhook_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: chat_message chat_message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: channel_file fk_channel_file_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT fk_channel_file_message_id FOREIGN KEY (message_id) REFERENCES public.message(id) ON DELETE CASCADE;


--
-- Name: group fk_group_parent; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT fk_group_parent FOREIGN KEY (parent_group_id) REFERENCES public."group"(id) ON DELETE SET NULL;


--
-- Name: knowledge_file fk_knowledge_file_directory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT fk_knowledge_file_directory_id FOREIGN KEY (directory_id) REFERENCES public.knowledge_directory(id) ON DELETE SET NULL;


--
-- Name: group_member group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: group_member group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_directory(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: oauth_session oauth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: pinned_note pinned_note_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id) ON DELETE CASCADE;


--
-- Name: shared_chat shared_chat_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

