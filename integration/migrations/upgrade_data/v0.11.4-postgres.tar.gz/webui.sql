--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_grant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_grant (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    user_id text,
    key text NOT NULL,
    data json,
    expires_at bigint,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth (
    id character varying NOT NULL,
    email character varying,
    password text,
    active boolean
);


--
-- Name: automation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    data json NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    folder_id text
);


--
-- Name: automation_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_run (
    id text NOT NULL,
    automation_id text NOT NULL,
    chat_id text,
    status text NOT NULL,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    color text,
    is_default boolean NOT NULL,
    data json,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event (
    id text NOT NULL,
    calendar_id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    start_at bigint NOT NULL,
    end_at bigint,
    all_day boolean NOT NULL,
    rrule text,
    color text,
    location text,
    data json,
    meta json,
    is_cancelled boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event_attendee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendee (
    id text NOT NULL,
    event_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    type text,
    is_private boolean,
    archived_at bigint,
    archived_by text,
    deleted_at bigint,
    deleted_by text,
    updated_by text
);


--
-- Name: channel_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_file (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    message_id text
);


--
-- Name: channel_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_member (
    id text NOT NULL,
    channel_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    status text,
    is_active boolean DEFAULT true NOT NULL,
    is_channel_muted boolean DEFAULT false NOT NULL,
    is_channel_pinned boolean DEFAULT false NOT NULL,
    data json,
    meta json,
    joined_at bigint NOT NULL,
    left_at bigint,
    last_read_at bigint,
    updated_at bigint,
    role text,
    invited_by text,
    invited_at bigint
);


--
-- Name: channel_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_webhook (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    profile_image_url text,
    token text NOT NULL,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    user_id character varying,
    title text,
    created_at bigint,
    updated_at bigint,
    share_id text,
    archived boolean,
    chat json,
    pinned boolean,
    meta json DEFAULT '{}'::json NOT NULL,
    folder_id text,
    tasks json,
    summary text,
    last_read_at bigint,
    current_message_id text,
    variables json,
    timer_at bigint
);


--
-- Name: chat_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_file (
    id text NOT NULL,
    user_id text NOT NULL,
    chat_id text NOT NULL,
    file_id text NOT NULL,
    message_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text,
    role text NOT NULL,
    parent_id text,
    content json,
    output json,
    model_id text,
    files json,
    sources json,
    embeds json,
    done boolean,
    status_history json,
    error json,
    usage json,
    created_at bigint,
    updated_at bigint,
    context_summary text,
    meta json
);


--
-- Name: chatidtag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chatidtag (
    id character varying NOT NULL,
    tag_name character varying,
    chat_id character varying,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    key text NOT NULL,
    value json NOT NULL,
    updated_at bigint
);


--
-- Name: config_old; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_old (
    id integer NOT NULL,
    data json NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config_old.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    collection_name character varying NOT NULL,
    name character varying,
    title text,
    filename text,
    content text,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    user_id text,
    version bigint,
    type text,
    data json,
    meta json,
    snapshot json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id character varying NOT NULL,
    user_id character varying,
    filename text,
    meta json,
    created_at bigint,
    hash text,
    data json,
    updated_at bigint,
    path text
);


--
-- Name: folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder (
    id text NOT NULL,
    parent_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    items json,
    meta json,
    is_expanded boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    data json
);


--
-- Name: function; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    type text,
    content text,
    meta text,
    valves text,
    is_active boolean,
    is_global boolean,
    updated_at bigint,
    created_at bigint
);


--
-- Name: group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."group" (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    permissions json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: group_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_member (
    id text NOT NULL,
    group_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    updated_at bigint
);


--
-- Name: knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint,
    data json
);


--
-- Name: knowledge_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_directory (
    id text NOT NULL,
    knowledge_id text NOT NULL,
    parent_id text,
    name text NOT NULL,
    user_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: knowledge_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_file (
    id text NOT NULL,
    user_id text NOT NULL,
    knowledge_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    directory_id text
);


--
-- Name: memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory (
    id character varying NOT NULL,
    user_id character varying,
    content text,
    updated_at bigint,
    created_at bigint,
    type character varying DEFAULT 'context'::character varying NOT NULL,
    path text,
    meta json
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    id text NOT NULL,
    user_id text,
    channel_id text,
    content text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    parent_id text,
    reply_to_id text,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at bigint,
    pinned_by text
);


--
-- Name: message_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    message_id text NOT NULL,
    name text NOT NULL,
    created_at bigint
);


--
-- Name: model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model (
    id text NOT NULL,
    user_id text,
    base_model_id text,
    name text,
    params text,
    meta text,
    updated_at bigint,
    created_at bigint,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    id text NOT NULL,
    user_id text,
    title text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: oauth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_session (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pinned_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_note (
    id text NOT NULL,
    user_id text NOT NULL,
    note_id text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: prompt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt (
    id text NOT NULL,
    command character varying,
    user_id character varying NOT NULL,
    name text NOT NULL,
    content text NOT NULL,
    data json,
    meta json,
    is_active boolean DEFAULT true NOT NULL,
    version_id text,
    tags json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: prompt_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt_history (
    id text NOT NULL,
    prompt_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: shared_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_chat (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text NOT NULL,
    title text,
    chat json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    updated_at bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tag (
    id character varying NOT NULL,
    name character varying,
    user_id character varying NOT NULL,
    meta json
);


--
-- Name: tool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    content text,
    specs text,
    meta text,
    valves text,
    updated_at bigint,
    created_at bigint
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id character varying NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    profile_image_url text,
    last_active_at bigint,
    updated_at bigint,
    created_at bigint,
    settings json,
    info json,
    username character varying(50),
    bio text,
    gender text,
    date_of_birth date,
    profile_banner_image_url text,
    timezone character varying,
    presence_state character varying,
    status_emoji character varying,
    status_message text,
    status_expires_at bigint,
    oauth json,
    scim json,
    variables json
);


--
-- Name: config_old id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Data for Name: access_grant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_grant (id, resource_type, resource_id, principal_type, principal_id, permission, created_at) FROM stdin;
187c19ef-91e6-45b1-b8f0-2699096b69df	prompt	6932d9de-28ed-496c-8517-89ee0340f1fc	group	dce6c37f-8059-4aa9-87f5-420147f5f483	read	1795595593
c64f00c4-9c02-4d0f-bc3b-ab95e66781a6	tool	weather_tool	group	dce6c37f-8059-4aa9-87f5-420147f5f483	read	1795595593
60aa20ee-7426-4c05-8e88-ea084b968934	model	research-assistant	user	478b333b-9c42-454e-9e8d-b0bba24a606a	read	1795595593
630f9dc4-59f4-47fe-ae7d-165bc174bbb8	skill	trip-planner	group	dce6c37f-8059-4aa9-87f5-420147f5f483	read	1795595593
d775253d-a9b2-46da-a528-eb14c797285d	skill	trip-planner	user	478b333b-9c42-454e-9e8d-b0bba24a606a	write	1795595593
1c312afb-3456-4449-b827-fb7efa53c099	skill	house-style	user	*	read	1795595594
bc0d5417-717b-4cea-b5a4-a1f6d618b747	skill	dave-notes	group	dce6c37f-8059-4aa9-87f5-420147f5f483	read	1795595594
e0b8a3fc-b788-408c-8add-d543e7397248	knowledge	6991632e-bbc4-4923-81f0-aa81dde43a1d	group	dce6c37f-8059-4aa9-87f5-420147f5f483	read	1795595594
63aa02d5-f1bb-405f-b527-bf31f4202451	shared_chat	dc526bbd-1f51-4db6-afff-a47d8192d059	user	478b333b-9c42-454e-9e8d-b0bba24a606a	read	1795595595
0c329af6-cb66-4ea2-a72d-44fa851d94c6	note	3d338c56-f7a8-414b-b183-79e86de65424	user	478b333b-9c42-454e-9e8d-b0bba24a606a	read	1795595597
3dc1f56c-74e4-4d9f-939b-9de1ec96c8ca	note	3d338c56-f7a8-414b-b183-79e86de65424	user	478b333b-9c42-454e-9e8d-b0bba24a606a	write	1795595597
ad2b582c-b99c-4938-953d-c4f3340d42ba	channel	dbfa78ac-68a0-4320-a798-d9394f1f3688	group	dce6c37f-8059-4aa9-87f5-420147f5f483	read	1795595598
18472ace-f47e-45e3-ae94-82e9b6a56e1b	channel	dbfa78ac-68a0-4320-a798-d9394f1f3688	group	dce6c37f-8059-4aa9-87f5-420147f5f483	write	1795595598
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
d4c1a8e37b62
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, user_id, key, data, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth (id, email, password, active) FROM stdin;
0336a46e-791d-4c33-b07f-b62308a04511	admin@example.com	$2b$12$ZA59l9b/UWtpS2aJv7Z0q.T5pr0Wq/VZ3dPu1fh92lEBmGctFuCX6	t
e38e3bc0-1dba-4a94-bad6-5a9293febaae	alice@example.com	$2b$12$0XBpLfMZ0WP0NZRyPgQJ/uj3oxSsaA1f9/0Hswv5E6wu/cnJEaPJC	t
478b333b-9c42-454e-9e8d-b0bba24a606a	bob@example.com	$2b$12$XBswVTO99oZB7LLeNLlqjOg3XAQx0pK23LYdn2EkhT/cFSTpUWkAa	t
347d1d8f-819b-499c-9949-449e1784cc3d	carol@example.com	$2b$12$UiX23O5GlGZlCxLumzALVOdxzZKXDLCIriORrlAs0t.gQCAjn4ulu	t
\.


--
-- Data for Name: automation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation (id, user_id, name, data, meta, is_active, last_run_at, next_run_at, created_at, updated_at, folder_id) FROM stdin;
\.


--
-- Data for Name: automation_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_run (id, automation_id, chat_id, status, error, created_at) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar (id, user_id, name, color, is_default, data, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event (id, calendar_id, user_id, title, description, start_at, end_at, all_day, rrule, color, location, data, meta, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendee (id, event_id, user_id, status, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel (id, user_id, name, description, data, meta, created_at, updated_at, type, is_private, archived_at, archived_by, deleted_at, deleted_by, updated_by) FROM stdin;
dbfa78ac-68a0-4320-a798-d9394f1f3688	0336a46e-791d-4c33-b07f-b62308a04511	lighthouse	Team chatter	null	null	1795595598004474510	1795595598004474921	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: channel_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_file (id, user_id, channel_id, file_id, created_at, updated_at, message_id) FROM stdin;
\.


--
-- Data for Name: channel_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_member (id, channel_id, user_id, created_at, status, is_active, is_channel_muted, is_channel_pinned, data, meta, joined_at, left_at, last_read_at, updated_at, role, invited_by, invited_at) FROM stdin;
8951ff6a-edc3-49ee-ad10-22b0feab9a08	dbfa78ac-68a0-4320-a798-d9394f1f3688	e38e3bc0-1dba-4a94-bad6-5a9293febaae	1795595598035266997	joined	t	f	f	null	null	1795595598035266316	\N	1795595598035266736	1795595598035267137	\N	\N	\N
12737420-c0fa-42cb-9c44-b33a812f65ac	dbfa78ac-68a0-4320-a798-d9394f1f3688	478b333b-9c42-454e-9e8d-b0bba24a606a	1795595598074084209	joined	t	f	f	null	null	1795595598074083608	\N	1795595598074084119	1795595598074084299	\N	\N	\N
\.


--
-- Data for Name: channel_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_webhook (id, user_id, channel_id, name, profile_image_url, token, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat (id, user_id, title, created_at, updated_at, share_id, archived, chat, pinned, meta, folder_id, tasks, summary, last_read_at, current_message_id, variables, timer_at) FROM stdin;
dc526bbd-1f51-4db6-afff-a47d8192d059	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Packing for Vienna	1795595595	1795595595	aeef3cd9-4d6e-4dc4-9e79-45f48ec1ab54	f	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "8fc5d428-92b7-44de-9fb7-b07c87bd1b4e", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1795595595, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1795595596}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1795595597}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1795595598, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1795595599}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "8fc5d428-92b7-44de-9fb7-b07c87bd1b4e", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1795595595, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1795595597}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1795595598, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1795595599}], "files": [{"type": "file", "id": "8fc5d428-92b7-44de-9fb7-b07c87bd1b4e", "name": "packing.txt", "status": "uploaded"}], "params": {}}	t	{"tags": ["travel"]}	be25165a-edf3-4869-a78c-1a46a2b9b831	null	\N	1795595595	a2-0000-4000-8000-000000000000	{}	\N
62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Schnitzel questions	1795595595	1795595595	\N	f	{"id": "62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340", "title": "Schnitzel questions", "models": ["mock-model"], "history": {"currentId": "1117bd8a-ceb0-4d97-9282-a10f00a017fa", "messages": {"6bee3fcd-36a9-480e-821f-c049169ab304": {"id": "6bee3fcd-36a9-480e-821f-c049169ab304", "parentId": null, "childrenIds": ["8c6de1ee-467b-4553-b868-0e5af17f449b"], "role": "user", "content": "What is a Schnitzel?", "models": ["mock-model"], "timestamp": 1795595595}, "8c6de1ee-467b-4553-b868-0e5af17f449b": {"id": "8c6de1ee-467b-4553-b868-0e5af17f449b", "parentId": "6bee3fcd-36a9-480e-821f-c049169ab304", "childrenIds": ["379a71d1-ac7e-44bc-b080-a67d84292041"], "role": "assistant", "content": "Schnitzel is a breaded cutlet.", "done": true, "model": "mock-model", "timestamp": 1795595595, "output": [{"type": "message", "id": "msg_d83bf70ec4104a22a8e87238", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]}, "379a71d1-ac7e-44bc-b080-a67d84292041": {"id": "379a71d1-ac7e-44bc-b080-a67d84292041", "parentId": "8c6de1ee-467b-4553-b868-0e5af17f449b", "childrenIds": ["1117bd8a-ceb0-4d97-9282-a10f00a017fa"], "role": "user", "content": "How do I eat it?", "models": ["mock-model"], "timestamp": 1795595595}, "1117bd8a-ceb0-4d97-9282-a10f00a017fa": {"id": "1117bd8a-ceb0-4d97-9282-a10f00a017fa", "parentId": "379a71d1-ac7e-44bc-b080-a67d84292041", "childrenIds": [], "role": "assistant", "content": "Try it with lemon.", "done": true, "model": "mock-model", "timestamp": 1795595595, "output": [{"type": "message", "id": "msg_4ef832c90137408d931872c0", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]}}}, "messages": [{"role": "user", "content": "What is a Schnitzel?"}], "files": [], "tags": [], "timestamp": 1795595595100}	f	{}	\N	null	\N	1795595595	1117bd8a-ceb0-4d97-9282-a10f00a017fa	{}	\N
844b29c3-149e-4d50-81a8-edcaaf692fcf	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Old plans	1795595596	1795595596	\N	t	{"title": "Old plans", "models": ["mock-model"], "history": {}}	f	{}	\N	null	\N	1795595596	\N	{}	\N
101b2385-fc26-49c1-a45b-2667bebab266	478b333b-9c42-454e-9e8d-b0bba24a606a	Getting to the Prater	1795595596	1795595597	\N	f	{"id": "101b2385-fc26-49c1-a45b-2667bebab266", "title": "Getting to the Prater", "models": ["mock-model"], "history": {"currentId": "177c6335-c348-48cc-aae9-eb7851ef3a6a", "messages": {"19179917-cf12-45d6-b649-0baed4e6e1ad": {"id": "19179917-cf12-45d6-b649-0baed4e6e1ad", "parentId": null, "childrenIds": ["744b0678-644e-4489-be16-1834e47fec49"], "role": "user", "content": "How do I get to the Prater?", "models": ["mock-model"], "timestamp": 1795595596}, "744b0678-644e-4489-be16-1834e47fec49": {"id": "744b0678-644e-4489-be16-1834e47fec49", "parentId": "19179917-cf12-45d6-b649-0baed4e6e1ad", "childrenIds": ["2ccabbd7-1dd3-4b51-95db-eb6612bfb822"], "role": "assistant", "content": "Take the U-Bahn.", "done": true, "model": "mock-model", "timestamp": 1795595596, "output": [{"type": "message", "id": "msg_ce02340af367404382f324b7", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Take the U-Bahn."}]}], "usage": {"prompt_tokens": 12, "completion_tokens": 7, "total_tokens": 19, "input_tokens": 12, "output_tokens": 7}, "annotation": {"rating": 1, "reason": "Accurate", "comment": "Exactly the line I needed.", "tags": ["transport"]}, "feedbackId": "700d38f2-dc04-44be-b932-7b5ca855326e", "followUps": ["How long does it take?", "Is there a night line?"], "embeds": ["<p>U2 to Praterstern</p>"]}, "2ccabbd7-1dd3-4b51-95db-eb6612bfb822": {"id": "2ccabbd7-1dd3-4b51-95db-eb6612bfb822", "parentId": "744b0678-644e-4489-be16-1834e47fec49", "childrenIds": ["177c6335-c348-48cc-aae9-eb7851ef3a6a"], "role": "user", "content": "And back?", "models": ["mock-model"], "timestamp": 1795595597}, "177c6335-c348-48cc-aae9-eb7851ef3a6a": {"id": "177c6335-c348-48cc-aae9-eb7851ef3a6a", "parentId": "2ccabbd7-1dd3-4b51-95db-eb6612bfb822", "childrenIds": [], "role": "assistant", "content": "", "done": true, "model": "mock-model", "timestamp": 1795595597, "error": {"content": "the provider is down"}}}}, "messages": [{"role": "user", "content": "How do I get to the Prater?"}], "files": [], "tags": [], "timestamp": 1795595596987}	f	{}	\N	null	\N	1795595596	177c6335-c348-48cc-aae9-eb7851ef3a6a	{}	\N
027dc2da-f051-43d4-bcf4-cc08413b176e	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Lighthouse key	1795595596	1795595596	\N	f	{"id": "027dc2da-f051-43d4-bcf4-cc08413b176e", "title": "Lighthouse key", "models": ["mock-model"], "history": {"currentId": "3ea81e1b-2f1b-4b82-9808-1d5ee2cc5d0b", "messages": {"777faffa-d5c5-46e3-a984-77915a282d35": {"id": "777faffa-d5c5-46e3-a984-77915a282d35", "parentId": null, "childrenIds": ["3ea81e1b-2f1b-4b82-9808-1d5ee2cc5d0b"], "role": "user", "content": "Where does the lighthouse key hang?", "models": ["mock-model"], "timestamp": 1795595596, "files": [{"type": "collection", "id": "6991632e-bbc4-4923-81f0-aa81dde43a1d", "name": "Handbook"}]}, "3ea81e1b-2f1b-4b82-9808-1d5ee2cc5d0b": {"id": "3ea81e1b-2f1b-4b82-9808-1d5ee2cc5d0b", "parentId": "777faffa-d5c5-46e3-a984-77915a282d35", "childrenIds": [], "role": "assistant", "content": "Behind the blue door [1].", "done": true, "model": "mock-model", "timestamp": 1795595596, "statusHistory": [{"action": "queries_generated", "queries": ["ok"], "done": false}, {"action": "sources_retrieved", "count": 1, "done": true}], "sources": [{"source": {"type": "collection", "id": "6991632e-bbc4-4923-81f0-aa81dde43a1d", "name": "Handbook"}, "document": ["The upgrade handbook says the lighthouse key hangs behind the blue door."], "metadata": [{"hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "start_index": 0, "file_id": "7d60706c-881e-4df8-b390-c3ce1827cd98", "source": "handbook.txt", "size": 72, "content_type": "text/plain", "created_by": "0336a46e-791d-4c33-b07f-b62308a04511", "embedding_config": "{'engine': 'openai', 'model': 'sentence-transformers/all-MiniLM-L6-v2'}", "name": "handbook.txt"}], "distances": [0.9999999403953552]}], "output": [{"type": "message", "id": "msg_618ff1acf9e9479ba7860a1a", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Behind the blue door [1]."}]}]}}}, "messages": [{"role": "user", "content": "Where does the lighthouse key hang?"}], "files": [{"type": "collection", "id": "6991632e-bbc4-4923-81f0-aa81dde43a1d", "name": "Handbook"}], "tags": [], "timestamp": 1795595596042}	f	{}	\N	null	\N	1795595596	3ea81e1b-2f1b-4b82-9808-1d5ee2cc5d0b	{}	\N
\.


--
-- Data for Name: chat_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_file (id, user_id, chat_id, file_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_message (id, chat_id, user_id, role, parent_id, content, output, model_id, files, sources, embeds, done, status_history, error, usage, created_at, updated_at, context_summary, meta) FROM stdin;
dc526bbd-1f51-4db6-afff-a47d8192d059-u1-0000-4000-8000-000000000000	dc526bbd-1f51-4db6-afff-a47d8192d059	e38e3bc0-1dba-4a94-bad6-5a9293febaae	user	\N	"What should I pack for Vienna?"	null	\N	[{"type": "file", "id": "8fc5d428-92b7-44de-9fb7-b07c87bd1b4e", "name": "packing.txt", "status": "uploaded"}]	null	null	t	null	null	null	1795595595	1795595595	\N	null
dc526bbd-1f51-4db6-afff-a47d8192d059-a1-0000-4000-8000-000000000000	dc526bbd-1f51-4db6-afff-a47d8192d059	e38e3bc0-1dba-4a94-bad6-5a9293febaae	assistant	u1-0000-4000-8000-000000000000	"Pack an umbrella."	null	mock-model	null	null	null	t	null	null	null	1795595596	1795595595	\N	null
dc526bbd-1f51-4db6-afff-a47d8192d059-a1b-0000-4000-8000-000000000000	dc526bbd-1f51-4db6-afff-a47d8192d059	e38e3bc0-1dba-4a94-bad6-5a9293febaae	assistant	u1-0000-4000-8000-000000000000	"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses."	null	mock-model	null	null	null	t	null	null	null	1795595597	1795595595	\N	null
dc526bbd-1f51-4db6-afff-a47d8192d059-u2-0000-4000-8000-000000000000	dc526bbd-1f51-4db6-afff-a47d8192d059	e38e3bc0-1dba-4a94-bad6-5a9293febaae	user	a1b-0000-4000-8000-000000000000	"And for the evening?"	null	\N	null	null	null	t	null	null	null	1795595598	1795595595	\N	null
dc526bbd-1f51-4db6-afff-a47d8192d059-a2-0000-4000-8000-000000000000	dc526bbd-1f51-4db6-afff-a47d8192d059	e38e3bc0-1dba-4a94-bad6-5a9293febaae	assistant	u2-0000-4000-8000-000000000000	"A light jacket."	null	mock-model	null	null	null	t	null	null	null	1795595599	1795595595	\N	null
62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340-1117bd8a-ceb0-4d97-9282-a10f00a017fa	62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340	e38e3bc0-1dba-4a94-bad6-5a9293febaae	assistant	379a71d1-ac7e-44bc-b080-a67d84292041	"Try it with lemon."	[{"type": "message", "id": "msg_4ef832c90137408d931872c0", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]	mock-model	null	null	null	t	null	null	null	1795595595	1795595596	\N	null
62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340-379a71d1-ac7e-44bc-b080-a67d84292041	62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340	e38e3bc0-1dba-4a94-bad6-5a9293febaae	user	8c6de1ee-467b-4553-b868-0e5af17f449b	"How do I eat it?"	null	\N	null	null	null	t	null	null	null	1795595595	1795595596	\N	null
62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340-6bee3fcd-36a9-480e-821f-c049169ab304	62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340	e38e3bc0-1dba-4a94-bad6-5a9293febaae	user	\N	"What is a Schnitzel?"	null	\N	null	null	null	t	null	null	null	1795595595	1795595596	\N	null
62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340-8c6de1ee-467b-4553-b868-0e5af17f449b	62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340	e38e3bc0-1dba-4a94-bad6-5a9293febaae	assistant	6bee3fcd-36a9-480e-821f-c049169ab304	"Schnitzel is a breaded cutlet."	[{"type": "message", "id": "msg_d83bf70ec4104a22a8e87238", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]	mock-model	null	null	null	t	null	null	null	1795595595	1795595596	\N	null
027dc2da-f051-43d4-bcf4-cc08413b176e-777faffa-d5c5-46e3-a984-77915a282d35	027dc2da-f051-43d4-bcf4-cc08413b176e	e38e3bc0-1dba-4a94-bad6-5a9293febaae	user	\N	"Where does the lighthouse key hang?"	null	\N	[{"type": "collection", "id": "6991632e-bbc4-4923-81f0-aa81dde43a1d", "name": "Handbook"}]	null	null	t	null	null	null	1795595596	1795595596	\N	null
101b2385-fc26-49c1-a45b-2667bebab266-2ccabbd7-1dd3-4b51-95db-eb6612bfb822	101b2385-fc26-49c1-a45b-2667bebab266	478b333b-9c42-454e-9e8d-b0bba24a606a	user	744b0678-644e-4489-be16-1834e47fec49	"And back?"	null	\N	null	null	null	t	null	null	null	1795595597	1795595597	\N	null
027dc2da-f051-43d4-bcf4-cc08413b176e-3ea81e1b-2f1b-4b82-9808-1d5ee2cc5d0b	027dc2da-f051-43d4-bcf4-cc08413b176e	e38e3bc0-1dba-4a94-bad6-5a9293febaae	assistant	777faffa-d5c5-46e3-a984-77915a282d35	"Behind the blue door [1]."	[{"type": "message", "id": "msg_618ff1acf9e9479ba7860a1a", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Behind the blue door [1]."}]}]	mock-model	null	[{"source": {"type": "collection", "id": "6991632e-bbc4-4923-81f0-aa81dde43a1d", "name": "Handbook"}, "document": ["The upgrade handbook says the lighthouse key hangs behind the blue door."], "metadata": [{"hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "start_index": 0, "file_id": "7d60706c-881e-4df8-b390-c3ce1827cd98", "source": "handbook.txt", "size": 72, "content_type": "text/plain", "created_by": "0336a46e-791d-4c33-b07f-b62308a04511", "embedding_config": "{'engine': 'openai', 'model': 'sentence-transformers/all-MiniLM-L6-v2'}", "name": "handbook.txt"}], "distances": [0.9999999403953552]}]	null	t	[{"action": "queries_generated", "queries": ["ok"], "done": false}, {"action": "sources_retrieved", "count": 1, "done": true}]	null	null	1795595596	1795595596	\N	null
101b2385-fc26-49c1-a45b-2667bebab266-177c6335-c348-48cc-aae9-eb7851ef3a6a	101b2385-fc26-49c1-a45b-2667bebab266	478b333b-9c42-454e-9e8d-b0bba24a606a	assistant	2ccabbd7-1dd3-4b51-95db-eb6612bfb822	""	null	mock-model	null	null	null	t	null	{"content": "the provider is down"}	null	1795595597	1795595597	\N	null
101b2385-fc26-49c1-a45b-2667bebab266-19179917-cf12-45d6-b649-0baed4e6e1ad	101b2385-fc26-49c1-a45b-2667bebab266	478b333b-9c42-454e-9e8d-b0bba24a606a	user	\N	"How do I get to the Prater?"	null	\N	null	null	null	t	null	null	null	1795595596	1795595597	\N	null
101b2385-fc26-49c1-a45b-2667bebab266-744b0678-644e-4489-be16-1834e47fec49	101b2385-fc26-49c1-a45b-2667bebab266	478b333b-9c42-454e-9e8d-b0bba24a606a	assistant	19179917-cf12-45d6-b649-0baed4e6e1ad	"Take the U-Bahn."	[{"type": "message", "id": "msg_ce02340af367404382f324b7", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Take the U-Bahn."}]}]	mock-model	null	null	["<p>U2 to Praterstern</p>"]	t	null	null	{"prompt_tokens": 12, "completion_tokens": 7, "total_tokens": 19, "input_tokens": 12, "output_tokens": 7}	1795595596	1795595597	\N	null
\.


--
-- Data for Name: chatidtag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chatidtag (id, tag_name, chat_id, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config (key, value, updated_at) FROM stdin;
direct.enable	false	1795595592
direct.integrations.enable	false	1795595592
ollama.enable	false	1795595592
ollama.base_urls	["http://localhost:11434"]	1795595592
ollama.api_configs	{}	1795595592
openai.enable	true	1795595592
openai.api_keys	["sk-mock"]	1795595592
openai.api_base_urls	["http://127.0.0.1:34831/v1"]	1795595592
openai.api_configs	{}	1795595592
models.base_models_cache	false	1795595592
tool_server.connections	[]	1795595592
terminal_server.connections	[]	1795595592
code_execution.enable	true	1795595592
code_execution.engine	"pyodide"	1795595592
code_execution.jupyter.url	""	1795595592
code_execution.jupyter.auth	""	1795595592
code_execution.jupyter.auth_token	""	1795595592
code_execution.jupyter.auth_password	""	1795595592
code_execution.jupyter.timeout	60	1795595592
code_interpreter.enable	true	1795595592
memories.background_review.enable	false	1795595592
memories.review_interval_turns	10	1795595592
memories.user_char_limit	2000	1795595592
memories.context_char_limit	2000	1795595592
code_interpreter.engine	"pyodide"	1795595592
code_interpreter.prompt_template	""	1795595592
code_interpreter.jupyter.url	""	1795595592
code_interpreter.jupyter.auth	""	1795595592
code_interpreter.jupyter.auth_token	""	1795595592
code_interpreter.jupyter.auth_password	""	1795595592
code_interpreter.jupyter.timeout	60	1795595592
google_drive.enable	false	1795595592
google_drive.client_id	""	1795595592
google_drive.api_key	""	1795595592
onedrive.enable	false	1795595592
onedrive.sharepoint_url	""	1795595592
onedrive.sharepoint_tenant_id	""	1795595592
rag.content_extraction_engine	""	1795595592
rag.content_extraction.supported_media_mime_types	null	1795595592
rag.datalab_marker_api_key	""	1795595592
rag.datalab_marker_api_base_url	""	1795595592
rag.datalab_marker_additional_config	""	1795595592
rag.datalab_marker_use_llm	false	1795595592
rag.datalab_marker_skip_cache	false	1795595592
rag.datalab_marker_force_ocr	false	1795595592
rag.datalab_marker_paginate	false	1795595592
rag.datalab_marker_strip_existing_ocr	false	1795595592
rag.datalab_marker_disable_image_extraction	false	1795595592
rag.datalab_marker_format_lines	false	1795595592
rag.datalab_marker_output_format	"markdown"	1795595592
rag.mineru_api_mode	"local"	1795595592
rag.mineru_api_url	"http://localhost:8000"	1795595592
rag.mineru_api_timeout	"300"	1795595592
rag.mineru_api_key	""	1795595592
rag.mineru_params	{}	1795595592
rag.mineru_file_extensions	["pdf"]	1795595592
rag.external_document_loader_url	""	1795595592
rag.external_document_loader_api_key	""	1795595592
rag.external_document_loader_headers	{}	1795595592
rag.tika_server_url	"http://tika:9998"	1795595592
rag.tika_server_version	"3"	1795595592
rag.docling_server_url	"http://docling:5001"	1795595592
rag.docling_api_key	""	1795595592
rag.docling_params	{}	1795595592
rag.document_intelligence_endpoint	""	1795595592
rag.document_intelligence_key	""	1795595592
rag.document_intelligence_model	"prebuilt-layout"	1795595592
rag.mistral_ocr_api_base_url	"https://api.mistral.ai/v1"	1795595592
rag.mistral_ocr_api_key	""	1795595592
rag.mistral_ocr_use_base64	false	1795595592
rag.paddleocr_vl_base_url	"http://localhost:8080"	1795595592
rag.paddleocr_vl_token	""	1795595592
rag.bypass_embedding_and_retrieval	false	1795595592
rag.top_k	3	1795595592
rag.top_k_reranker	3	1795595592
rag.relevance_threshold	0.0	1795595592
rag.hybrid_bm25_weight	0.5	1795595592
rag.enable_hybrid_search	false	1795595592
rag.enable_hybrid_search_enriched_texts	false	1795595592
rag.full_context	false	1795595592
rag.file.max_count	null	1795595592
rag.file.max_size	null	1795595592
file.image_compression_width	null	1795595592
file.image_compression_height	null	1795595592
rag.file.allowed_extensions	[]	1795595592
rag.embedding_engine	"openai"	1795595592
rag.pdf_extract_images	false	1795595592
rag.pdf_loader_mode	"page"	1795595592
rag.embedding_model	"sentence-transformers/all-MiniLM-L6-v2"	1795595592
rag.tokenizer_model	""	1795595592
rag.embedding_batch_size	1	1795595592
rag.enable_async_embedding	true	1795595592
rag.embedding_concurrent_requests	0	1795595592
rag.reranking_engine	""	1795595592
rag.reranking_model	""	1795595592
rag.reranking_batch_size	32	1795595592
rag.external_reranker_url	""	1795595592
rag.external_reranker_api_key	""	1795595592
rag.external_reranker_timeout	""	1795595592
rag.text_splitter	""	1795595592
rag.enable_markdown_header_text_splitter	true	1795595592
rag.tiktoken_encoding_name	"cl100k_base"	1795595592
rag.chunk_size	1000	1795595592
rag.chunk_min_size_target	0	1795595592
rag.chunk_overlap	100	1795595592
image_generation.engine	"openai"	1795595592
image_generation.model	""	1795595592
image_generation.size	"512x512"	1795595592
image_generation.steps	50	1795595592
image_generation.prompt.enable	true	1795595592
image_generation.automatic1111.base_url	""	1795595592
rag.template	"### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n{{CONTEXT}}\\n</context>\\n"	1795595592
rag.openai.api_base_url	"http://127.0.0.1:34831/v1"	1795595592
rag.openai.api_key	"sk-mock"	1795595592
rag.azure_openai.base_url	""	1795595592
rag.azure_openai.api_key	""	1795595592
rag.azure_openai.api_version	""	1795595592
rag.ollama.base_url	"http://localhost:11434"	1795595592
rag.ollama.api_key	""	1795595592
rag.youtube_loader_language	["en"]	1795595592
rag.youtube_loader_proxy_url	""	1795595592
web.search.enable	false	1795595592
web.search.confirmation.enable	false	1795595592
web.search.confirmation.content	"Your query will be sent to the configured web search provider."	1795595592
web.search.engine	""	1795595592
web.search.bypass_embedding_and_retrieval	false	1795595592
web.search.bypass_web_loader	false	1795595592
web.search.result_count	3	1795595592
web.search.domain.filter_list	[]	1795595592
web.search.concurrent_requests	0	1795595592
web.fetch.max_content_length	null	1795595592
web.loader.engine	""	1795595592
web.loader.concurrent_requests	10	1795595592
web.loader.timeout	""	1795595592
web.loader.ssl_verification	true	1795595592
web.search.trust_env	true	1795595592
web.search.ollama_cloud_api_key	""	1795595592
web.search.searxng_query_url	""	1795595592
web.search.openserp_base_url	"http://localhost:7000"	1795595592
web.search.searxng_language	"all"	1795595592
web.search.yacy_query_url	""	1795595592
web.search.yacy_username	""	1795595592
web.search.yacy_password	""	1795595592
web.search.google_pse_api_key	""	1795595592
web.search.google_pse_engine_id	""	1795595592
web.search.brave_search_api_key	""	1795595592
web.search.brave_search_context_tokens	8192	1795595592
web.search.kagi_search_api_key	""	1795595592
web.search.mojeek_search_api_key	""	1795595592
web.search.bocha_search_api_key	""	1795595592
web.search.serpstack_api_key	""	1795595592
web.search.serpstack_https	true	1795595592
web.search.serper_api_key	""	1795595592
web.search.serply_api_key	""	1795595592
web.search.serphouse_api_key	""	1795595592
web.search.serphouse_domain	"google.com"	1795595592
web.search.ddgs_backend	"auto"	1795595592
web.search.jina_api_key	""	1795595592
web.search.jina_api_base_url	""	1795595592
web.search.searchapi_api_key	""	1795595592
web.search.searchapi_engine	""	1795595592
web.search.serpapi_api_key	""	1795595592
web.search.serpapi_engine	""	1795595592
web.search.bing_search_v7_endpoint	"https://api.bing.microsoft.com/v7.0/search"	1795595592
web.search.bing_search_v7_subscription_key	""	1795595592
web.search.azure_ai_search_api_key	""	1795595592
web.search.azure_ai_search_endpoint	""	1795595592
web.search.azure_ai_search_index_name	""	1795595592
web.search.exa_api_key	""	1795595592
web.search.exa_max_content_length	null	1795595592
web.search.perplexity_api_key	""	1795595592
web.search.perplexity_model	"sonar"	1795595592
web.search.perplexity_search_context_usage	"medium"	1795595592
web.search.perplexity_search_api_url	"https://api.perplexity.ai/search"	1795595592
web.search.microsoft_web_iq_api_base_url	"https://api.microsoft.ai/v3"	1795595592
web.search.microsoft_web_iq_api_key	""	1795595592
web.search.microsoft_web_iq_language	"en"	1795595592
web.search.sougou_api_sid	""	1795595592
web.search.sougou_api_sk	""	1795595592
web.search.tavily_api_key	""	1795595592
web.search.tavily_extract_depth	"basic"	1795595592
web.search.staan_api_key	""	1795595592
web.search.staan_market	"en-us"	1795595592
web.search.staan_max_snippets	0	1795595592
web.loader.playwright_ws_url	""	1795595592
web.loader.playwright_timeout	10000	1795595592
web.loader.firecrawl_api_key	""	1795595592
web.loader.firecrawl_api_url	"https://api.firecrawl.dev"	1795595592
web.loader.firecrawl_timeout	""	1795595592
web.search.external_web_search_url	""	1795595592
web.search.external_web_search_api_key	""	1795595592
web.loader.external_web_loader_url	""	1795595592
web.loader.external_web_loader_api_key	""	1795595592
web.search.yandex_web_search_url	""	1795595592
web.search.yandex_web_search_api_key	""	1795595592
web.search.yandex_web_search_config	""	1795595592
web.search.youcom_api_key	""	1795595592
web.search.linkup_api_key	""	1795595592
web.search.linkup_search_params	{}	1795595592
image_generation.enable	false	1795595592
image_generation.automatic1111.api_auth	""	1795595592
image_generation.automatic1111.api_params	{}	1795595592
image_generation.comfyui.base_url	""	1795595592
image_generation.comfyui.api_key	""	1795595592
image_generation.comfyui.workflow	"\\n{\\n  \\"3\\": {\\n    \\"inputs\\": {\\n      \\"seed\\": 0,\\n      \\"steps\\": 20,\\n      \\"cfg\\": 8,\\n      \\"sampler_name\\": \\"euler\\",\\n      \\"scheduler\\": \\"normal\\",\\n      \\"denoise\\": 1,\\n      \\"model\\": [\\n        \\"4\\",\\n        0\\n      ],\\n      \\"positive\\": [\\n        \\"6\\",\\n        0\\n      ],\\n      \\"negative\\": [\\n        \\"7\\",\\n        0\\n      ],\\n      \\"latent_image\\": [\\n        \\"5\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"KSampler\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"KSampler\\"\\n    }\\n  },\\n  \\"4\\": {\\n    \\"inputs\\": {\\n      \\"ckpt_name\\": \\"model.safetensors\\"\\n    },\\n    \\"class_type\\": \\"CheckpointLoaderSimple\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Load Checkpoint\\"\\n    }\\n  },\\n  \\"5\\": {\\n    \\"inputs\\": {\\n      \\"width\\": 512,\\n      \\"height\\": 512,\\n      \\"batch_size\\": 1\\n    },\\n    \\"class_type\\": \\"EmptyLatentImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Empty Latent Image\\"\\n    }\\n  },\\n  \\"6\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"Prompt\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"7\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"8\\": {\\n    \\"inputs\\": {\\n      \\"samples\\": [\\n        \\"3\\",\\n        0\\n      ],\\n      \\"vae\\": [\\n        \\"4\\",\\n        2\\n      ]\\n    },\\n    \\"class_type\\": \\"VAEDecode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"VAE Decode\\"\\n    }\\n  },\\n  \\"9\\": {\\n    \\"inputs\\": {\\n      \\"filename_prefix\\": \\"ComfyUI\\",\\n      \\"images\\": [\\n        \\"8\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"SaveImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Save Image\\"\\n    }\\n  }\\n}\\n"	1795595592
image_generation.comfyui.nodes	[]	1795595592
image_generation.openai.api_base_url	"https://api.openai.com/v1"	1795595592
image_generation.openai.api_version	""	1795595592
image_generation.openai.api_key	""	1795595592
image_generation.openai.params	{}	1795595592
image_generation.gemini.api_base_url	""	1795595592
image_generation.gemini.api_key	""	1795595592
image_generation.gemini.endpoint_method	""	1795595592
images.edit.enable	false	1795595592
images.edit.engine	"openai"	1795595592
images.edit.model	""	1795595592
images.edit.size	""	1795595592
images.edit.openai.api_base_url	"https://api.openai.com/v1"	1795595592
images.edit.openai.api_version	""	1795595592
images.edit.openai.api_key	""	1795595592
images.edit.gemini.api_base_url	""	1795595592
images.edit.gemini.api_key	""	1795595592
images.edit.comfyui.base_url	""	1795595592
images.edit.comfyui.api_key	""	1795595592
images.edit.comfyui.workflow	""	1795595592
images.edit.comfyui.nodes	[]	1795595592
audio.stt.whisper_model	"base"	1795595592
audio.stt.deepgram.api_key	""	1795595592
audio.stt.openai.api_base_url	"https://api.openai.com/v1"	1795595592
audio.stt.openai.api_key	""	1795595592
audio.stt.openai.api_request_format	"multipart"	1795595592
audio.stt.engine	""	1795595592
audio.stt.model	""	1795595592
audio.stt.supported_content_types	[]	1795595592
audio.stt.allowed_extensions	["mp3", "wav", "m4a", "webm", "ogg", "flac", "mp4", "mpga", "mpeg"]	1795595592
audio.stt.azure.api_key	""	1795595592
audio.stt.azure.region	""	1795595592
audio.stt.azure.locales	""	1795595592
audio.stt.azure.base_url	""	1795595592
audio.stt.azure.max_speakers	""	1795595592
audio.stt.mistral.api_key	""	1795595592
audio.stt.mistral.api_base_url	"https://api.mistral.ai/v1"	1795595592
audio.stt.mistral.use_chat_completions	false	1795595592
audio.tts.openai.api_base_url	"https://api.openai.com/v1"	1795595592
audio.tts.openai.api_key	""	1795595592
audio.tts.openai.params	{}	1795595592
audio.tts.api_key	""	1795595592
audio.tts.engine	""	1795595592
audio.tts.model	"tts-1"	1795595592
audio.tts.voice	"alloy"	1795595592
audio.tts.split_on	"punctuation"	1795595592
audio.tts.azure.speech_region	""	1795595592
audio.tts.azure.speech_base_url	""	1795595592
audio.tts.azure.speech_output_format	"audio-24khz-160kbitrate-mono-mp3"	1795595592
audio.tts.mistral.api_key	""	1795595592
audio.tts.mistral.api_base_url	"https://api.mistral.ai/v1"	1795595592
ui.enable_password_change_form	true	1795595592
ui.default_locale	""	1795595592
ui.default_models	null	1795595592
ui.default_pinned_models	null	1795595592
ui.prompt_suggestions	null	1795595592
ui.prompt_suggestions_i18n	{}	1795595592
ui.model_order_list	[]	1795595592
models.default_metadata	{}	1795595592
models.default_params	{}	1795595592
ui.default_group_id	""	1795595593
ui.default_interface_settings	{}	1795595593
ui.default_user_role	"user"	1795595593
ui.enable_login_form	true	1795595593
ui.enable_signup	false	1795595593
ui.i18n	{}	1795595593
ui.pending_user_overlay_content	""	1795595593
ui.pending_user_overlay_title	""	1795595593
ui.watermark	""	1795595593
webui.url	"https://chat.example.com"	1795595593
subagents.enable	true	1795595592
subagents.background_enabled	false	1795595592
subagents.max_concurrent	20	1795595592
subagents.max_async	20	1795595592
subagents.max_iterations	30	1795595592
subagents.max_output	30000	1795595592
subagents.system_prompt	""	1795595592
automations.auth_token_expires_in	"1h"	1795595592
evaluation.arena.enable	true	1795595592
evaluation.arena.models	[]	1795595592
webhook_url	""	1795595592
task.model.default	""	1795595592
task.model.external	""	1795595592
task.model.params	{}	1795595592
chat.context_compaction.model	""	1795595592
chat.context_compaction.enable	false	1795595592
chat.context_compaction.token_threshold	80000	1795595592
chat.context_compaction.token_cap	null	1795595592
chat.context_compaction.retention_percentage	40	1795595592
chat.context_compaction.prompt_template	""	1795595592
chat.tool_permissions.enable	false	1795595592
task.title.prompt_template	""	1795595592
task.tags.prompt_template	""	1795595592
task.image.prompt_template	""	1795595592
task.follow_up.prompt_template	""	1795595592
task.follow_up.enable	false	1795595592
task.tags.enable	false	1795595592
task.title.enable	false	1795595592
task.query.search.enable	true	1795595592
task.query.retrieval.enable	true	1795595592
task.query.prompt_template	""	1795595592
task.autocomplete.enable	false	1795595592
task.autocomplete.input_max_length	-1	1795595592
task.autocomplete.prompt_template	""	1795595592
task.voice.prompt_template	""	1795595592
task.voice.prompt.enable	true	1795595592
task.tools.prompt_template	""	1795595592
ldap.enable	false	1795595592
ldap.server.label	"LDAP Server"	1795595592
ldap.server.host	"localhost"	1795595592
ldap.server.port	389	1795595592
ldap.server.attribute_for_mail	"mail"	1795595592
ldap.server.attribute_for_username	"uid"	1795595592
ldap.server.app_dn	""	1795595592
ldap.server.app_password	""	1795595592
ldap.server.users_dn	""	1795595592
ldap.server.search_filter	""	1795595592
ldap.server.use_tls	true	1795595592
ldap.server.ca_cert_file	""	1795595592
ldap.server.validate_cert	true	1795595592
ldap.server.ciphers	"ALL"	1795595592
ldap.group.enable_management	false	1795595592
ldap.group.enable_creation	false	1795595592
ldap.server.attribute_for_groups	"memberOf"	1795595592
auth.admin.email	null	1795595593
auth.admin.show	true	1795595593
auth.api_key.allowed_endpoints	""	1795595593
auth.api_key.endpoint_restrictions	false	1795595593
auth.enable_api_keys	false	1795595593
auth.jwt_expiry	"4w"	1795595593
automations.enable	true	1795595593
automations.max_count	""	1795595593
automations.min_interval	""	1795595593
calendar.enable	true	1795595593
channels.enable	true	1795595593
channels.model_response_mode	"thread"	1795595593
folders.enable	true	1795595593
folders.max_file_count	""	1795595593
memories.enable	true	1795595593
memories.system_context.enable	true	1795595593
notes.enable	true	1795595593
ui.enable_community_sharing	false	1795595593
ui.enable_message_rating	true	1795595593
ui.enable_user_webhooks	false	1795595593
users.enable_status	true	1795595593
ui.banners	[{"i18n": null, "id": "upgrade-banner", "type": "info", "title": "Maintenance", "content": "Maintenance on Sunday", "dismissible": true, "timestamp": 1700000000}]	1795595593
user.permissions	{"workspace": {"models": false, "knowledge": false, "prompts": true, "tools": false, "skills": true, "models_import": false, "models_export": false, "prompts_import": false, "prompts_export": false, "tools_import": false, "tools_export": false, "skills_import": false, "skills_export": false}, "sharing": {"models": false, "public_models": false, "knowledge": false, "public_knowledge": false, "prompts": false, "public_prompts": false, "tools": false, "public_tools": false, "skills": false, "public_skills": false, "notes": false, "public_notes": false, "folders": false, "public_chats": false, "open_chats": false, "public_calendars": false}, "access_grants": {"allow_users": true, "allow_groups": true}, "chat": {"controls": true, "valves": true, "system_prompt": true, "params": true, "file_upload": true, "web_upload": true, "delete": false, "delete_message": true, "continue_response": true, "regenerate_response": true, "rate_response": true, "edit": true, "share": true, "export": true, "import": true, "stt": true, "tts": true, "call": true, "multiple_models": true, "temporary": true, "temporary_enforced": false}, "features": {"api_keys": false, "notes": true, "channels": true, "folders": true, "direct_tool_servers": false, "web_search": true, "image_generation": true, "code_interpreter": true, "memories": true, "automations": false, "calendar": true, "webhooks": false}, "settings": {"interface": true}}	1795595593
\.


--
-- Data for Name: config_old; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_old (id, data, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (collection_name, name, title, filename, content, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, user_id, version, type, data, meta, snapshot, created_at, updated_at) FROM stdin;
c589f4b7-ab40-45a0-b979-d87821377e29	e38e3bc0-1dba-4a94-bad6-5a9293febaae	0	rating	{"rating": 1, "model_id": "mock-model", "sibling_model_ids": null, "reason": "Accurate", "comment": null}	{"chat_id": "62b9d5b1-ab3d-4bbc-83b2-253f7b9fd340", "message_id": "8c6de1ee-467b-4553-b868-0e5af17f449b"}	{"chat": {}}	1795595596	1795595596
700d38f2-dc04-44be-b932-7b5ca855326e	478b333b-9c42-454e-9e8d-b0bba24a606a	0	rating	{"rating": 1, "model_id": "mock-model", "sibling_model_ids": null, "reason": "Accurate", "comment": null}	{"chat_id": "101b2385-fc26-49c1-a45b-2667bebab266", "message_id": "744b0678-644e-4489-be16-1834e47fec49"}	{"chat": {}}	1795595597	1795595597
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, user_id, filename, meta, created_at, hash, data, updated_at, path) FROM stdin;
7d60706c-881e-4df8-b390-c3ce1827cd98	0336a46e-791d-4c33-b07f-b62308a04511	handbook.txt	{"name": "handbook.txt", "content_type": "text/plain", "size": 72, "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "data": {}, "collection_name": "6991632e-bbc4-4923-81f0-aa81dde43a1d"}	1795595594	51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb	{"status": "completed", "content": "The upgrade handbook says the lighthouse key hangs behind the blue door.", "error": null}	1795595594	/home/tmp/seed-v0.11.4-y50pch9z/data/uploads/7d60706c-881e-4df8-b390-c3ce1827cd98_handbook.txt
8fc5d428-92b7-44de-9fb7-b07c87bd1b4e	e38e3bc0-1dba-4a94-bad6-5a9293febaae	packing.txt	{"name": "packing.txt", "content_type": "text/plain", "size": 59, "file_hash": "85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a", "data": {}, "collection_name": "file-8fc5d428-92b7-44de-9fb7-b07c87bd1b4e"}	1795595594	85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a	{"status": "completed", "content": "Packing list: umbrella, passport, a very old map of Vienna.", "error": null}	1795595595	/home/tmp/seed-v0.11.4-y50pch9z/data/uploads/8fc5d428-92b7-44de-9fb7-b07c87bd1b4e_packing.txt
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder (id, parent_id, user_id, name, items, meta, is_expanded, created_at, updated_at, data) FROM stdin;
cd9ed40c-1050-49ee-a675-87c515763d35	\N	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Trips	null	null	f	1795595594	1795595594	null
be25165a-edf3-4869-a78c-1a46a2b9b831	cd9ed40c-1050-49ee-a675-87c515763d35	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Vienna	null	null	f	1795595594	1795595594	null
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function (id, user_id, name, type, content, meta, valves, is_active, is_global, updated_at, created_at) FROM stdin;
shout_filter	0336a46e-791d-4c33-b07f-b62308a04511	Shout filter	filter	"""\ntitle: Shout filter\n"""\n\nfrom pydantic import BaseModel\n\n\nclass Filter:\n    class Valves(BaseModel):\n        suffix: str = "!"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def inlet(self, body: dict) -> dict:\n        return body\n	{"description": "Adds emphasis", "manifest": {"title": "Shout filter"}}	{"suffix": "!!!"}	t	t	1795595593	1795595593
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."group" (id, user_id, name, description, data, meta, permissions, created_at, updated_at) FROM stdin;
dce6c37f-8059-4aa9-87f5-420147f5f483	0336a46e-791d-4c33-b07f-b62308a04511	Research	People who read the handbook	{"config": {"share": "members"}}	null	{"workspace": {"models": true}}	1795595593	1795595593
\.


--
-- Data for Name: group_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_member (id, group_id, user_id, created_at, updated_at) FROM stdin;
f1547dd3-3db8-4c4e-b81b-464131c1e0cf	dce6c37f-8059-4aa9-87f5-420147f5f483	e38e3bc0-1dba-4a94-bad6-5a9293febaae	1795595593	1795595593
0d29a326-2dde-453b-a1d0-623be192080a	dce6c37f-8059-4aa9-87f5-420147f5f483	478b333b-9c42-454e-9e8d-b0bba24a606a	1795595593	1795595593
\.


--
-- Data for Name: knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge (id, user_id, name, description, meta, created_at, updated_at, data) FROM stdin;
6991632e-bbc4-4923-81f0-aa81dde43a1d	0336a46e-791d-4c33-b07f-b62308a04511	Handbook	Where things are	null	1795595594	1795595594	\N
\.


--
-- Data for Name: knowledge_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_directory (id, knowledge_id, parent_id, name, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_file (id, user_id, knowledge_id, file_id, created_at, updated_at, directory_id) FROM stdin;
acdfadd3-6a30-49d2-9ac1-cee640a59b98	0336a46e-791d-4c33-b07f-b62308a04511	6991632e-bbc4-4923-81f0-aa81dde43a1d	7d60706c-881e-4df8-b390-c3ce1827cd98	1795595594	1795595594	\N
\.


--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.memory (id, user_id, content, updated_at, created_at, type, path, meta) FROM stdin;
0b64fb4b-8898-4e62-974c-d0cb79e71397	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Alice is allergic to peanuts.	1795595597	1795595597	context	\N	{"created_by": "manual"}
ec8b70e7-f38e-4c5d-8799-575826195729	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Alice prefers window seats.	1795595597	1795595597	context	\N	{"created_by": "manual"}
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (id, user_id, channel_id, content, data, meta, created_at, updated_at, parent_id, reply_to_id, is_pinned, pinned_at, pinned_by) FROM stdin;
2fa0b0e4-163a-40bd-b358-aef649fe7c2b	e38e3bc0-1dba-4a94-bad6-5a9293febaae	dbfa78ac-68a0-4320-a798-d9394f1f3688	Who has the lighthouse key?	null	null	1795595598037711654	1795595598037711654	\N	\N	f	\N	\N
dc145a11-f4d4-491e-9120-610c4bdfaf43	478b333b-9c42-454e-9e8d-b0bba24a606a	dbfa78ac-68a0-4320-a798-d9394f1f3688	Behind the blue door.	null	null	1795595598075912780	1795595598075912780	2fa0b0e4-163a-40bd-b358-aef649fe7c2b	\N	f	\N	\N
\.


--
-- Data for Name: message_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reaction (id, user_id, message_id, name, created_at) FROM stdin;
0d603649-d9b2-4119-ac99-2bde40d6ada8	478b333b-9c42-454e-9e8d-b0bba24a606a	2fa0b0e4-163a-40bd-b358-aef649fe7c2b	thumbsup	1795595598108068953
\.


--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model (id, user_id, base_model_id, name, params, meta, updated_at, created_at, is_active) FROM stdin;
research-assistant	0336a46e-791d-4c33-b07f-b62308a04511	mock-model	Research assistant	{"system": "You answer from the handbook.", "temperature": 0.2}	{"profile_image_url": null, "background_image_url": null, "description": "Answers from the handbook", "i18n": null, "capabilities": null, "knowledge": null}	1795595593	1795595593	t
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (id, user_id, title, data, meta, created_at, updated_at) FROM stdin;
3d338c56-f7a8-414b-b183-79e86de65424	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Groceries	{"content": {"md": "# Groceries\\n\\n- apples\\n- *dark* chocolate", "html": "", "json": null}}	null	1795595597946961705	1795595597946962156
\.


--
-- Data for Name: oauth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_session (id, user_id, provider, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pinned_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_note (id, user_id, note_id, created_at) FROM stdin;
\.


--
-- Data for Name: prompt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt (id, command, user_id, name, content, data, meta, is_active, version_id, tags, created_at, updated_at) FROM stdin;
6932d9de-28ed-496c-8517-89ee0340f1fc	summarize	0336a46e-791d-4c33-b07f-b62308a04511	Summarize	Summarize the following text in three bullet points.	{}	{}	t	56802d5b-6501-40c6-9041-6dc247197f45	[]	1795595593	1795595593
7bc1548b-9db5-44db-8beb-f0061475859d	alice-draft	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Alice's draft	Draft a polite reply to this email.	{}	{}	t	0384dfa7-690f-4fc5-8145-655fdb242f7e	[]	1795595593	1795595593
\.


--
-- Data for Name: prompt_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt_history (id, prompt_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
56802d5b-6501-40c6-9041-6dc247197f45	6932d9de-28ed-496c-8517-89ee0340f1fc	\N	{"name": "Summarize", "content": "Summarize the following text in three bullet points.", "command": "summarize", "data": {}, "meta": {}, "tags": [], "access_grants": [{"id": "187c19ef-91e6-45b1-b8f0-2699096b69df", "resource_type": "prompt", "resource_id": "6932d9de-28ed-496c-8517-89ee0340f1fc", "principal_type": "group", "principal_id": "dce6c37f-8059-4aa9-87f5-420147f5f483", "permission": "read", "created_at": 1795595593}]}	0336a46e-791d-4c33-b07f-b62308a04511	Initial version	1795595593
0384dfa7-690f-4fc5-8145-655fdb242f7e	7bc1548b-9db5-44db-8beb-f0061475859d	\N	{"name": "Alice's draft", "content": "Draft a polite reply to this email.", "command": "alice-draft", "data": {}, "meta": {}, "tags": [], "access_grants": []}	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Initial version	1795595593
\.


--
-- Data for Name: shared_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shared_chat (id, chat_id, user_id, title, chat, created_at, updated_at) FROM stdin;
aeef3cd9-4d6e-4dc4-9e79-45f48ec1ab54	dc526bbd-1f51-4db6-afff-a47d8192d059	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Packing for Vienna	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "8fc5d428-92b7-44de-9fb7-b07c87bd1b4e", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1795595595, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1795595596}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1795595597}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1795595598, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1795595599}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "8fc5d428-92b7-44de-9fb7-b07c87bd1b4e", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1795595595, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1795595597}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1795595598, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1795595599}], "files": [{"type": "file", "id": "8fc5d428-92b7-44de-9fb7-b07c87bd1b4e", "name": "packing.txt", "status": "uploaded"}], "params": {}}	1795595595	1795595595
\.


--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill (id, user_id, name, description, content, meta, is_active, updated_at, created_at) FROM stdin;
trip-planner	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Trip planner	Plans multi-city trips by train.	---\nname: trip-planner\ndescription: Plans multi-city trips by train.\n---\n\n# Trip planner\n\n1. Ask for the cities and the dates.\n2. Prefer night trains over flights.\n3. Keep every transfer above 40 minutes.\n4. Name the platform for every departure.\n	{"i18n": null, "tags": ["travel"]}	t	1795595594	1795595593
uebersetzer	e38e3bc0-1dba-4a94-bad6-5a9293febaae	Übersetzer 日本語 🚀		# Übersetzer 🌍\r\n\r\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\r\n\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \r\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\r\n	{"i18n": null, "tags": []}	t	1795595594	1795595594
old-habits	478b333b-9c42-454e-9e8d-b0bba24a606a	Old habits	\N	Answer in Latin.	{"i18n": null, "tags": []}	f	1795595594	1795595594
house-style	0336a46e-791d-4c33-b07f-b62308a04511	House style	How every answer is formatted.	Use sentence case headings and no exclamation marks.	{"i18n": null, "tags": []}	t	1795595594	1795595594
dave-notes	1ff7bc72-b933-4c00-b515-fb9270511fed	Dave's notes	Left behind.	Hand over to the next shift at six.	{"i18n": null, "tags": []}	t	1795595594	1795595594
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tag (id, name, user_id, meta) FROM stdin;
travel	travel	e38e3bc0-1dba-4a94-bad6-5a9293febaae	\N
\.


--
-- Data for Name: tool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool (id, user_id, name, content, specs, meta, valves, updated_at, created_at) FROM stdin;
weather_tool	0336a46e-791d-4c33-b07f-b62308a04511	Weather	"""\ntitle: Weather\n"""\n\n\nfrom pydantic import BaseModel\n\n\nclass Tools:\n    class Valves(BaseModel):\n        units: str = "metric"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def get_weather(self, city: str) -> str:\n        """Report the weather in a city."""\n        return f"Sunny in {city}"\n	[{"name": "get_weather", "description": "Report the weather in a city.", "parameters": {"properties": {"city": {"type": "string"}}, "required": ["city"], "type": "object"}}]	{"i18n": null, "description": "Weather lookups", "manifest": {"title": "Weather"}, "has_user_valves": false}	\N	1795595593	1795595593
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, role, profile_image_url, last_active_at, updated_at, created_at, settings, info, username, bio, gender, date_of_birth, profile_banner_image_url, timezone, presence_state, status_emoji, status_message, status_expires_at, oauth, scim, variables) FROM stdin;
0336a46e-791d-4c33-b07f-b62308a04511	Ada Admin	admin@example.com	admin	/user.png	1795595592	1795595592	1795595592	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
347d1d8f-819b-499c-9949-449e1784cc3d	Carol Outsider	carol@example.com	user	/user.png	1795595593	1795595593	1795595593	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
e38e3bc0-1dba-4a94-bad6-5a9293febaae	Alice Author	alice@example.com	user	/user.png	1795595593	1795595592	1795595592	{"ui": {"theme": "dark", "chatBubble": false, "notesSeen": 3}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
478b333b-9c42-454e-9e8d-b0bba24a606a	Bob Reader	bob@example.com	user	/user.png	1795595593	1795595592	1795595592	{"ui": {"models": ["research-assistant"]}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
\.


--
-- Name: config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_id_seq', 1, false);


--
-- Name: access_grant access_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT access_grant_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_key UNIQUE (key);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: automation automation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation
    ADD CONSTRAINT automation_pkey PRIMARY KEY (id);


--
-- Name: automation_run automation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_run
    ADD CONSTRAINT automation_run_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendee calendar_event_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT calendar_event_attendee_pkey PRIMARY KEY (id);


--
-- Name: calendar_event calendar_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event
    ADD CONSTRAINT calendar_event_pkey PRIMARY KEY (id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (id);


--
-- Name: channel_file channel_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_pkey PRIMARY KEY (id);


--
-- Name: channel_member channel_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT channel_member_pkey PRIMARY KEY (id);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_webhook channel_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_pkey PRIMARY KEY (id);


--
-- Name: chat_file chat_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: chat chat_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_share_id_key UNIQUE (share_id);


--
-- Name: chatidtag chatidtag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chatidtag
    ADD CONSTRAINT chatidtag_pkey PRIMARY KEY (id);


--
-- Name: config_old config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey1 PRIMARY KEY (key);


--
-- Name: document document_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_name_key UNIQUE (name);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (collection_name);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id, user_id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: group_member group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_pkey PRIMARY KEY (id);


--
-- Name: group group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pkey PRIMARY KEY (id);


--
-- Name: knowledge_directory knowledge_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_pkey PRIMARY KEY (id);


--
-- Name: knowledge_file knowledge_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_pkey PRIMARY KEY (id);


--
-- Name: knowledge knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge
    ADD CONSTRAINT knowledge_pkey PRIMARY KEY (id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: message_reaction message_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reaction
    ADD CONSTRAINT message_reaction_pkey PRIMARY KEY (id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: oauth_session oauth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_pkey PRIMARY KEY (id);


--
-- Name: pinned_note pinned_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_pkey PRIMARY KEY (id);


--
-- Name: tag pk_id_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_id_user_id PRIMARY KEY (id, user_id);


--
-- Name: prompt_history prompt_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt_history
    ADD CONSTRAINT prompt_history_pkey PRIMARY KEY (id);


--
-- Name: prompt prompt_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt
    ADD CONSTRAINT prompt_new_pkey PRIMARY KEY (id);


--
-- Name: shared_chat shared_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_pkey PRIMARY KEY (id);


--
-- Name: skill skill_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_name_key UNIQUE (name);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- Name: tool tool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool
    ADD CONSTRAINT tool_pkey PRIMARY KEY (id);


--
-- Name: access_grant uq_access_grant_grant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT uq_access_grant_grant UNIQUE (resource_type, resource_id, principal_type, principal_id, permission);


--
-- Name: channel_file uq_channel_file_channel_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT uq_channel_file_channel_file UNIQUE (channel_id, file_id);


--
-- Name: chat_file uq_chat_file_chat_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT uq_chat_file_chat_file UNIQUE (chat_id, file_id);


--
-- Name: calendar_event_attendee uq_event_attendee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT uq_event_attendee UNIQUE (event_id, user_id);


--
-- Name: group_member uq_group_member_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT uq_group_member_group_user UNIQUE (group_id, user_id);


--
-- Name: knowledge_directory uq_knowledge_directory_knowledge_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT uq_knowledge_directory_knowledge_parent_name UNIQUE (knowledge_id, parent_id, name);


--
-- Name: knowledge_file uq_knowledge_file_knowledge_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT uq_knowledge_file_knowledge_file UNIQUE (knowledge_id, file_id);


--
-- Name: pinned_note uq_pinned_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT uq_pinned_note UNIQUE (user_id, note_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: chat_message_chat_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_parent_idx ON public.chat_message USING btree (chat_id, parent_id);


--
-- Name: chat_message_chat_role_done_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_role_done_idx ON public.chat_message USING btree (chat_id, role, done);


--
-- Name: chat_message_model_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_model_created_idx ON public.chat_message USING btree (model_id, created_at);


--
-- Name: chat_message_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_user_created_idx ON public.chat_message USING btree (user_id, created_at);


--
-- Name: folder_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_idx ON public.chat USING btree (folder_id);


--
-- Name: folder_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_user_id_idx ON public.chat USING btree (folder_id, user_id);


--
-- Name: idx_access_grant_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_principal ON public.access_grant USING btree (principal_type, principal_id);


--
-- Name: idx_access_grant_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_resource ON public.access_grant USING btree (resource_type, resource_id);


--
-- Name: idx_oauth_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_expires_at ON public.oauth_session USING btree (expires_at);


--
-- Name: idx_oauth_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_id ON public.oauth_session USING btree (user_id);


--
-- Name: idx_oauth_session_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_provider ON public.oauth_session USING btree (user_id, provider);


--
-- Name: idx_skill_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_updated_at ON public.skill USING btree (updated_at);


--
-- Name: idx_skill_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_user_id ON public.skill USING btree (user_id);


--
-- Name: is_global_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX is_global_idx ON public.function USING btree (is_global);


--
-- Name: ix_automation_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_next_run ON public.automation USING btree (next_run_at);


--
-- Name: ix_automation_run_automation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_run_automation_id ON public.automation_run USING btree (automation_id);


--
-- Name: ix_automation_user_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_user_folder ON public.automation USING btree (user_id, folder_id);


--
-- Name: ix_calendar_event_attendee_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_attendee_user ON public.calendar_event_attendee USING btree (user_id, status);


--
-- Name: ix_calendar_event_calendar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_calendar ON public.calendar_event USING btree (calendar_id, start_at);


--
-- Name: ix_calendar_event_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_user_date ON public.calendar_event USING btree (user_id, start_at);


--
-- Name: ix_calendar_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_user ON public.calendar USING btree (user_id);


--
-- Name: ix_channel_file_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_channel_id ON public.channel_file USING btree (channel_id);


--
-- Name: ix_channel_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_file_id ON public.channel_file USING btree (file_id);


--
-- Name: ix_channel_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_user_id ON public.channel_file USING btree (user_id);


--
-- Name: ix_chat_file_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_chat_id ON public.chat_file USING btree (chat_id);


--
-- Name: ix_chat_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_file_id ON public.chat_file USING btree (file_id);


--
-- Name: ix_chat_file_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_message_id ON public.chat_file USING btree (message_id);


--
-- Name: ix_chat_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_user_id ON public.chat_file USING btree (user_id);


--
-- Name: ix_chat_message_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_chat_id ON public.chat_message USING btree (chat_id);


--
-- Name: ix_chat_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_created_at ON public.chat_message USING btree (created_at);


--
-- Name: ix_chat_message_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_model_id ON public.chat_message USING btree (model_id);


--
-- Name: ix_chat_message_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_user_id ON public.chat_message USING btree (user_id);


--
-- Name: ix_group_member_user_id_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_group_member_user_id_group_id ON public.group_member USING btree (user_id, group_id);


--
-- Name: ix_knowledge_directory_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_knowledge_id ON public.knowledge_directory USING btree (knowledge_id);


--
-- Name: ix_knowledge_directory_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_parent_id ON public.knowledge_directory USING btree (parent_id);


--
-- Name: ix_knowledge_file_directory_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_directory_id ON public.knowledge_file USING btree (directory_id);


--
-- Name: ix_knowledge_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_file_id ON public.knowledge_file USING btree (file_id);


--
-- Name: ix_knowledge_file_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_knowledge_id ON public.knowledge_file USING btree (knowledge_id);


--
-- Name: ix_knowledge_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_user_id ON public.knowledge_file USING btree (user_id);


--
-- Name: ix_memory_id_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_id_user_id ON public.memory USING btree (id, user_id);


--
-- Name: ix_memory_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_type ON public.memory USING btree (type);


--
-- Name: ix_memory_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_user_id ON public.memory USING btree (user_id);


--
-- Name: ix_prompt_history_prompt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompt_history_prompt_id ON public.prompt_history USING btree (prompt_id);


--
-- Name: ix_prompt_new_command; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_prompt_new_command ON public.prompt USING btree (command);


--
-- Name: timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX timer_at_idx ON public.chat USING btree (timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: updated_at_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX updated_at_user_id_idx ON public.chat USING btree (updated_at, user_id);


--
-- Name: uq_user_email_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_user_email_lower ON public."user" USING btree (lower((email)::text)) WHERE (email IS NOT NULL);


--
-- Name: user_id_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_archived_idx ON public.chat USING btree (user_id, archived);


--
-- Name: user_id_folder_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_folder_unread_idx ON public.chat USING btree (user_id, folder_id, archived, updated_at, last_read_at, id);


--
-- Name: user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_idx ON public.tag USING btree (user_id);


--
-- Name: user_id_pinned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_pinned_idx ON public.chat USING btree (user_id, pinned);


--
-- Name: user_id_timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_timer_at_idx ON public.chat USING btree (user_id, timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: user_id_updated_at_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_updated_at_id_idx ON public.chat USING btree (user_id, updated_at DESC, id);


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: channel_webhook channel_webhook_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: chat_message chat_message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: channel_file fk_channel_file_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT fk_channel_file_message_id FOREIGN KEY (message_id) REFERENCES public.message(id) ON DELETE CASCADE;


--
-- Name: knowledge_file fk_knowledge_file_directory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT fk_knowledge_file_directory_id FOREIGN KEY (directory_id) REFERENCES public.knowledge_directory(id) ON DELETE SET NULL;


--
-- Name: group_member group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: group_member group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_directory(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: oauth_session oauth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: pinned_note pinned_note_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id) ON DELETE CASCADE;


--
-- Name: shared_chat shared_chat_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

