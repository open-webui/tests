--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_grant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_grant (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    user_id text,
    key text NOT NULL,
    data json,
    expires_at bigint,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth (
    id character varying NOT NULL,
    email character varying,
    password text,
    active boolean
);


--
-- Name: automation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    data json NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    folder_id text
);


--
-- Name: automation_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_run (
    id text NOT NULL,
    automation_id text NOT NULL,
    chat_id text,
    status text NOT NULL,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    color text,
    is_default boolean NOT NULL,
    data json,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event (
    id text NOT NULL,
    calendar_id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    start_at bigint NOT NULL,
    end_at bigint,
    all_day boolean NOT NULL,
    rrule text,
    color text,
    location text,
    data json,
    meta json,
    is_cancelled boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event_attendee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendee (
    id text NOT NULL,
    event_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    type text,
    is_private boolean,
    archived_at bigint,
    archived_by text,
    deleted_at bigint,
    deleted_by text,
    updated_by text
);


--
-- Name: channel_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_file (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    message_id text
);


--
-- Name: channel_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_member (
    id text NOT NULL,
    channel_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    status text,
    is_active boolean DEFAULT true NOT NULL,
    is_channel_muted boolean DEFAULT false NOT NULL,
    is_channel_pinned boolean DEFAULT false NOT NULL,
    data json,
    meta json,
    joined_at bigint NOT NULL,
    left_at bigint,
    last_read_at bigint,
    updated_at bigint,
    role text,
    invited_by text,
    invited_at bigint
);


--
-- Name: channel_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_webhook (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    profile_image_url text,
    token text NOT NULL,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    user_id character varying,
    title text,
    created_at bigint,
    updated_at bigint,
    share_id text,
    archived boolean,
    chat json,
    pinned boolean,
    meta json DEFAULT '{}'::json NOT NULL,
    folder_id text,
    tasks json,
    summary text,
    last_read_at bigint,
    current_message_id text,
    variables json,
    timer_at bigint
);


--
-- Name: chat_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_file (
    id text NOT NULL,
    user_id text NOT NULL,
    chat_id text NOT NULL,
    file_id text NOT NULL,
    message_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text,
    role text NOT NULL,
    parent_id text,
    content json,
    output json,
    model_id text,
    files json,
    sources json,
    embeds json,
    done boolean,
    status_history json,
    error json,
    usage json,
    created_at bigint,
    updated_at bigint,
    context_summary text,
    meta json
);


--
-- Name: chatidtag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chatidtag (
    id character varying NOT NULL,
    tag_name character varying,
    chat_id character varying,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    key text NOT NULL,
    value json NOT NULL,
    updated_at bigint
);


--
-- Name: config_old; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_old (
    id integer NOT NULL,
    data json NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config_old.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    collection_name character varying NOT NULL,
    name character varying,
    title text,
    filename text,
    content text,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    user_id text,
    version bigint,
    type text,
    data json,
    meta json,
    snapshot json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id character varying NOT NULL,
    user_id character varying,
    filename text,
    meta json,
    created_at bigint,
    hash text,
    data json,
    updated_at bigint,
    path text
);


--
-- Name: folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder (
    id text NOT NULL,
    parent_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    items json,
    meta json,
    is_expanded boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    data json
);


--
-- Name: function; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    type text,
    content text,
    meta text,
    valves text,
    is_active boolean,
    is_global boolean,
    updated_at bigint,
    created_at bigint
);


--
-- Name: group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."group" (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    permissions json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: group_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_member (
    id text NOT NULL,
    group_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    updated_at bigint
);


--
-- Name: knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint,
    data json
);


--
-- Name: knowledge_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_directory (
    id text NOT NULL,
    knowledge_id text NOT NULL,
    parent_id text,
    name text NOT NULL,
    user_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: knowledge_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_file (
    id text NOT NULL,
    user_id text NOT NULL,
    knowledge_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    directory_id text
);


--
-- Name: memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory (
    id character varying NOT NULL,
    user_id character varying,
    content text,
    updated_at bigint,
    created_at bigint,
    type character varying DEFAULT 'context'::character varying NOT NULL,
    path text,
    meta json
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    id text NOT NULL,
    user_id text,
    channel_id text,
    content text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    parent_id text,
    reply_to_id text,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at bigint,
    pinned_by text
);


--
-- Name: message_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    message_id text NOT NULL,
    name text NOT NULL,
    created_at bigint
);


--
-- Name: model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model (
    id text NOT NULL,
    user_id text,
    base_model_id text,
    name text,
    params text,
    meta text,
    updated_at bigint,
    created_at bigint,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    id text NOT NULL,
    user_id text,
    title text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: oauth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_session (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pinned_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_note (
    id text NOT NULL,
    user_id text NOT NULL,
    note_id text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: prompt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt (
    id text NOT NULL,
    command character varying,
    user_id character varying NOT NULL,
    name text NOT NULL,
    content text NOT NULL,
    data json,
    meta json,
    is_active boolean DEFAULT true NOT NULL,
    version_id text,
    tags json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: prompt_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt_history (
    id text NOT NULL,
    prompt_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: shared_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_chat (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text NOT NULL,
    title text,
    chat json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    updated_at bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tag (
    id character varying NOT NULL,
    name character varying,
    user_id character varying NOT NULL,
    meta json
);


--
-- Name: tool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    content text,
    specs text,
    meta text,
    valves text,
    updated_at bigint,
    created_at bigint
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id character varying NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    profile_image_url text,
    last_active_at bigint,
    updated_at bigint,
    created_at bigint,
    settings json,
    info json,
    username character varying(50),
    bio text,
    gender text,
    date_of_birth date,
    profile_banner_image_url text,
    timezone character varying,
    presence_state character varying,
    status_emoji character varying,
    status_message text,
    status_expires_at bigint,
    oauth json,
    scim json,
    variables json
);


--
-- Name: config_old id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Data for Name: access_grant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_grant (id, resource_type, resource_id, principal_type, principal_id, permission, created_at) FROM stdin;
f10d63ab-cd0f-4ebc-8476-6b5302132926	prompt	f71c2a2d-565e-46fb-bcf8-e929559bd196	group	a028c6c0-14af-49ba-a28b-5839bd07a2ee	read	1791343674
15eff4f4-da72-4069-b628-ab052ac3c94b	tool	weather_tool	group	a028c6c0-14af-49ba-a28b-5839bd07a2ee	read	1791343674
75645147-4c2b-4e35-947c-334bbe4cc815	model	research-assistant	user	5d82715e-c330-4799-8e17-44dce0a501e5	read	1791343674
8878c771-738e-45ca-a84b-3e7faaf46b38	knowledge	a794af32-79bf-4c4d-afd6-a85bc52dc6c0	group	a028c6c0-14af-49ba-a28b-5839bd07a2ee	read	1791343674
850eb733-976b-49ab-ba6f-dd035ad8fdd3	shared_chat	8c0e5d67-6079-4b47-a1ec-15a3f1bc7172	user	5d82715e-c330-4799-8e17-44dce0a501e5	read	1791343674
9f1a1613-27d0-4373-9fa8-ca9a88db931a	note	9139440d-5cc4-4b76-a1cd-59ed1dd30372	user	5d82715e-c330-4799-8e17-44dce0a501e5	read	1791343675
dd16ec48-eb84-44a3-b3b4-ade84bfcfa0f	note	9139440d-5cc4-4b76-a1cd-59ed1dd30372	user	5d82715e-c330-4799-8e17-44dce0a501e5	write	1791343675
a3b60305-2b6f-4685-9741-58430f0a3d29	channel	24e8ede3-1e38-4df8-a34e-551ded61c838	group	a028c6c0-14af-49ba-a28b-5839bd07a2ee	read	1791343675
09ac8f96-dd23-44b3-aeda-fdb976430c52	channel	24e8ede3-1e38-4df8-a34e-551ded61c838	group	a028c6c0-14af-49ba-a28b-5839bd07a2ee	write	1791343675
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
d4c1a8e37b62
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, user_id, key, data, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth (id, email, password, active) FROM stdin;
bd076204-9166-4119-a5ce-12e2343ebbb9	admin@example.com	$2b$12$zgNym.TWXg7KkbNrQr9S3ekT2A7gG5vAp64RRHN1Oe8ffg6wqrfW.	t
4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	alice@example.com	$2b$12$71c7C/rberfs/.XnpakPBePTqezJZX1t1gcu0TZp6/idOw53Tcg4C	t
5d82715e-c330-4799-8e17-44dce0a501e5	bob@example.com	$2b$12$FS5S38DL/f4lULs.rU014OO.wD7XUJSO67nHhMWRZ2yxgpWBp2bjm	t
151fadc6-ff7c-491b-be89-10fbd66f049a	carol@example.com	$2b$12$aqUIweajNw6PsBOoB9biMehIWGGCgVtA9AG8NBOffq7BIaFZBMeby	t
\.


--
-- Data for Name: automation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation (id, user_id, name, data, meta, is_active, last_run_at, next_run_at, created_at, updated_at, folder_id) FROM stdin;
\.


--
-- Data for Name: automation_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_run (id, automation_id, chat_id, status, error, created_at) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar (id, user_id, name, color, is_default, data, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event (id, calendar_id, user_id, title, description, start_at, end_at, all_day, rrule, color, location, data, meta, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendee (id, event_id, user_id, status, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel (id, user_id, name, description, data, meta, created_at, updated_at, type, is_private, archived_at, archived_by, deleted_at, deleted_by, updated_by) FROM stdin;
24e8ede3-1e38-4df8-a34e-551ded61c838	bd076204-9166-4119-a5ce-12e2343ebbb9	lighthouse	Team chatter	null	null	1791343675249930894	1791343675249931355	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: channel_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_file (id, user_id, channel_id, file_id, created_at, updated_at, message_id) FROM stdin;
\.


--
-- Data for Name: channel_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_member (id, channel_id, user_id, created_at, status, is_active, is_channel_muted, is_channel_pinned, data, meta, joined_at, left_at, last_read_at, updated_at, role, invited_by, invited_at) FROM stdin;
1ef15c66-22fb-4b56-93e4-b9f6478c56ef	24e8ede3-1e38-4df8-a34e-551ded61c838	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	1791343675280515825	joined	t	f	f	null	null	1791343675280515254	\N	1791343675280515624	1791343675280515965	\N	\N	\N
f14879fc-3cd8-44fb-950c-dcef5a98fd9c	24e8ede3-1e38-4df8-a34e-551ded61c838	5d82715e-c330-4799-8e17-44dce0a501e5	1791343675322217504	joined	t	f	f	null	null	1791343675322217093	\N	1791343675322217403	1791343675322217694	\N	\N	\N
\.


--
-- Data for Name: channel_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_webhook (id, user_id, channel_id, name, profile_image_url, token, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat (id, user_id, title, created_at, updated_at, share_id, archived, chat, pinned, meta, folder_id, tasks, summary, last_read_at, current_message_id, variables, timer_at) FROM stdin;
8c0e5d67-6079-4b47-a1ec-15a3f1bc7172	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Packing for Vienna	1791343674	1791343674	4050a36c-fce4-48fa-9d0c-a5a5f1e9e2db	f	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "e7970ec9-da96-48ce-a161-9c7cab82dde8", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1791343674, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1791343675}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1791343676}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1791343677, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1791343678}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "e7970ec9-da96-48ce-a161-9c7cab82dde8", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1791343674, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1791343676}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1791343677, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1791343678}], "files": [{"type": "file", "id": "e7970ec9-da96-48ce-a161-9c7cab82dde8", "name": "packing.txt", "status": "uploaded"}], "params": {}}	t	{"tags": ["travel"]}	ad6104cb-639c-478c-87e9-1c595312dfb9	null	\N	1791343674	a2-0000-4000-8000-000000000000	{}	\N
fa19215a-3190-4406-9f60-1ca426fb84f3	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Schnitzel questions	1791343674	1791343674	\N	f	{"id": "fa19215a-3190-4406-9f60-1ca426fb84f3", "title": "Schnitzel questions", "models": ["mock-model"], "history": {"currentId": "3e837281-bd3f-41f2-bc2b-ab2677d5e3fd", "messages": {"d72d402d-a176-4abd-acb3-b1cd23f67af5": {"id": "d72d402d-a176-4abd-acb3-b1cd23f67af5", "parentId": null, "childrenIds": ["5e0bf3c5-5151-4599-b133-5a0224680bb6"], "role": "user", "content": "What is a Schnitzel?", "models": ["mock-model"], "timestamp": 1791343674}, "5e0bf3c5-5151-4599-b133-5a0224680bb6": {"id": "5e0bf3c5-5151-4599-b133-5a0224680bb6", "parentId": "d72d402d-a176-4abd-acb3-b1cd23f67af5", "childrenIds": ["153c433a-865f-47f0-98fc-02bab6ad92bc"], "role": "assistant", "content": "Schnitzel is a breaded cutlet.", "done": true, "model": "mock-model", "timestamp": 1791343674, "output": [{"type": "message", "id": "msg_912ff6c5fde9400cb9be1c7f", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]}, "153c433a-865f-47f0-98fc-02bab6ad92bc": {"id": "153c433a-865f-47f0-98fc-02bab6ad92bc", "parentId": "5e0bf3c5-5151-4599-b133-5a0224680bb6", "childrenIds": ["3e837281-bd3f-41f2-bc2b-ab2677d5e3fd"], "role": "user", "content": "How do I eat it?", "models": ["mock-model"], "timestamp": 1791343674}, "3e837281-bd3f-41f2-bc2b-ab2677d5e3fd": {"id": "3e837281-bd3f-41f2-bc2b-ab2677d5e3fd", "parentId": "153c433a-865f-47f0-98fc-02bab6ad92bc", "childrenIds": [], "role": "assistant", "content": "Try it with lemon.", "done": true, "model": "mock-model", "timestamp": 1791343674, "output": [{"type": "message", "id": "msg_12275c50735a4262a6b9b5a8", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]}}}, "messages": [{"role": "user", "content": "What is a Schnitzel?"}], "files": [], "tags": [], "timestamp": 1791343674551}	f	{}	\N	null	\N	1791343674	3e837281-bd3f-41f2-bc2b-ab2677d5e3fd	{}	\N
659faa89-4c8d-4e04-b6bc-0597624d8110	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Old plans	1791343675	1791343675	\N	t	{"title": "Old plans", "models": ["mock-model"], "history": {}}	f	{}	\N	null	\N	1791343675	\N	{}	\N
2f365735-cfc9-4299-aabe-e4eb140eadde	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Lighthouse key	1791343674	1791343675	\N	f	{"id": "2f365735-cfc9-4299-aabe-e4eb140eadde", "title": "Lighthouse key", "models": ["mock-model"], "history": {"currentId": "69bf501c-837c-46b4-9e04-f0e50e152db1", "messages": {"ed00642e-f064-48a7-88b9-4e350f011d25": {"id": "ed00642e-f064-48a7-88b9-4e350f011d25", "parentId": null, "childrenIds": ["69bf501c-837c-46b4-9e04-f0e50e152db1"], "role": "user", "content": "Where does the lighthouse key hang?", "models": ["mock-model"], "timestamp": 1791343674, "files": [{"type": "collection", "id": "a794af32-79bf-4c4d-afd6-a85bc52dc6c0", "name": "Handbook"}]}, "69bf501c-837c-46b4-9e04-f0e50e152db1": {"id": "69bf501c-837c-46b4-9e04-f0e50e152db1", "parentId": "ed00642e-f064-48a7-88b9-4e350f011d25", "childrenIds": [], "role": "assistant", "content": "Behind the blue door [1].", "done": true, "model": "mock-model", "timestamp": 1791343674, "statusHistory": [{"action": "queries_generated", "queries": ["ok"], "done": false}, {"action": "sources_retrieved", "count": 1, "done": true}], "sources": [{"source": {"type": "collection", "id": "a794af32-79bf-4c4d-afd6-a85bc52dc6c0", "name": "Handbook"}, "document": ["The upgrade handbook says the lighthouse key hangs behind the blue door."], "metadata": [{"embedding_config": "{'engine': 'openai', 'model': 'sentence-transformers/all-MiniLM-L6-v2'}", "source": "handbook.txt", "hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "content_type": "text/plain", "file_id": "b59d0b41-a6a9-435c-b4d5-23ebc5fca920", "start_index": 0, "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "size": 72, "name": "handbook.txt", "created_by": "bd076204-9166-4119-a5ce-12e2343ebbb9"}], "distances": [0.9999999403953552]}], "output": [{"type": "message", "id": "msg_ebcd3c564c0145028fc176e6", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Behind the blue door [1]."}]}]}}}, "messages": [{"role": "user", "content": "Where does the lighthouse key hang?"}], "files": [{"type": "collection", "id": "a794af32-79bf-4c4d-afd6-a85bc52dc6c0", "name": "Handbook"}], "tags": [], "timestamp": 1791343674881}	f	{}	\N	null	\N	1791343674	69bf501c-837c-46b4-9e04-f0e50e152db1	{}	\N
\.


--
-- Data for Name: chat_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_file (id, user_id, chat_id, file_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_message (id, chat_id, user_id, role, parent_id, content, output, model_id, files, sources, embeds, done, status_history, error, usage, created_at, updated_at, context_summary, meta) FROM stdin;
8c0e5d67-6079-4b47-a1ec-15a3f1bc7172-u1-0000-4000-8000-000000000000	8c0e5d67-6079-4b47-a1ec-15a3f1bc7172	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	user	\N	"What should I pack for Vienna?"	null	\N	[{"type": "file", "id": "e7970ec9-da96-48ce-a161-9c7cab82dde8", "name": "packing.txt", "status": "uploaded"}]	null	null	t	null	null	null	1791343674	1791343674	\N	null
8c0e5d67-6079-4b47-a1ec-15a3f1bc7172-a1-0000-4000-8000-000000000000	8c0e5d67-6079-4b47-a1ec-15a3f1bc7172	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	assistant	u1-0000-4000-8000-000000000000	"Pack an umbrella."	null	mock-model	null	null	null	t	null	null	null	1791343675	1791343674	\N	null
8c0e5d67-6079-4b47-a1ec-15a3f1bc7172-a1b-0000-4000-8000-000000000000	8c0e5d67-6079-4b47-a1ec-15a3f1bc7172	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	assistant	u1-0000-4000-8000-000000000000	"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses."	null	mock-model	null	null	null	t	null	null	null	1791343676	1791343674	\N	null
8c0e5d67-6079-4b47-a1ec-15a3f1bc7172-u2-0000-4000-8000-000000000000	8c0e5d67-6079-4b47-a1ec-15a3f1bc7172	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	user	a1b-0000-4000-8000-000000000000	"And for the evening?"	null	\N	null	null	null	t	null	null	null	1791343677	1791343674	\N	null
8c0e5d67-6079-4b47-a1ec-15a3f1bc7172-a2-0000-4000-8000-000000000000	8c0e5d67-6079-4b47-a1ec-15a3f1bc7172	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	assistant	u2-0000-4000-8000-000000000000	"A light jacket."	null	mock-model	null	null	null	t	null	null	null	1791343678	1791343674	\N	null
fa19215a-3190-4406-9f60-1ca426fb84f3-d72d402d-a176-4abd-acb3-b1cd23f67af5	fa19215a-3190-4406-9f60-1ca426fb84f3	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	user	\N	"What is a Schnitzel?"	null	\N	null	null	null	t	null	null	null	1791343674	1791343674	\N	null
fa19215a-3190-4406-9f60-1ca426fb84f3-5e0bf3c5-5151-4599-b133-5a0224680bb6	fa19215a-3190-4406-9f60-1ca426fb84f3	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	assistant	d72d402d-a176-4abd-acb3-b1cd23f67af5	"Schnitzel is a breaded cutlet."	[{"type": "message", "id": "msg_912ff6c5fde9400cb9be1c7f", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]	mock-model	null	null	null	t	null	null	null	1791343674	1791343674	\N	null
fa19215a-3190-4406-9f60-1ca426fb84f3-153c433a-865f-47f0-98fc-02bab6ad92bc	fa19215a-3190-4406-9f60-1ca426fb84f3	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	user	5e0bf3c5-5151-4599-b133-5a0224680bb6	"How do I eat it?"	null	\N	null	null	null	t	null	null	null	1791343674	1791343674	\N	null
fa19215a-3190-4406-9f60-1ca426fb84f3-3e837281-bd3f-41f2-bc2b-ab2677d5e3fd	fa19215a-3190-4406-9f60-1ca426fb84f3	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	assistant	153c433a-865f-47f0-98fc-02bab6ad92bc	"Try it with lemon."	[{"type": "message", "id": "msg_12275c50735a4262a6b9b5a8", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]	mock-model	null	null	null	t	null	null	null	1791343674	1791343674	\N	null
2f365735-cfc9-4299-aabe-e4eb140eadde-69bf501c-837c-46b4-9e04-f0e50e152db1	2f365735-cfc9-4299-aabe-e4eb140eadde	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	assistant	ed00642e-f064-48a7-88b9-4e350f011d25	"Behind the blue door [1]."	[{"type": "message", "id": "msg_ebcd3c564c0145028fc176e6", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Behind the blue door [1]."}]}]	mock-model	null	[{"source": {"type": "collection", "id": "a794af32-79bf-4c4d-afd6-a85bc52dc6c0", "name": "Handbook"}, "document": ["The upgrade handbook says the lighthouse key hangs behind the blue door."], "metadata": [{"embedding_config": "{'engine': 'openai', 'model': 'sentence-transformers/all-MiniLM-L6-v2'}", "source": "handbook.txt", "hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "content_type": "text/plain", "file_id": "b59d0b41-a6a9-435c-b4d5-23ebc5fca920", "start_index": 0, "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "size": 72, "name": "handbook.txt", "created_by": "bd076204-9166-4119-a5ce-12e2343ebbb9"}], "distances": [0.9999999403953552]}]	null	t	[{"action": "queries_generated", "queries": ["ok"], "done": false}, {"action": "sources_retrieved", "count": 1, "done": true}]	null	null	1791343674	1791343675	\N	null
2f365735-cfc9-4299-aabe-e4eb140eadde-ed00642e-f064-48a7-88b9-4e350f011d25	2f365735-cfc9-4299-aabe-e4eb140eadde	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	user	\N	"Where does the lighthouse key hang?"	null	\N	[{"type": "collection", "id": "a794af32-79bf-4c4d-afd6-a85bc52dc6c0", "name": "Handbook"}]	null	null	t	null	null	null	1791343674	1791343675	\N	null
\.


--
-- Data for Name: chatidtag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chatidtag (id, tag_name, chat_id, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config (key, value, updated_at) FROM stdin;
direct.enable	false	1791343672
direct.integrations.enable	false	1791343672
ollama.enable	false	1791343672
ollama.base_urls	["http://localhost:11434"]	1791343672
ollama.api_configs	{}	1791343672
openai.enable	true	1791343672
openai.api_keys	["sk-mock"]	1791343672
openai.api_base_urls	["http://127.0.0.1:44171/v1"]	1791343672
openai.api_configs	{}	1791343672
models.base_models_cache	false	1791343672
tool_server.connections	[]	1791343672
terminal_server.connections	[]	1791343672
code_execution.enable	true	1791343672
code_execution.engine	"pyodide"	1791343672
code_execution.jupyter.url	""	1791343672
code_execution.jupyter.auth	""	1791343672
code_execution.jupyter.auth_token	""	1791343672
code_execution.jupyter.auth_password	""	1791343672
code_execution.jupyter.timeout	60	1791343672
code_interpreter.enable	true	1791343672
memories.background_review.enable	false	1791343672
memories.review_interval_turns	10	1791343672
memories.user_char_limit	2000	1791343672
memories.context_char_limit	2000	1791343672
code_interpreter.engine	"pyodide"	1791343672
code_interpreter.prompt_template	""	1791343672
code_interpreter.jupyter.url	""	1791343672
code_interpreter.jupyter.auth	""	1791343672
code_interpreter.jupyter.auth_token	""	1791343672
code_interpreter.jupyter.auth_password	""	1791343672
code_interpreter.jupyter.timeout	60	1791343672
google_drive.enable	false	1791343672
google_drive.client_id	""	1791343672
google_drive.api_key	""	1791343672
onedrive.enable	false	1791343672
onedrive.sharepoint_url	""	1791343672
onedrive.sharepoint_tenant_id	""	1791343672
rag.content_extraction_engine	""	1791343672
rag.content_extraction.supported_media_mime_types	null	1791343672
rag.datalab_marker_api_key	""	1791343672
rag.datalab_marker_api_base_url	""	1791343672
rag.datalab_marker_additional_config	""	1791343672
rag.datalab_marker_use_llm	false	1791343672
rag.datalab_marker_skip_cache	false	1791343672
rag.datalab_marker_force_ocr	false	1791343672
rag.datalab_marker_paginate	false	1791343672
rag.datalab_marker_strip_existing_ocr	false	1791343672
rag.datalab_marker_disable_image_extraction	false	1791343672
rag.datalab_marker_format_lines	false	1791343672
rag.datalab_marker_output_format	"markdown"	1791343672
rag.mineru_api_mode	"local"	1791343672
rag.mineru_api_url	"http://localhost:8000"	1791343672
rag.mineru_api_timeout	"300"	1791343672
rag.mineru_api_key	""	1791343672
rag.mineru_params	{}	1791343672
rag.mineru_file_extensions	["pdf"]	1791343672
rag.external_document_loader_url	""	1791343672
rag.external_document_loader_api_key	""	1791343672
rag.external_document_loader_headers	{}	1791343672
rag.tika_server_url	"http://tika:9998"	1791343672
rag.tika_server_version	"3"	1791343672
rag.docling_server_url	"http://docling:5001"	1791343672
rag.docling_api_key	""	1791343672
rag.docling_params	{}	1791343672
rag.document_intelligence_endpoint	""	1791343672
rag.document_intelligence_key	""	1791343672
rag.document_intelligence_model	"prebuilt-layout"	1791343672
rag.mistral_ocr_api_base_url	"https://api.mistral.ai/v1"	1791343672
rag.mistral_ocr_api_key	""	1791343672
rag.mistral_ocr_use_base64	false	1791343672
rag.paddleocr_vl_base_url	"http://localhost:8080"	1791343672
rag.paddleocr_vl_token	""	1791343672
rag.bypass_embedding_and_retrieval	false	1791343672
rag.top_k	3	1791343672
rag.top_k_reranker	3	1791343672
rag.relevance_threshold	0.0	1791343672
rag.hybrid_bm25_weight	0.5	1791343672
rag.enable_hybrid_search	false	1791343672
rag.enable_hybrid_search_enriched_texts	false	1791343672
rag.full_context	false	1791343672
rag.file.max_count	null	1791343672
rag.file.max_size	null	1791343672
file.image_compression_width	null	1791343672
file.image_compression_height	null	1791343672
rag.file.allowed_extensions	[]	1791343672
rag.embedding_engine	"openai"	1791343672
rag.pdf_extract_images	false	1791343672
rag.pdf_loader_mode	"page"	1791343672
rag.embedding_model	"sentence-transformers/all-MiniLM-L6-v2"	1791343672
rag.tokenizer_model	""	1791343672
rag.embedding_batch_size	1	1791343672
rag.enable_async_embedding	true	1791343672
rag.embedding_concurrent_requests	0	1791343672
rag.reranking_engine	""	1791343672
rag.reranking_model	""	1791343672
rag.reranking_batch_size	32	1791343672
rag.external_reranker_url	""	1791343672
rag.external_reranker_api_key	""	1791343672
rag.external_reranker_timeout	""	1791343672
rag.text_splitter	""	1791343672
rag.enable_markdown_header_text_splitter	true	1791343672
rag.tiktoken_encoding_name	"cl100k_base"	1791343672
rag.chunk_size	1000	1791343672
rag.chunk_min_size_target	0	1791343672
rag.chunk_overlap	100	1791343672
image_generation.engine	"openai"	1791343672
image_generation.model	""	1791343672
image_generation.size	"512x512"	1791343672
image_generation.steps	50	1791343672
image_generation.prompt.enable	true	1791343672
image_generation.automatic1111.base_url	""	1791343672
rag.template	"### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n{{CONTEXT}}\\n</context>\\n"	1791343672
rag.openai.api_base_url	"http://127.0.0.1:44171/v1"	1791343672
rag.openai.api_key	"sk-mock"	1791343672
rag.azure_openai.base_url	""	1791343672
rag.azure_openai.api_key	""	1791343672
rag.azure_openai.api_version	""	1791343672
rag.ollama.base_url	"http://localhost:11434"	1791343672
rag.ollama.api_key	""	1791343672
rag.youtube_loader_language	["en"]	1791343672
rag.youtube_loader_proxy_url	""	1791343672
web.search.enable	false	1791343672
web.search.confirmation.enable	false	1791343672
web.search.confirmation.content	"Your query will be sent to the configured web search provider."	1791343672
web.search.engine	""	1791343672
web.search.bypass_embedding_and_retrieval	false	1791343672
web.search.bypass_web_loader	false	1791343672
web.search.result_count	3	1791343672
web.search.domain.filter_list	[]	1791343672
web.search.concurrent_requests	0	1791343672
web.fetch.max_content_length	null	1791343672
web.loader.engine	""	1791343672
web.loader.concurrent_requests	10	1791343672
web.loader.timeout	""	1791343672
web.loader.ssl_verification	true	1791343672
web.search.trust_env	true	1791343672
web.search.ollama_cloud_api_key	""	1791343672
web.search.searxng_query_url	""	1791343672
web.search.openserp_base_url	"http://localhost:7000"	1791343672
web.search.searxng_language	"all"	1791343672
web.search.yacy_query_url	""	1791343672
web.search.yacy_username	""	1791343672
web.search.yacy_password	""	1791343672
web.search.google_pse_api_key	""	1791343672
web.search.google_pse_engine_id	""	1791343672
web.search.brave_search_api_key	""	1791343672
web.search.brave_search_context_tokens	8192	1791343672
web.search.kagi_search_api_key	""	1791343672
web.search.mojeek_search_api_key	""	1791343672
web.search.bocha_search_api_key	""	1791343672
web.search.serpstack_api_key	""	1791343672
web.search.serpstack_https	true	1791343672
web.search.serper_api_key	""	1791343672
web.search.serply_api_key	""	1791343672
web.search.serphouse_api_key	""	1791343672
web.search.serphouse_domain	"google.com"	1791343672
web.search.ddgs_backend	"auto"	1791343672
web.search.jina_api_key	""	1791343672
web.search.jina_api_base_url	""	1791343672
web.search.searchapi_api_key	""	1791343672
web.search.searchapi_engine	""	1791343672
web.search.serpapi_api_key	""	1791343672
web.search.serpapi_engine	""	1791343672
web.search.bing_search_v7_endpoint	"https://api.bing.microsoft.com/v7.0/search"	1791343672
web.search.bing_search_v7_subscription_key	""	1791343672
web.search.azure_ai_search_api_key	""	1791343672
web.search.azure_ai_search_endpoint	""	1791343672
web.search.azure_ai_search_index_name	""	1791343672
web.search.exa_api_key	""	1791343672
web.search.exa_max_content_length	null	1791343672
web.search.perplexity_api_key	""	1791343672
web.search.perplexity_model	"sonar"	1791343672
web.search.perplexity_search_context_usage	"medium"	1791343672
web.search.perplexity_search_api_url	"https://api.perplexity.ai/search"	1791343672
web.search.microsoft_web_iq_api_base_url	"https://api.microsoft.ai/v3"	1791343672
web.search.microsoft_web_iq_api_key	""	1791343672
web.search.microsoft_web_iq_language	"en"	1791343672
web.search.sougou_api_sid	""	1791343672
web.search.sougou_api_sk	""	1791343672
web.search.tavily_api_key	""	1791343672
web.search.tavily_extract_depth	"basic"	1791343672
web.search.staan_api_key	""	1791343672
web.search.staan_market	"en-us"	1791343672
web.search.staan_max_snippets	0	1791343672
web.loader.playwright_ws_url	""	1791343672
web.loader.playwright_timeout	10000	1791343672
web.loader.firecrawl_api_key	""	1791343672
web.loader.firecrawl_api_url	"https://api.firecrawl.dev"	1791343672
web.loader.firecrawl_timeout	""	1791343672
web.search.external_web_search_url	""	1791343672
web.search.external_web_search_api_key	""	1791343672
web.loader.external_web_loader_url	""	1791343672
web.loader.external_web_loader_api_key	""	1791343672
web.search.yandex_web_search_url	""	1791343672
web.search.yandex_web_search_api_key	""	1791343672
web.search.yandex_web_search_config	""	1791343672
web.search.youcom_api_key	""	1791343672
web.search.linkup_api_key	""	1791343672
web.search.linkup_search_params	{}	1791343672
image_generation.enable	false	1791343672
image_generation.automatic1111.api_auth	""	1791343672
image_generation.automatic1111.api_params	{}	1791343672
image_generation.comfyui.base_url	""	1791343672
image_generation.comfyui.api_key	""	1791343672
image_generation.comfyui.workflow	"\\n{\\n  \\"3\\": {\\n    \\"inputs\\": {\\n      \\"seed\\": 0,\\n      \\"steps\\": 20,\\n      \\"cfg\\": 8,\\n      \\"sampler_name\\": \\"euler\\",\\n      \\"scheduler\\": \\"normal\\",\\n      \\"denoise\\": 1,\\n      \\"model\\": [\\n        \\"4\\",\\n        0\\n      ],\\n      \\"positive\\": [\\n        \\"6\\",\\n        0\\n      ],\\n      \\"negative\\": [\\n        \\"7\\",\\n        0\\n      ],\\n      \\"latent_image\\": [\\n        \\"5\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"KSampler\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"KSampler\\"\\n    }\\n  },\\n  \\"4\\": {\\n    \\"inputs\\": {\\n      \\"ckpt_name\\": \\"model.safetensors\\"\\n    },\\n    \\"class_type\\": \\"CheckpointLoaderSimple\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Load Checkpoint\\"\\n    }\\n  },\\n  \\"5\\": {\\n    \\"inputs\\": {\\n      \\"width\\": 512,\\n      \\"height\\": 512,\\n      \\"batch_size\\": 1\\n    },\\n    \\"class_type\\": \\"EmptyLatentImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Empty Latent Image\\"\\n    }\\n  },\\n  \\"6\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"Prompt\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"7\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"8\\": {\\n    \\"inputs\\": {\\n      \\"samples\\": [\\n        \\"3\\",\\n        0\\n      ],\\n      \\"vae\\": [\\n        \\"4\\",\\n        2\\n      ]\\n    },\\n    \\"class_type\\": \\"VAEDecode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"VAE Decode\\"\\n    }\\n  },\\n  \\"9\\": {\\n    \\"inputs\\": {\\n      \\"filename_prefix\\": \\"ComfyUI\\",\\n      \\"images\\": [\\n        \\"8\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"SaveImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Save Image\\"\\n    }\\n  }\\n}\\n"	1791343672
image_generation.comfyui.nodes	[]	1791343672
image_generation.openai.api_base_url	"https://api.openai.com/v1"	1791343672
image_generation.openai.api_version	""	1791343672
image_generation.openai.api_key	""	1791343672
image_generation.openai.params	{}	1791343672
image_generation.gemini.api_base_url	""	1791343672
image_generation.gemini.api_key	""	1791343672
image_generation.gemini.endpoint_method	""	1791343672
images.edit.enable	false	1791343672
images.edit.engine	"openai"	1791343672
images.edit.model	""	1791343672
images.edit.size	""	1791343672
images.edit.openai.api_base_url	"https://api.openai.com/v1"	1791343672
images.edit.openai.api_version	""	1791343672
images.edit.openai.api_key	""	1791343672
images.edit.gemini.api_base_url	""	1791343672
images.edit.gemini.api_key	""	1791343672
images.edit.comfyui.base_url	""	1791343672
images.edit.comfyui.api_key	""	1791343672
images.edit.comfyui.workflow	""	1791343672
images.edit.comfyui.nodes	[]	1791343672
audio.stt.whisper_model	"base"	1791343672
audio.stt.deepgram.api_key	""	1791343672
audio.stt.openai.api_base_url	"https://api.openai.com/v1"	1791343672
audio.stt.openai.api_key	""	1791343672
audio.stt.openai.api_request_format	"multipart"	1791343672
audio.stt.engine	""	1791343672
audio.stt.model	""	1791343672
audio.stt.supported_content_types	[]	1791343672
audio.stt.allowed_extensions	["mp3", "wav", "m4a", "webm", "ogg", "flac", "mp4", "mpga", "mpeg"]	1791343672
audio.stt.azure.api_key	""	1791343672
audio.stt.azure.region	""	1791343672
audio.stt.azure.locales	""	1791343672
audio.stt.azure.base_url	""	1791343672
audio.stt.azure.max_speakers	""	1791343672
audio.stt.mistral.api_key	""	1791343672
audio.stt.mistral.api_base_url	"https://api.mistral.ai/v1"	1791343672
audio.stt.mistral.use_chat_completions	false	1791343672
audio.tts.openai.api_base_url	"https://api.openai.com/v1"	1791343672
audio.tts.openai.api_key	""	1791343672
audio.tts.openai.params	{}	1791343672
audio.tts.api_key	""	1791343672
audio.tts.engine	""	1791343672
audio.tts.model	"tts-1"	1791343672
audio.tts.voice	"alloy"	1791343672
audio.tts.split_on	"punctuation"	1791343672
audio.tts.azure.speech_region	""	1791343672
audio.tts.azure.speech_base_url	""	1791343672
audio.tts.azure.speech_output_format	"audio-24khz-160kbitrate-mono-mp3"	1791343672
audio.tts.mistral.api_key	""	1791343672
audio.tts.mistral.api_base_url	"https://api.mistral.ai/v1"	1791343672
ui.enable_password_change_form	true	1791343672
ui.default_locale	""	1791343672
ui.default_models	null	1791343672
ui.default_pinned_models	null	1791343672
ui.prompt_suggestions	null	1791343672
ui.prompt_suggestions_i18n	{}	1791343672
ui.model_order_list	[]	1791343672
models.default_metadata	{}	1791343672
models.default_params	{}	1791343672
ui.enable_signup	false	1791343673
ui.default_group_id	""	1791343673
ui.default_interface_settings	{}	1791343673
ui.default_user_role	"user"	1791343673
ui.enable_login_form	true	1791343673
ui.i18n	{}	1791343673
ui.pending_user_overlay_content	""	1791343673
ui.pending_user_overlay_title	""	1791343673
ui.watermark	""	1791343673
webui.url	"https://chat.example.com"	1791343673
subagents.enable	false	1791343672
subagents.background_enabled	false	1791343672
subagents.max_concurrent	20	1791343672
subagents.max_async	20	1791343672
subagents.max_iterations	30	1791343672
subagents.max_output	30000	1791343672
subagents.system_prompt	""	1791343672
automations.auth_token_expires_in	"1h"	1791343672
evaluation.arena.enable	true	1791343672
evaluation.arena.models	[]	1791343672
webhook_url	""	1791343672
task.model.default	""	1791343672
task.model.external	""	1791343672
task.model.params	{}	1791343672
chat.context_compaction.model	""	1791343672
chat.context_compaction.enable	false	1791343672
chat.context_compaction.token_threshold	80000	1791343672
chat.context_compaction.token_cap	null	1791343672
chat.context_compaction.retention_percentage	40	1791343672
chat.context_compaction.prompt_template	""	1791343672
chat.tool_permissions.enable	false	1791343672
task.title.prompt_template	""	1791343672
task.tags.prompt_template	""	1791343672
task.image.prompt_template	""	1791343672
task.follow_up.prompt_template	""	1791343672
task.follow_up.enable	false	1791343672
task.tags.enable	false	1791343672
task.title.enable	false	1791343672
task.query.search.enable	true	1791343672
task.query.retrieval.enable	true	1791343672
task.query.prompt_template	""	1791343672
task.autocomplete.enable	false	1791343672
task.autocomplete.input_max_length	-1	1791343672
task.autocomplete.prompt_template	""	1791343672
task.voice.prompt_template	""	1791343672
task.voice.prompt.enable	true	1791343672
task.tools.prompt_template	""	1791343672
ldap.enable	false	1791343672
ldap.server.label	"LDAP Server"	1791343672
ldap.server.host	"localhost"	1791343672
ldap.server.port	389	1791343672
ldap.server.attribute_for_mail	"mail"	1791343672
ldap.server.attribute_for_username	"uid"	1791343672
ldap.server.app_dn	""	1791343672
ldap.server.app_password	""	1791343672
ldap.server.users_dn	""	1791343672
ldap.server.search_filter	""	1791343672
ldap.server.use_tls	true	1791343672
ldap.server.ca_cert_file	""	1791343672
ldap.server.validate_cert	true	1791343672
ldap.server.ciphers	"ALL"	1791343672
ldap.group.enable_management	false	1791343672
ldap.group.enable_creation	false	1791343672
ldap.server.attribute_for_groups	"memberOf"	1791343672
auth.admin.email	null	1791343673
auth.admin.show	true	1791343673
auth.api_key.allowed_endpoints	""	1791343673
auth.api_key.endpoint_restrictions	false	1791343673
auth.enable_api_keys	false	1791343673
auth.jwt_expiry	"4w"	1791343673
automations.enable	true	1791343673
automations.max_count	""	1791343673
automations.min_interval	""	1791343673
calendar.enable	true	1791343673
channels.enable	true	1791343673
channels.model_response_mode	"thread"	1791343673
folders.enable	true	1791343673
folders.max_file_count	""	1791343673
memories.enable	true	1791343673
memories.system_context.enable	true	1791343673
notes.enable	true	1791343673
ui.enable_community_sharing	false	1791343673
ui.enable_message_rating	true	1791343673
ui.enable_user_webhooks	false	1791343673
users.enable_status	true	1791343673
ui.banners	[{"i18n": null, "id": "upgrade-banner", "type": "info", "title": "Maintenance", "content": "Maintenance on Sunday", "dismissible": true, "timestamp": 1700000000}]	1791343674
user.permissions	{"workspace": {"models": false, "knowledge": false, "prompts": true, "tools": false, "skills": false, "models_import": false, "models_export": false, "prompts_import": false, "prompts_export": false, "tools_import": false, "tools_export": false, "skills_import": false, "skills_export": false}, "sharing": {"models": false, "public_models": false, "knowledge": false, "public_knowledge": false, "prompts": false, "public_prompts": false, "tools": false, "public_tools": false, "skills": false, "public_skills": false, "notes": false, "public_notes": false, "folders": false, "public_chats": false, "open_chats": false, "public_calendars": false}, "access_grants": {"allow_users": true, "allow_groups": true}, "chat": {"controls": true, "valves": true, "system_prompt": true, "params": true, "file_upload": true, "web_upload": true, "delete": false, "delete_message": true, "continue_response": true, "regenerate_response": true, "rate_response": true, "edit": true, "share": true, "export": true, "import": true, "stt": true, "tts": true, "call": true, "multiple_models": true, "temporary": true, "temporary_enforced": false}, "features": {"api_keys": false, "notes": true, "channels": true, "folders": true, "direct_tool_servers": false, "web_search": true, "image_generation": true, "code_interpreter": true, "memories": true, "automations": false, "calendar": true, "webhooks": false}, "settings": {"interface": true}}	1791343674
\.


--
-- Data for Name: config_old; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_old (id, data, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (collection_name, name, title, filename, content, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, user_id, version, type, data, meta, snapshot, created_at, updated_at) FROM stdin;
953e0d5c-f09f-4644-8434-476735304eb3	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	0	rating	{"rating": 1, "model_id": "mock-model", "sibling_model_ids": null, "reason": "Accurate", "comment": null}	{"chat_id": "fa19215a-3190-4406-9f60-1ca426fb84f3", "message_id": "5e0bf3c5-5151-4599-b133-5a0224680bb6"}	{"chat": {}}	1791343675	1791343675
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, user_id, filename, meta, created_at, hash, data, updated_at, path) FROM stdin;
b59d0b41-a6a9-435c-b4d5-23ebc5fca920	bd076204-9166-4119-a5ce-12e2343ebbb9	handbook.txt	{"name": "handbook.txt", "content_type": "text/plain", "size": 72, "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "data": {}, "collection_name": "a794af32-79bf-4c4d-afd6-a85bc52dc6c0"}	1791343674	51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb	{"status": "completed", "content": "The upgrade handbook says the lighthouse key hangs behind the blue door.", "error": null}	1791343674	/tmp/seed-v0.11.4-g6ccjg7r/data/uploads/b59d0b41-a6a9-435c-b4d5-23ebc5fca920_handbook.txt
e7970ec9-da96-48ce-a161-9c7cab82dde8	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	packing.txt	{"name": "packing.txt", "content_type": "text/plain", "size": 59, "file_hash": "85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a", "data": {}, "collection_name": "file-e7970ec9-da96-48ce-a161-9c7cab82dde8"}	1791343674	85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a	{"status": "completed", "content": "Packing list: umbrella, passport, a very old map of Vienna.", "error": null}	1791343674	/tmp/seed-v0.11.4-g6ccjg7r/data/uploads/e7970ec9-da96-48ce-a161-9c7cab82dde8_packing.txt
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder (id, parent_id, user_id, name, items, meta, is_expanded, created_at, updated_at, data) FROM stdin;
03bb4ba2-f44b-4eda-9ac8-72af929d9d9e	\N	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Trips	null	null	f	1791343674	1791343674	null
ad6104cb-639c-478c-87e9-1c595312dfb9	03bb4ba2-f44b-4eda-9ac8-72af929d9d9e	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Vienna	null	null	f	1791343674	1791343674	null
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function (id, user_id, name, type, content, meta, valves, is_active, is_global, updated_at, created_at) FROM stdin;
shout_filter	bd076204-9166-4119-a5ce-12e2343ebbb9	Shout filter	filter	"""\ntitle: Shout filter\n"""\n\nfrom pydantic import BaseModel\n\n\nclass Filter:\n    class Valves(BaseModel):\n        suffix: str = "!"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def inlet(self, body: dict) -> dict:\n        return body\n	{"description": "Adds emphasis", "manifest": {"title": "Shout filter"}}	{"suffix": "!!!"}	t	t	1791343674	1791343674
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."group" (id, user_id, name, description, data, meta, permissions, created_at, updated_at) FROM stdin;
a028c6c0-14af-49ba-a28b-5839bd07a2ee	bd076204-9166-4119-a5ce-12e2343ebbb9	Research	People who read the handbook	{"config": {"share": "members"}}	null	{"workspace": {"models": true}}	1791343673	1791343673
\.


--
-- Data for Name: group_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_member (id, group_id, user_id, created_at, updated_at) FROM stdin;
bae27549-cda9-4812-9d13-028a6a439bd6	a028c6c0-14af-49ba-a28b-5839bd07a2ee	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	1791343673	1791343673
a60e0a6c-7fed-4c18-a797-8968949e6f71	a028c6c0-14af-49ba-a28b-5839bd07a2ee	5d82715e-c330-4799-8e17-44dce0a501e5	1791343673	1791343673
\.


--
-- Data for Name: knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge (id, user_id, name, description, meta, created_at, updated_at, data) FROM stdin;
a794af32-79bf-4c4d-afd6-a85bc52dc6c0	bd076204-9166-4119-a5ce-12e2343ebbb9	Handbook	Where things are	null	1791343674	1791343674	\N
\.


--
-- Data for Name: knowledge_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_directory (id, knowledge_id, parent_id, name, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_file (id, user_id, knowledge_id, file_id, created_at, updated_at, directory_id) FROM stdin;
b1c5af8a-2c1f-45e4-81b3-84ccb04947bd	bd076204-9166-4119-a5ce-12e2343ebbb9	a794af32-79bf-4c4d-afd6-a85bc52dc6c0	b59d0b41-a6a9-435c-b4d5-23ebc5fca920	1791343674	1791343674	\N
\.


--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.memory (id, user_id, content, updated_at, created_at, type, path, meta) FROM stdin;
5f77d394-19be-42da-b901-4b1075bab31e	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Alice is allergic to peanuts.	1791343675	1791343675	context	\N	{"created_by": "manual"}
09286536-3329-4edf-b992-d22771439106	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Alice prefers window seats.	1791343675	1791343675	context	\N	{"created_by": "manual"}
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (id, user_id, channel_id, content, data, meta, created_at, updated_at, parent_id, reply_to_id, is_pinned, pinned_at, pinned_by) FROM stdin;
58f2593c-d57d-4f21-af5b-3dc480b5dad0	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	24e8ede3-1e38-4df8-a34e-551ded61c838	Who has the lighthouse key?	null	null	1791343675281913541	1791343675281913541	\N	\N	f	\N	\N
ffc0038b-5edb-4a51-b115-a85d7caa44c5	5d82715e-c330-4799-8e17-44dce0a501e5	24e8ede3-1e38-4df8-a34e-551ded61c838	Behind the blue door.	null	null	1791343675324013480	1791343675324013480	58f2593c-d57d-4f21-af5b-3dc480b5dad0	\N	f	\N	\N
\.


--
-- Data for Name: message_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reaction (id, user_id, message_id, name, created_at) FROM stdin;
14699bd2-2187-4a00-b705-e2bc50238e59	5d82715e-c330-4799-8e17-44dce0a501e5	58f2593c-d57d-4f21-af5b-3dc480b5dad0	thumbsup	1791343675371613434
\.


--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model (id, user_id, base_model_id, name, params, meta, updated_at, created_at, is_active) FROM stdin;
research-assistant	bd076204-9166-4119-a5ce-12e2343ebbb9	mock-model	Research assistant	{"system": "You answer from the handbook.", "temperature": 0.2}	{"profile_image_url": null, "background_image_url": null, "description": "Answers from the handbook", "i18n": null, "capabilities": null, "knowledge": null}	1791343674	1791343674	t
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (id, user_id, title, data, meta, created_at, updated_at) FROM stdin;
9139440d-5cc4-4b76-a1cd-59ed1dd30372	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Groceries	{"content": {"md": "# Groceries\\n\\n- apples\\n- *dark* chocolate", "html": "", "json": null}}	null	1791343675191691197	1791343675191691828
\.


--
-- Data for Name: oauth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_session (id, user_id, provider, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pinned_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_note (id, user_id, note_id, created_at) FROM stdin;
\.


--
-- Data for Name: prompt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt (id, command, user_id, name, content, data, meta, is_active, version_id, tags, created_at, updated_at) FROM stdin;
f71c2a2d-565e-46fb-bcf8-e929559bd196	summarize	bd076204-9166-4119-a5ce-12e2343ebbb9	Summarize	Summarize the following text in three bullet points.	{}	{}	t	c3f90017-0cda-411f-a039-21ce63ec7b03	[]	1791343674	1791343674
91018e73-b857-4e42-a2e7-434294fa9e13	alice-draft	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Alice's draft	Draft a polite reply to this email.	{}	{}	t	f3398f62-f9e6-4ec2-8d08-f841c9b050cd	[]	1791343674	1791343674
\.


--
-- Data for Name: prompt_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt_history (id, prompt_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
c3f90017-0cda-411f-a039-21ce63ec7b03	f71c2a2d-565e-46fb-bcf8-e929559bd196	\N	{"name": "Summarize", "content": "Summarize the following text in three bullet points.", "command": "summarize", "data": {}, "meta": {}, "tags": [], "access_grants": [{"id": "f10d63ab-cd0f-4ebc-8476-6b5302132926", "resource_type": "prompt", "resource_id": "f71c2a2d-565e-46fb-bcf8-e929559bd196", "principal_type": "group", "principal_id": "a028c6c0-14af-49ba-a28b-5839bd07a2ee", "permission": "read", "created_at": 1791343674}]}	bd076204-9166-4119-a5ce-12e2343ebbb9	Initial version	1791343674
f3398f62-f9e6-4ec2-8d08-f841c9b050cd	91018e73-b857-4e42-a2e7-434294fa9e13	\N	{"name": "Alice's draft", "content": "Draft a polite reply to this email.", "command": "alice-draft", "data": {}, "meta": {}, "tags": [], "access_grants": []}	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Initial version	1791343674
\.


--
-- Data for Name: shared_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shared_chat (id, chat_id, user_id, title, chat, created_at, updated_at) FROM stdin;
4050a36c-fce4-48fa-9d0c-a5a5f1e9e2db	8c0e5d67-6079-4b47-a1ec-15a3f1bc7172	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Packing for Vienna	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "e7970ec9-da96-48ce-a161-9c7cab82dde8", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1791343674, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1791343675}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1791343676}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1791343677, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1791343678}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "e7970ec9-da96-48ce-a161-9c7cab82dde8", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1791343674, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1791343676}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1791343677, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1791343678}], "files": [{"type": "file", "id": "e7970ec9-da96-48ce-a161-9c7cab82dde8", "name": "packing.txt", "status": "uploaded"}], "params": {}}	1791343674	1791343674
\.


--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill (id, user_id, name, description, content, meta, is_active, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tag (id, name, user_id, meta) FROM stdin;
travel	travel	4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	\N
\.


--
-- Data for Name: tool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool (id, user_id, name, content, specs, meta, valves, updated_at, created_at) FROM stdin;
weather_tool	bd076204-9166-4119-a5ce-12e2343ebbb9	Weather	"""\ntitle: Weather\n"""\n\n\nfrom pydantic import BaseModel\n\n\nclass Tools:\n    class Valves(BaseModel):\n        units: str = "metric"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def get_weather(self, city: str) -> str:\n        """Report the weather in a city."""\n        return f"Sunny in {city}"\n	[{"name": "get_weather", "description": "Report the weather in a city.", "parameters": {"properties": {"city": {"type": "string"}}, "required": ["city"], "type": "object"}}]	{"i18n": null, "description": "Weather lookups", "manifest": {"title": "Weather"}, "has_user_valves": false}	\N	1791343674	1791343674
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, role, profile_image_url, last_active_at, updated_at, created_at, settings, info, username, bio, gender, date_of_birth, profile_banner_image_url, timezone, presence_state, status_emoji, status_message, status_expires_at, oauth, scim, variables) FROM stdin;
bd076204-9166-4119-a5ce-12e2343ebbb9	Ada Admin	admin@example.com	admin	/user.png	1791343673	1791343673	1791343673	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
151fadc6-ff7c-491b-be89-10fbd66f049a	Carol Outsider	carol@example.com	user	/user.png	1791343673	1791343673	1791343673	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
4a4bd652-0448-4dc3-99c9-eb4681d2b7e0	Alice Author	alice@example.com	user	/user.png	1791343674	1791343673	1791343673	{"ui": {"theme": "dark", "chatBubble": false, "notesSeen": 3}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
5d82715e-c330-4799-8e17-44dce0a501e5	Bob Reader	bob@example.com	user	/user.png	1791343674	1791343673	1791343673	{"ui": {"models": ["research-assistant"]}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
\.


--
-- Name: config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_id_seq', 1, false);


--
-- Name: access_grant access_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT access_grant_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_key UNIQUE (key);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: automation automation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation
    ADD CONSTRAINT automation_pkey PRIMARY KEY (id);


--
-- Name: automation_run automation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_run
    ADD CONSTRAINT automation_run_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendee calendar_event_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT calendar_event_attendee_pkey PRIMARY KEY (id);


--
-- Name: calendar_event calendar_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event
    ADD CONSTRAINT calendar_event_pkey PRIMARY KEY (id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (id);


--
-- Name: channel_file channel_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_pkey PRIMARY KEY (id);


--
-- Name: channel_member channel_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT channel_member_pkey PRIMARY KEY (id);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_webhook channel_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_pkey PRIMARY KEY (id);


--
-- Name: chat_file chat_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: chat chat_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_share_id_key UNIQUE (share_id);


--
-- Name: chatidtag chatidtag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chatidtag
    ADD CONSTRAINT chatidtag_pkey PRIMARY KEY (id);


--
-- Name: config_old config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey1 PRIMARY KEY (key);


--
-- Name: document document_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_name_key UNIQUE (name);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (collection_name);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id, user_id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: group_member group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_pkey PRIMARY KEY (id);


--
-- Name: group group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pkey PRIMARY KEY (id);


--
-- Name: knowledge_directory knowledge_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_pkey PRIMARY KEY (id);


--
-- Name: knowledge_file knowledge_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_pkey PRIMARY KEY (id);


--
-- Name: knowledge knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge
    ADD CONSTRAINT knowledge_pkey PRIMARY KEY (id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: message_reaction message_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reaction
    ADD CONSTRAINT message_reaction_pkey PRIMARY KEY (id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: oauth_session oauth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_pkey PRIMARY KEY (id);


--
-- Name: pinned_note pinned_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_pkey PRIMARY KEY (id);


--
-- Name: tag pk_id_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_id_user_id PRIMARY KEY (id, user_id);


--
-- Name: prompt_history prompt_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt_history
    ADD CONSTRAINT prompt_history_pkey PRIMARY KEY (id);


--
-- Name: prompt prompt_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt
    ADD CONSTRAINT prompt_new_pkey PRIMARY KEY (id);


--
-- Name: shared_chat shared_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_pkey PRIMARY KEY (id);


--
-- Name: skill skill_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_name_key UNIQUE (name);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- Name: tool tool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool
    ADD CONSTRAINT tool_pkey PRIMARY KEY (id);


--
-- Name: access_grant uq_access_grant_grant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT uq_access_grant_grant UNIQUE (resource_type, resource_id, principal_type, principal_id, permission);


--
-- Name: channel_file uq_channel_file_channel_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT uq_channel_file_channel_file UNIQUE (channel_id, file_id);


--
-- Name: chat_file uq_chat_file_chat_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT uq_chat_file_chat_file UNIQUE (chat_id, file_id);


--
-- Name: calendar_event_attendee uq_event_attendee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT uq_event_attendee UNIQUE (event_id, user_id);


--
-- Name: group_member uq_group_member_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT uq_group_member_group_user UNIQUE (group_id, user_id);


--
-- Name: knowledge_directory uq_knowledge_directory_knowledge_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT uq_knowledge_directory_knowledge_parent_name UNIQUE (knowledge_id, parent_id, name);


--
-- Name: knowledge_file uq_knowledge_file_knowledge_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT uq_knowledge_file_knowledge_file UNIQUE (knowledge_id, file_id);


--
-- Name: pinned_note uq_pinned_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT uq_pinned_note UNIQUE (user_id, note_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: chat_message_chat_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_parent_idx ON public.chat_message USING btree (chat_id, parent_id);


--
-- Name: chat_message_chat_role_done_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_role_done_idx ON public.chat_message USING btree (chat_id, role, done);


--
-- Name: chat_message_model_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_model_created_idx ON public.chat_message USING btree (model_id, created_at);


--
-- Name: chat_message_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_user_created_idx ON public.chat_message USING btree (user_id, created_at);


--
-- Name: folder_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_idx ON public.chat USING btree (folder_id);


--
-- Name: folder_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_user_id_idx ON public.chat USING btree (folder_id, user_id);


--
-- Name: idx_access_grant_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_principal ON public.access_grant USING btree (principal_type, principal_id);


--
-- Name: idx_access_grant_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_resource ON public.access_grant USING btree (resource_type, resource_id);


--
-- Name: idx_oauth_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_expires_at ON public.oauth_session USING btree (expires_at);


--
-- Name: idx_oauth_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_id ON public.oauth_session USING btree (user_id);


--
-- Name: idx_oauth_session_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_provider ON public.oauth_session USING btree (user_id, provider);


--
-- Name: idx_skill_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_updated_at ON public.skill USING btree (updated_at);


--
-- Name: idx_skill_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_user_id ON public.skill USING btree (user_id);


--
-- Name: is_global_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX is_global_idx ON public.function USING btree (is_global);


--
-- Name: ix_automation_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_next_run ON public.automation USING btree (next_run_at);


--
-- Name: ix_automation_run_automation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_run_automation_id ON public.automation_run USING btree (automation_id);


--
-- Name: ix_automation_user_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_user_folder ON public.automation USING btree (user_id, folder_id);


--
-- Name: ix_calendar_event_attendee_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_attendee_user ON public.calendar_event_attendee USING btree (user_id, status);


--
-- Name: ix_calendar_event_calendar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_calendar ON public.calendar_event USING btree (calendar_id, start_at);


--
-- Name: ix_calendar_event_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_user_date ON public.calendar_event USING btree (user_id, start_at);


--
-- Name: ix_calendar_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_user ON public.calendar USING btree (user_id);


--
-- Name: ix_channel_file_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_channel_id ON public.channel_file USING btree (channel_id);


--
-- Name: ix_channel_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_file_id ON public.channel_file USING btree (file_id);


--
-- Name: ix_channel_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_user_id ON public.channel_file USING btree (user_id);


--
-- Name: ix_chat_file_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_chat_id ON public.chat_file USING btree (chat_id);


--
-- Name: ix_chat_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_file_id ON public.chat_file USING btree (file_id);


--
-- Name: ix_chat_file_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_message_id ON public.chat_file USING btree (message_id);


--
-- Name: ix_chat_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_user_id ON public.chat_file USING btree (user_id);


--
-- Name: ix_chat_message_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_chat_id ON public.chat_message USING btree (chat_id);


--
-- Name: ix_chat_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_created_at ON public.chat_message USING btree (created_at);


--
-- Name: ix_chat_message_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_model_id ON public.chat_message USING btree (model_id);


--
-- Name: ix_chat_message_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_user_id ON public.chat_message USING btree (user_id);


--
-- Name: ix_group_member_user_id_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_group_member_user_id_group_id ON public.group_member USING btree (user_id, group_id);


--
-- Name: ix_knowledge_directory_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_knowledge_id ON public.knowledge_directory USING btree (knowledge_id);


--
-- Name: ix_knowledge_directory_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_parent_id ON public.knowledge_directory USING btree (parent_id);


--
-- Name: ix_knowledge_file_directory_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_directory_id ON public.knowledge_file USING btree (directory_id);


--
-- Name: ix_knowledge_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_file_id ON public.knowledge_file USING btree (file_id);


--
-- Name: ix_knowledge_file_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_knowledge_id ON public.knowledge_file USING btree (knowledge_id);


--
-- Name: ix_knowledge_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_user_id ON public.knowledge_file USING btree (user_id);


--
-- Name: ix_memory_id_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_id_user_id ON public.memory USING btree (id, user_id);


--
-- Name: ix_memory_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_type ON public.memory USING btree (type);


--
-- Name: ix_memory_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_user_id ON public.memory USING btree (user_id);


--
-- Name: ix_prompt_history_prompt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompt_history_prompt_id ON public.prompt_history USING btree (prompt_id);


--
-- Name: ix_prompt_new_command; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_prompt_new_command ON public.prompt USING btree (command);


--
-- Name: timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX timer_at_idx ON public.chat USING btree (timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: updated_at_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX updated_at_user_id_idx ON public.chat USING btree (updated_at, user_id);


--
-- Name: uq_user_email_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_user_email_lower ON public."user" USING btree (lower((email)::text)) WHERE (email IS NOT NULL);


--
-- Name: user_id_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_archived_idx ON public.chat USING btree (user_id, archived);


--
-- Name: user_id_folder_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_folder_unread_idx ON public.chat USING btree (user_id, folder_id, archived, updated_at, last_read_at, id);


--
-- Name: user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_idx ON public.tag USING btree (user_id);


--
-- Name: user_id_pinned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_pinned_idx ON public.chat USING btree (user_id, pinned);


--
-- Name: user_id_timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_timer_at_idx ON public.chat USING btree (user_id, timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: user_id_updated_at_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_updated_at_id_idx ON public.chat USING btree (user_id, updated_at DESC, id);


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: channel_webhook channel_webhook_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: chat_message chat_message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: channel_file fk_channel_file_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT fk_channel_file_message_id FOREIGN KEY (message_id) REFERENCES public.message(id) ON DELETE CASCADE;


--
-- Name: knowledge_file fk_knowledge_file_directory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT fk_knowledge_file_directory_id FOREIGN KEY (directory_id) REFERENCES public.knowledge_directory(id) ON DELETE SET NULL;


--
-- Name: group_member group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: group_member group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_directory(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: oauth_session oauth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: pinned_note pinned_note_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id) ON DELETE CASCADE;


--
-- Name: shared_chat shared_chat_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

