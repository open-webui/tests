--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_grant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_grant (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    user_id text,
    key text NOT NULL,
    data json,
    expires_at bigint,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth (
    id character varying NOT NULL,
    email character varying,
    password text,
    active boolean
);


--
-- Name: automation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    data json NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    folder_id text
);


--
-- Name: automation_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_run (
    id text NOT NULL,
    automation_id text NOT NULL,
    chat_id text,
    status text NOT NULL,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    color text,
    is_default boolean NOT NULL,
    data json,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event (
    id text NOT NULL,
    calendar_id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    start_at bigint NOT NULL,
    end_at bigint,
    all_day boolean NOT NULL,
    rrule text,
    color text,
    location text,
    data json,
    meta json,
    is_cancelled boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event_attendee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendee (
    id text NOT NULL,
    event_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    type text,
    is_private boolean,
    archived_at bigint,
    archived_by text,
    deleted_at bigint,
    deleted_by text,
    updated_by text
);


--
-- Name: channel_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_file (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    message_id text
);


--
-- Name: channel_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_member (
    id text NOT NULL,
    channel_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    status text,
    is_active boolean DEFAULT true NOT NULL,
    is_channel_muted boolean DEFAULT false NOT NULL,
    is_channel_pinned boolean DEFAULT false NOT NULL,
    data json,
    meta json,
    joined_at bigint NOT NULL,
    left_at bigint,
    last_read_at bigint,
    updated_at bigint,
    role text,
    invited_by text,
    invited_at bigint
);


--
-- Name: channel_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_webhook (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    profile_image_url text,
    token text NOT NULL,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    user_id character varying,
    title text,
    created_at bigint,
    updated_at bigint,
    share_id text,
    archived boolean,
    chat json,
    pinned boolean,
    meta json DEFAULT '{}'::json NOT NULL,
    folder_id text,
    tasks json,
    summary text,
    last_read_at bigint,
    current_message_id text,
    variables json,
    timer_at bigint
);


--
-- Name: chat_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_file (
    id text NOT NULL,
    user_id text NOT NULL,
    chat_id text NOT NULL,
    file_id text NOT NULL,
    message_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text,
    role text NOT NULL,
    parent_id text,
    content json,
    output json,
    model_id text,
    files json,
    sources json,
    embeds json,
    done boolean,
    status_history json,
    error json,
    usage json,
    created_at bigint,
    updated_at bigint,
    context_summary text,
    meta json
);


--
-- Name: chatidtag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chatidtag (
    id character varying NOT NULL,
    tag_name character varying,
    chat_id character varying,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    key text NOT NULL,
    value json NOT NULL,
    updated_at bigint
);


--
-- Name: config_old; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_old (
    id integer NOT NULL,
    data json NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config_old.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    collection_name character varying NOT NULL,
    name character varying,
    title text,
    filename text,
    content text,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    user_id text,
    version bigint,
    type text,
    data json,
    meta json,
    snapshot json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id character varying NOT NULL,
    user_id character varying,
    filename text,
    meta json,
    created_at bigint,
    hash text,
    data json,
    updated_at bigint,
    path text
);


--
-- Name: folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder (
    id text NOT NULL,
    parent_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    items json,
    meta json,
    is_expanded boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    data json
);


--
-- Name: function; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    type text,
    content text,
    meta text,
    valves text,
    is_active boolean,
    is_global boolean,
    updated_at bigint,
    created_at bigint
);


--
-- Name: group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."group" (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    permissions json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: group_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_member (
    id text NOT NULL,
    group_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    updated_at bigint
);


--
-- Name: knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint,
    data json
);


--
-- Name: knowledge_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_directory (
    id text NOT NULL,
    knowledge_id text NOT NULL,
    parent_id text,
    name text NOT NULL,
    user_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: knowledge_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_file (
    id text NOT NULL,
    user_id text NOT NULL,
    knowledge_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    directory_id text
);


--
-- Name: memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory (
    id character varying NOT NULL,
    user_id character varying,
    content text,
    updated_at bigint,
    created_at bigint,
    type character varying DEFAULT 'context'::character varying NOT NULL,
    path text,
    meta json
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    id text NOT NULL,
    user_id text,
    channel_id text,
    content text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    parent_id text,
    reply_to_id text,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at bigint,
    pinned_by text
);


--
-- Name: message_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    message_id text NOT NULL,
    name text NOT NULL,
    created_at bigint
);


--
-- Name: model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model (
    id text NOT NULL,
    user_id text,
    base_model_id text,
    name text,
    params text,
    meta text,
    updated_at bigint,
    created_at bigint,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    id text NOT NULL,
    user_id text,
    title text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: oauth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_session (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pinned_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_note (
    id text NOT NULL,
    user_id text NOT NULL,
    note_id text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: prompt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt (
    id text NOT NULL,
    command character varying,
    user_id character varying NOT NULL,
    name text NOT NULL,
    content text NOT NULL,
    data json,
    meta json,
    is_active boolean DEFAULT true NOT NULL,
    version_id text,
    tags json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: prompt_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt_history (
    id text NOT NULL,
    prompt_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: shared_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_chat (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text NOT NULL,
    title text,
    chat json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    updated_at bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tag (
    id character varying NOT NULL,
    name character varying,
    user_id character varying NOT NULL,
    meta json
);


--
-- Name: tool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    content text,
    specs text,
    meta text,
    valves text,
    updated_at bigint,
    created_at bigint
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id character varying NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    profile_image_url text,
    last_active_at bigint,
    updated_at bigint,
    created_at bigint,
    settings json,
    info json,
    username character varying(50),
    bio text,
    gender text,
    date_of_birth date,
    profile_banner_image_url text,
    timezone character varying,
    presence_state character varying,
    status_emoji character varying,
    status_message text,
    status_expires_at bigint,
    oauth json,
    scim json,
    variables json
);


--
-- Name: config_old id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Data for Name: access_grant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_grant (id, resource_type, resource_id, principal_type, principal_id, permission, created_at) FROM stdin;
1c63dfc1-1023-478d-94b6-6faac269d46b	prompt	80655670-0380-48b7-bcf9-4f9d34f81c9f	group	946c9f9c-483e-4cd0-9419-c5ec9582b447	read	1790362474
66aafcba-7b2c-44ec-99ab-6e8063d601a5	tool	weather_tool	group	946c9f9c-483e-4cd0-9419-c5ec9582b447	read	1790362474
3956b955-b92e-4f4b-bf8a-09dd841aad6e	model	research-assistant	user	e46905eb-7892-437e-af54-878b306f578c	read	1790362474
cbe2e7ba-dafc-4dba-b0a2-5a41fd8993d3	knowledge	98a87fcd-571b-477e-a101-2c0e8f504e2c	group	946c9f9c-483e-4cd0-9419-c5ec9582b447	read	1790362474
8f7a69cd-de47-4c82-95ea-d3f0df929e66	shared_chat	ba20db87-9477-492f-bc21-b405f01b07a1	user	e46905eb-7892-437e-af54-878b306f578c	read	1790362475
9ed8a8c7-2856-4489-8bf5-9b2b734e1afc	note	2efffd0e-a575-4dd7-84e8-80a92bef05db	user	e46905eb-7892-437e-af54-878b306f578c	read	1790362475
50d1b923-4fc2-4224-b950-6f0e30d7981c	note	2efffd0e-a575-4dd7-84e8-80a92bef05db	user	e46905eb-7892-437e-af54-878b306f578c	write	1790362475
72e59f46-4309-412f-84b2-ec1fe2531fc8	channel	1b0e865c-f53c-4252-9409-ed5483e16bd3	group	946c9f9c-483e-4cd0-9419-c5ec9582b447	read	1790362475
d80db0ff-e7d7-4a93-816e-68374421a444	channel	1b0e865c-f53c-4252-9409-ed5483e16bd3	group	946c9f9c-483e-4cd0-9419-c5ec9582b447	write	1790362475
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
d4c1a8e37b62
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, user_id, key, data, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth (id, email, password, active) FROM stdin;
22eb504c-081c-44bf-8695-9c36a7714ee3	admin@example.com	$2b$12$ZKBV9BNlVVuPbCgoUKYpve4G4vxNY/PJ3LHQ.QyCFhrPxvnh35qDC	t
3f12f684-e5fc-40c5-b268-0337affbfd46	alice@example.com	$2b$12$PVD2TiwPPKtlpFIGSDFIoOZzj8xmkcvx9DWT3W27CzatdcBtt8xBe	t
e46905eb-7892-437e-af54-878b306f578c	bob@example.com	$2b$12$t0RfFwZhYfsXetsL471zfe2XNjGDdSfC0YbBUSDcjwtrJhbiItcGq	t
afe23f56-a470-4646-9d20-3d71bc974f4e	carol@example.com	$2b$12$3lTOzet6mIyjrjHLvH2gxOK8IQBXDK5rFgFveIyXqdmx4cpZwYsva	t
\.


--
-- Data for Name: automation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation (id, user_id, name, data, meta, is_active, last_run_at, next_run_at, created_at, updated_at, folder_id) FROM stdin;
\.


--
-- Data for Name: automation_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_run (id, automation_id, chat_id, status, error, created_at) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar (id, user_id, name, color, is_default, data, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event (id, calendar_id, user_id, title, description, start_at, end_at, all_day, rrule, color, location, data, meta, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendee (id, event_id, user_id, status, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel (id, user_id, name, description, data, meta, created_at, updated_at, type, is_private, archived_at, archived_by, deleted_at, deleted_by, updated_by) FROM stdin;
1b0e865c-f53c-4252-9409-ed5483e16bd3	22eb504c-081c-44bf-8695-9c36a7714ee3	lighthouse	Team chatter	null	null	1790362475532846958	1790362475532847228	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: channel_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_file (id, user_id, channel_id, file_id, created_at, updated_at, message_id) FROM stdin;
\.


--
-- Data for Name: channel_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_member (id, channel_id, user_id, created_at, status, is_active, is_channel_muted, is_channel_pinned, data, meta, joined_at, left_at, last_read_at, updated_at, role, invited_by, invited_at) FROM stdin;
73d4ed70-317c-42f3-8b3c-4015aa276764	1b0e865c-f53c-4252-9409-ed5483e16bd3	3f12f684-e5fc-40c5-b268-0337affbfd46	1790362475560001881	joined	t	f	f	null	null	1790362475560001600	\N	1790362475560001801	1790362475560002061	\N	\N	\N
bb0c2e43-fcbc-45ac-b360-dc2d4262454e	1b0e865c-f53c-4252-9409-ed5483e16bd3	e46905eb-7892-437e-af54-878b306f578c	1790362475601026926	joined	t	f	f	null	null	1790362475601026395	\N	1790362475601026745	1790362475601027417	\N	\N	\N
\.


--
-- Data for Name: channel_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_webhook (id, user_id, channel_id, name, profile_image_url, token, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat (id, user_id, title, created_at, updated_at, share_id, archived, chat, pinned, meta, folder_id, tasks, summary, last_read_at, current_message_id, variables, timer_at) FROM stdin;
ba20db87-9477-492f-bc21-b405f01b07a1	3f12f684-e5fc-40c5-b268-0337affbfd46	Packing for Vienna	1790362474	1790362475	9684011e-bb1b-4dea-9dda-a917ec1f9aa5	f	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "696e8770-0bfe-487c-b63f-5dadec137d24", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1790362474, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1790362475}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1790362476}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1790362477, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1790362478}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "696e8770-0bfe-487c-b63f-5dadec137d24", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1790362474, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1790362476}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1790362477, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1790362478}], "files": [{"type": "file", "id": "696e8770-0bfe-487c-b63f-5dadec137d24", "name": "packing.txt", "status": "uploaded"}], "params": {}}	t	{"tags": ["travel"]}	5b004161-6dab-4b30-9d86-f090d3ff3618	null	\N	1790362475	a2-0000-4000-8000-000000000000	{}	\N
db8fa488-91db-49ce-a7c3-8fd5585d6ae1	3f12f684-e5fc-40c5-b268-0337affbfd46	Old plans	1790362475	1790362475	\N	t	{"title": "Old plans", "models": ["mock-model"], "history": {}}	f	{}	\N	null	\N	1790362475	\N	{}	\N
c443d13c-6c87-49ba-bdad-0d17218dc2b0	3f12f684-e5fc-40c5-b268-0337affbfd46	Schnitzel questions	1790362475	1790362475	\N	f	{"id": "c443d13c-6c87-49ba-bdad-0d17218dc2b0", "title": "Schnitzel questions", "models": ["mock-model"], "history": {"currentId": "f68e561c-194a-487f-9115-549ff023c074", "messages": {"b51a905c-067f-4782-8003-85c599b5bddb": {"id": "b51a905c-067f-4782-8003-85c599b5bddb", "parentId": null, "childrenIds": ["1d5baf5c-833b-4ded-9fb4-faf92ddd32ef"], "role": "user", "content": "What is a Schnitzel?", "models": ["mock-model"], "timestamp": 1790362475}, "1d5baf5c-833b-4ded-9fb4-faf92ddd32ef": {"id": "1d5baf5c-833b-4ded-9fb4-faf92ddd32ef", "parentId": "b51a905c-067f-4782-8003-85c599b5bddb", "childrenIds": ["8b6bdf5d-a2e7-45a9-a70b-158d06d22cdd"], "role": "assistant", "content": "Schnitzel is a breaded cutlet.", "done": true, "model": "mock-model", "timestamp": 1790362475, "output": [{"type": "message", "id": "msg_344b38c34d4044ca9f3c7205", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]}, "8b6bdf5d-a2e7-45a9-a70b-158d06d22cdd": {"id": "8b6bdf5d-a2e7-45a9-a70b-158d06d22cdd", "parentId": "1d5baf5c-833b-4ded-9fb4-faf92ddd32ef", "childrenIds": ["f68e561c-194a-487f-9115-549ff023c074"], "role": "user", "content": "How do I eat it?", "models": ["mock-model"], "timestamp": 1790362475}, "f68e561c-194a-487f-9115-549ff023c074": {"id": "f68e561c-194a-487f-9115-549ff023c074", "parentId": "8b6bdf5d-a2e7-45a9-a70b-158d06d22cdd", "childrenIds": [], "role": "assistant", "content": "Try it with lemon.", "done": true, "model": "mock-model", "timestamp": 1790362475, "output": [{"type": "message", "id": "msg_3420dab24d534c2ca063865f", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]}}}, "messages": [{"role": "user", "content": "What is a Schnitzel?"}], "files": [], "tags": [], "timestamp": 1790362475095}	f	{}	\N	null	\N	1790362475	f68e561c-194a-487f-9115-549ff023c074	{}	\N
\.


--
-- Data for Name: chat_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_file (id, user_id, chat_id, file_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_message (id, chat_id, user_id, role, parent_id, content, output, model_id, files, sources, embeds, done, status_history, error, usage, created_at, updated_at, context_summary, meta) FROM stdin;
ba20db87-9477-492f-bc21-b405f01b07a1-u1-0000-4000-8000-000000000000	ba20db87-9477-492f-bc21-b405f01b07a1	3f12f684-e5fc-40c5-b268-0337affbfd46	user	\N	"What should I pack for Vienna?"	null	\N	[{"type": "file", "id": "696e8770-0bfe-487c-b63f-5dadec137d24", "name": "packing.txt", "status": "uploaded"}]	null	null	t	null	null	null	1790362474	1790362474	\N	null
ba20db87-9477-492f-bc21-b405f01b07a1-a1-0000-4000-8000-000000000000	ba20db87-9477-492f-bc21-b405f01b07a1	3f12f684-e5fc-40c5-b268-0337affbfd46	assistant	u1-0000-4000-8000-000000000000	"Pack an umbrella."	null	mock-model	null	null	null	t	null	null	null	1790362475	1790362474	\N	null
ba20db87-9477-492f-bc21-b405f01b07a1-a1b-0000-4000-8000-000000000000	ba20db87-9477-492f-bc21-b405f01b07a1	3f12f684-e5fc-40c5-b268-0337affbfd46	assistant	u1-0000-4000-8000-000000000000	"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses."	null	mock-model	null	null	null	t	null	null	null	1790362476	1790362474	\N	null
ba20db87-9477-492f-bc21-b405f01b07a1-u2-0000-4000-8000-000000000000	ba20db87-9477-492f-bc21-b405f01b07a1	3f12f684-e5fc-40c5-b268-0337affbfd46	user	a1b-0000-4000-8000-000000000000	"And for the evening?"	null	\N	null	null	null	t	null	null	null	1790362477	1790362474	\N	null
ba20db87-9477-492f-bc21-b405f01b07a1-a2-0000-4000-8000-000000000000	ba20db87-9477-492f-bc21-b405f01b07a1	3f12f684-e5fc-40c5-b268-0337affbfd46	assistant	u2-0000-4000-8000-000000000000	"A light jacket."	null	mock-model	null	null	null	t	null	null	null	1790362478	1790362474	\N	null
c443d13c-6c87-49ba-bdad-0d17218dc2b0-b51a905c-067f-4782-8003-85c599b5bddb	c443d13c-6c87-49ba-bdad-0d17218dc2b0	3f12f684-e5fc-40c5-b268-0337affbfd46	user	\N	"What is a Schnitzel?"	null	\N	null	null	null	t	null	null	null	1790362475	1790362475	\N	null
c443d13c-6c87-49ba-bdad-0d17218dc2b0-1d5baf5c-833b-4ded-9fb4-faf92ddd32ef	c443d13c-6c87-49ba-bdad-0d17218dc2b0	3f12f684-e5fc-40c5-b268-0337affbfd46	assistant	b51a905c-067f-4782-8003-85c599b5bddb	"Schnitzel is a breaded cutlet."	[{"type": "message", "id": "msg_344b38c34d4044ca9f3c7205", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]	mock-model	null	null	null	t	null	null	null	1790362475	1790362475	\N	null
c443d13c-6c87-49ba-bdad-0d17218dc2b0-8b6bdf5d-a2e7-45a9-a70b-158d06d22cdd	c443d13c-6c87-49ba-bdad-0d17218dc2b0	3f12f684-e5fc-40c5-b268-0337affbfd46	user	1d5baf5c-833b-4ded-9fb4-faf92ddd32ef	"How do I eat it?"	null	\N	null	null	null	t	null	null	null	1790362475	1790362475	\N	null
c443d13c-6c87-49ba-bdad-0d17218dc2b0-f68e561c-194a-487f-9115-549ff023c074	c443d13c-6c87-49ba-bdad-0d17218dc2b0	3f12f684-e5fc-40c5-b268-0337affbfd46	assistant	8b6bdf5d-a2e7-45a9-a70b-158d06d22cdd	"Try it with lemon."	[{"type": "message", "id": "msg_3420dab24d534c2ca063865f", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]	mock-model	null	null	null	t	null	null	null	1790362475	1790362475	\N	null
\.


--
-- Data for Name: chatidtag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chatidtag (id, tag_name, chat_id, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config (key, value, updated_at) FROM stdin;
direct.enable	false	1790362473
direct.integrations.enable	false	1790362473
ollama.enable	false	1790362473
ollama.base_urls	["http://localhost:11434"]	1790362473
ollama.api_configs	{}	1790362473
openai.enable	true	1790362473
openai.api_keys	["sk-mock"]	1790362473
openai.api_base_urls	["http://127.0.0.1:40299/v1"]	1790362473
openai.api_configs	{}	1790362473
models.base_models_cache	false	1790362473
tool_server.connections	[]	1790362473
terminal_server.connections	[]	1790362473
code_execution.enable	true	1790362473
code_execution.engine	"pyodide"	1790362473
code_execution.jupyter.url	""	1790362473
code_execution.jupyter.auth	""	1790362473
code_execution.jupyter.auth_token	""	1790362473
code_execution.jupyter.auth_password	""	1790362473
code_execution.jupyter.timeout	60	1790362473
code_interpreter.enable	true	1790362473
memories.background_review.enable	false	1790362473
memories.review_interval_turns	10	1790362473
memories.user_char_limit	2000	1790362473
memories.context_char_limit	2000	1790362473
code_interpreter.engine	"pyodide"	1790362473
code_interpreter.prompt_template	""	1790362473
code_interpreter.jupyter.url	""	1790362473
code_interpreter.jupyter.auth	""	1790362473
code_interpreter.jupyter.auth_token	""	1790362473
code_interpreter.jupyter.auth_password	""	1790362473
code_interpreter.jupyter.timeout	60	1790362473
google_drive.enable	false	1790362473
google_drive.client_id	""	1790362473
google_drive.api_key	""	1790362473
onedrive.enable	false	1790362473
onedrive.sharepoint_url	""	1790362473
onedrive.sharepoint_tenant_id	""	1790362473
rag.content_extraction_engine	""	1790362473
rag.content_extraction.supported_media_mime_types	null	1790362473
rag.datalab_marker_api_key	""	1790362473
rag.datalab_marker_api_base_url	""	1790362473
rag.datalab_marker_additional_config	""	1790362473
rag.datalab_marker_use_llm	false	1790362473
rag.datalab_marker_skip_cache	false	1790362473
rag.datalab_marker_force_ocr	false	1790362473
rag.datalab_marker_paginate	false	1790362473
rag.datalab_marker_strip_existing_ocr	false	1790362473
rag.datalab_marker_disable_image_extraction	false	1790362473
rag.datalab_marker_format_lines	false	1790362473
rag.datalab_marker_output_format	"markdown"	1790362473
rag.mineru_api_mode	"local"	1790362473
rag.mineru_api_url	"http://localhost:8000"	1790362473
rag.mineru_api_timeout	"300"	1790362473
rag.mineru_api_key	""	1790362473
rag.mineru_params	{}	1790362473
rag.mineru_file_extensions	["pdf"]	1790362473
rag.external_document_loader_url	""	1790362473
rag.external_document_loader_api_key	""	1790362473
rag.external_document_loader_headers	{}	1790362473
rag.tika_server_url	"http://tika:9998"	1790362473
rag.tika_server_version	"3"	1790362473
rag.docling_server_url	"http://docling:5001"	1790362473
rag.docling_api_key	""	1790362473
rag.docling_params	{}	1790362473
rag.document_intelligence_endpoint	""	1790362473
rag.document_intelligence_key	""	1790362473
rag.document_intelligence_model	"prebuilt-layout"	1790362473
rag.mistral_ocr_api_base_url	"https://api.mistral.ai/v1"	1790362473
rag.mistral_ocr_api_key	""	1790362473
rag.mistral_ocr_use_base64	false	1790362473
rag.paddleocr_vl_base_url	"http://localhost:8080"	1790362473
rag.paddleocr_vl_token	""	1790362473
rag.bypass_embedding_and_retrieval	false	1790362473
rag.top_k	3	1790362473
rag.top_k_reranker	3	1790362473
rag.relevance_threshold	0.0	1790362473
rag.hybrid_bm25_weight	0.5	1790362473
rag.enable_hybrid_search	false	1790362473
rag.enable_hybrid_search_enriched_texts	false	1790362473
rag.full_context	false	1790362473
rag.file.max_count	null	1790362473
rag.file.max_size	null	1790362473
file.image_compression_width	null	1790362473
file.image_compression_height	null	1790362473
rag.file.allowed_extensions	[]	1790362473
rag.embedding_engine	"openai"	1790362473
rag.pdf_extract_images	false	1790362473
rag.pdf_loader_mode	"page"	1790362473
rag.embedding_model	"sentence-transformers/all-MiniLM-L6-v2"	1790362473
rag.tokenizer_model	""	1790362473
rag.embedding_batch_size	1	1790362473
rag.enable_async_embedding	true	1790362473
rag.embedding_concurrent_requests	0	1790362473
rag.reranking_engine	""	1790362473
rag.reranking_model	""	1790362473
rag.reranking_batch_size	32	1790362473
rag.external_reranker_url	""	1790362473
rag.external_reranker_api_key	""	1790362473
rag.external_reranker_timeout	""	1790362473
rag.text_splitter	""	1790362473
rag.enable_markdown_header_text_splitter	true	1790362473
rag.tiktoken_encoding_name	"cl100k_base"	1790362473
rag.chunk_size	1000	1790362473
rag.chunk_min_size_target	0	1790362473
rag.chunk_overlap	100	1790362473
image_generation.engine	"openai"	1790362473
image_generation.model	""	1790362473
image_generation.size	"512x512"	1790362473
image_generation.steps	50	1790362473
image_generation.prompt.enable	true	1790362473
image_generation.automatic1111.base_url	""	1790362473
rag.template	"### Task:\\nRespond to the user query using the provided context, incorporating inline citations in the format [id] **only when the <source> tag includes an explicit id attribute** (e.g., <source id=\\"1\\">).\\n\\n### Guidelines:\\n- If you don't know the answer, clearly state that.\\n- If uncertain, ask the user for clarification.\\n- Respond in the same language as the user's query.\\n- If the context is unreadable or of poor quality, inform the user and provide the best possible answer.\\n- If the answer isn't present in the context but you possess the knowledge, explain this to the user and provide the answer using your own understanding.\\n- **Only include inline citations using [id] (e.g., [1], [2]) when the <source> tag includes an id attribute.**\\n- Do not cite if the <source> tag does not contain an id attribute.\\n- Do not use XML tags in your response.\\n- Ensure citations are concise and directly related to the information provided.\\n\\n### Example of Citation:\\nIf the user asks about a specific topic and the information is found in a source with a provided id attribute, the response should include the citation like in the following example:\\n* \\"According to the study, the proposed method increases efficiency by 20% [1].\\"\\n\\n### Output:\\nProvide a clear and direct response to the user's query, including inline citations in the format [id] only when the <source> tag with id attribute is present in the context.\\n\\n<context>\\n{{CONTEXT}}\\n</context>\\n"	1790362473
rag.openai.api_base_url	"http://127.0.0.1:40299/v1"	1790362473
rag.openai.api_key	"sk-mock"	1790362473
rag.azure_openai.base_url	""	1790362473
rag.azure_openai.api_key	""	1790362473
rag.azure_openai.api_version	""	1790362473
rag.ollama.base_url	"http://localhost:11434"	1790362473
rag.ollama.api_key	""	1790362473
rag.youtube_loader_language	["en"]	1790362473
rag.youtube_loader_proxy_url	""	1790362473
web.search.enable	false	1790362473
web.search.confirmation.enable	false	1790362473
web.search.confirmation.content	"Your query will be sent to the configured web search provider."	1790362473
web.search.engine	""	1790362473
web.search.bypass_embedding_and_retrieval	false	1790362473
web.search.bypass_web_loader	false	1790362473
web.search.result_count	3	1790362473
web.search.domain.filter_list	[]	1790362473
web.search.concurrent_requests	0	1790362473
web.fetch.max_content_length	null	1790362473
web.loader.engine	""	1790362473
web.loader.concurrent_requests	10	1790362473
web.loader.timeout	""	1790362473
web.loader.ssl_verification	true	1790362473
web.search.trust_env	true	1790362473
web.search.ollama_cloud_api_key	""	1790362473
web.search.searxng_query_url	""	1790362473
web.search.openserp_base_url	"http://localhost:7000"	1790362473
web.search.searxng_language	"all"	1790362473
web.search.yacy_query_url	""	1790362473
web.search.yacy_username	""	1790362473
web.search.yacy_password	""	1790362473
web.search.google_pse_api_key	""	1790362473
web.search.google_pse_engine_id	""	1790362473
web.search.brave_search_api_key	""	1790362473
web.search.brave_search_context_tokens	8192	1790362473
web.search.kagi_search_api_key	""	1790362473
web.search.mojeek_search_api_key	""	1790362473
web.search.bocha_search_api_key	""	1790362473
web.search.serpstack_api_key	""	1790362473
web.search.serpstack_https	true	1790362473
web.search.serper_api_key	""	1790362473
web.search.serply_api_key	""	1790362473
web.search.serphouse_api_key	""	1790362473
web.search.serphouse_domain	"google.com"	1790362473
web.search.ddgs_backend	"auto"	1790362473
web.search.jina_api_key	""	1790362473
web.search.jina_api_base_url	""	1790362473
web.search.searchapi_api_key	""	1790362473
web.search.searchapi_engine	""	1790362473
web.search.serpapi_api_key	""	1790362473
web.search.serpapi_engine	""	1790362473
web.search.bing_search_v7_endpoint	"https://api.bing.microsoft.com/v7.0/search"	1790362473
web.search.bing_search_v7_subscription_key	""	1790362473
web.search.azure_ai_search_api_key	""	1790362473
web.search.azure_ai_search_endpoint	""	1790362473
web.search.azure_ai_search_index_name	""	1790362473
web.search.exa_api_key	""	1790362473
web.search.exa_max_content_length	null	1790362473
web.search.perplexity_api_key	""	1790362473
web.search.perplexity_model	"sonar"	1790362473
web.search.perplexity_search_context_usage	"medium"	1790362473
web.search.perplexity_search_api_url	"https://api.perplexity.ai/search"	1790362473
web.search.microsoft_web_iq_api_base_url	"https://api.microsoft.ai/v3"	1790362473
web.search.microsoft_web_iq_api_key	""	1790362473
web.search.microsoft_web_iq_language	"en"	1790362473
web.search.sougou_api_sid	""	1790362473
web.search.sougou_api_sk	""	1790362473
web.search.tavily_api_key	""	1790362473
web.search.tavily_extract_depth	"basic"	1790362473
web.search.staan_api_key	""	1790362473
web.search.staan_market	"en-us"	1790362473
web.search.staan_max_snippets	0	1790362473
web.loader.playwright_ws_url	""	1790362473
web.loader.playwright_timeout	10000	1790362473
web.loader.firecrawl_api_key	""	1790362473
web.loader.firecrawl_api_url	"https://api.firecrawl.dev"	1790362473
web.loader.firecrawl_timeout	""	1790362473
web.search.external_web_search_url	""	1790362473
web.search.external_web_search_api_key	""	1790362473
web.loader.external_web_loader_url	""	1790362473
web.loader.external_web_loader_api_key	""	1790362473
web.search.yandex_web_search_url	""	1790362473
web.search.yandex_web_search_api_key	""	1790362473
web.search.yandex_web_search_config	""	1790362473
web.search.youcom_api_key	""	1790362473
web.search.linkup_api_key	""	1790362473
web.search.linkup_search_params	{}	1790362473
image_generation.enable	false	1790362473
image_generation.automatic1111.api_auth	""	1790362473
image_generation.automatic1111.api_params	{}	1790362473
image_generation.comfyui.base_url	""	1790362473
image_generation.comfyui.api_key	""	1790362473
image_generation.comfyui.workflow	"\\n{\\n  \\"3\\": {\\n    \\"inputs\\": {\\n      \\"seed\\": 0,\\n      \\"steps\\": 20,\\n      \\"cfg\\": 8,\\n      \\"sampler_name\\": \\"euler\\",\\n      \\"scheduler\\": \\"normal\\",\\n      \\"denoise\\": 1,\\n      \\"model\\": [\\n        \\"4\\",\\n        0\\n      ],\\n      \\"positive\\": [\\n        \\"6\\",\\n        0\\n      ],\\n      \\"negative\\": [\\n        \\"7\\",\\n        0\\n      ],\\n      \\"latent_image\\": [\\n        \\"5\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"KSampler\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"KSampler\\"\\n    }\\n  },\\n  \\"4\\": {\\n    \\"inputs\\": {\\n      \\"ckpt_name\\": \\"model.safetensors\\"\\n    },\\n    \\"class_type\\": \\"CheckpointLoaderSimple\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Load Checkpoint\\"\\n    }\\n  },\\n  \\"5\\": {\\n    \\"inputs\\": {\\n      \\"width\\": 512,\\n      \\"height\\": 512,\\n      \\"batch_size\\": 1\\n    },\\n    \\"class_type\\": \\"EmptyLatentImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Empty Latent Image\\"\\n    }\\n  },\\n  \\"6\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"Prompt\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"7\\": {\\n    \\"inputs\\": {\\n      \\"text\\": \\"\\",\\n      \\"clip\\": [\\n        \\"4\\",\\n        1\\n      ]\\n    },\\n    \\"class_type\\": \\"CLIPTextEncode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"CLIP Text Encode (Prompt)\\"\\n    }\\n  },\\n  \\"8\\": {\\n    \\"inputs\\": {\\n      \\"samples\\": [\\n        \\"3\\",\\n        0\\n      ],\\n      \\"vae\\": [\\n        \\"4\\",\\n        2\\n      ]\\n    },\\n    \\"class_type\\": \\"VAEDecode\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"VAE Decode\\"\\n    }\\n  },\\n  \\"9\\": {\\n    \\"inputs\\": {\\n      \\"filename_prefix\\": \\"ComfyUI\\",\\n      \\"images\\": [\\n        \\"8\\",\\n        0\\n      ]\\n    },\\n    \\"class_type\\": \\"SaveImage\\",\\n    \\"_meta\\": {\\n      \\"title\\": \\"Save Image\\"\\n    }\\n  }\\n}\\n"	1790362473
image_generation.comfyui.nodes	[]	1790362473
image_generation.openai.api_base_url	"https://api.openai.com/v1"	1790362473
image_generation.openai.api_version	""	1790362473
image_generation.openai.api_key	""	1790362473
image_generation.openai.params	{}	1790362473
image_generation.gemini.api_base_url	""	1790362473
image_generation.gemini.api_key	""	1790362473
image_generation.gemini.endpoint_method	""	1790362473
images.edit.enable	false	1790362473
images.edit.engine	"openai"	1790362473
images.edit.model	""	1790362473
images.edit.size	""	1790362473
images.edit.openai.api_base_url	"https://api.openai.com/v1"	1790362473
images.edit.openai.api_version	""	1790362473
images.edit.openai.api_key	""	1790362473
images.edit.gemini.api_base_url	""	1790362473
images.edit.gemini.api_key	""	1790362473
images.edit.comfyui.base_url	""	1790362473
images.edit.comfyui.api_key	""	1790362473
images.edit.comfyui.workflow	""	1790362473
images.edit.comfyui.nodes	[]	1790362473
audio.stt.whisper_model	"base"	1790362473
audio.stt.deepgram.api_key	""	1790362473
audio.stt.openai.api_base_url	"https://api.openai.com/v1"	1790362473
audio.stt.openai.api_key	""	1790362473
audio.stt.openai.api_request_format	"multipart"	1790362473
audio.stt.engine	""	1790362473
audio.stt.model	""	1790362473
audio.stt.supported_content_types	[]	1790362473
audio.stt.allowed_extensions	["mp3", "wav", "m4a", "webm", "ogg", "flac", "mp4", "mpga", "mpeg"]	1790362473
audio.stt.azure.api_key	""	1790362473
audio.stt.azure.region	""	1790362473
audio.stt.azure.locales	""	1790362473
audio.stt.azure.base_url	""	1790362473
audio.stt.azure.max_speakers	""	1790362473
audio.stt.mistral.api_key	""	1790362473
audio.stt.mistral.api_base_url	"https://api.mistral.ai/v1"	1790362473
audio.stt.mistral.use_chat_completions	false	1790362473
audio.tts.openai.api_base_url	"https://api.openai.com/v1"	1790362473
audio.tts.openai.api_key	""	1790362473
audio.tts.openai.params	{}	1790362473
audio.tts.api_key	""	1790362473
audio.tts.engine	""	1790362473
audio.tts.model	"tts-1"	1790362473
audio.tts.voice	"alloy"	1790362473
audio.tts.split_on	"punctuation"	1790362473
audio.tts.azure.speech_region	""	1790362473
audio.tts.azure.speech_base_url	""	1790362473
audio.tts.azure.speech_output_format	"audio-24khz-160kbitrate-mono-mp3"	1790362473
audio.tts.mistral.api_key	""	1790362473
audio.tts.mistral.api_base_url	"https://api.mistral.ai/v1"	1790362473
ui.enable_password_change_form	true	1790362473
ui.default_locale	""	1790362473
ui.default_models	null	1790362473
ui.default_pinned_models	null	1790362473
ui.prompt_suggestions	null	1790362473
ui.prompt_suggestions_i18n	{}	1790362473
ui.model_order_list	[]	1790362473
models.default_metadata	{}	1790362473
models.default_params	{}	1790362473
ui.enable_signup	false	1790362474
ui.default_group_id	""	1790362474
ui.default_interface_settings	{}	1790362474
ui.default_user_role	"user"	1790362474
ui.enable_login_form	true	1790362474
ui.i18n	{}	1790362474
ui.pending_user_overlay_content	""	1790362474
ui.pending_user_overlay_title	""	1790362474
ui.watermark	""	1790362474
webui.url	"https://chat.example.com"	1790362474
subagents.enable	false	1790362473
subagents.background_enabled	false	1790362473
subagents.max_concurrent	20	1790362473
subagents.max_async	20	1790362473
subagents.max_iterations	30	1790362473
subagents.max_output	30000	1790362473
subagents.system_prompt	""	1790362473
automations.auth_token_expires_in	"1h"	1790362473
evaluation.arena.enable	true	1790362473
evaluation.arena.models	[]	1790362473
webhook_url	""	1790362473
task.model.default	""	1790362473
task.model.external	""	1790362473
task.model.params	{}	1790362473
chat.context_compaction.model	""	1790362473
chat.context_compaction.enable	false	1790362473
chat.context_compaction.token_threshold	80000	1790362473
chat.context_compaction.token_cap	null	1790362473
chat.context_compaction.retention_percentage	40	1790362473
chat.context_compaction.prompt_template	""	1790362473
chat.tool_permissions.enable	false	1790362473
task.title.prompt_template	""	1790362473
task.tags.prompt_template	""	1790362473
task.image.prompt_template	""	1790362473
task.follow_up.prompt_template	""	1790362473
task.follow_up.enable	false	1790362473
task.tags.enable	false	1790362473
task.title.enable	false	1790362473
task.query.search.enable	true	1790362473
task.query.retrieval.enable	true	1790362473
task.query.prompt_template	""	1790362473
task.autocomplete.enable	false	1790362473
task.autocomplete.input_max_length	-1	1790362473
task.autocomplete.prompt_template	""	1790362473
task.voice.prompt_template	""	1790362473
task.voice.prompt.enable	true	1790362473
task.tools.prompt_template	""	1790362473
ldap.enable	false	1790362473
ldap.server.label	"LDAP Server"	1790362473
ldap.server.host	"localhost"	1790362473
ldap.server.port	389	1790362473
ldap.server.attribute_for_mail	"mail"	1790362473
ldap.server.attribute_for_username	"uid"	1790362473
ldap.server.app_dn	""	1790362473
ldap.server.app_password	""	1790362473
ldap.server.users_dn	""	1790362473
ldap.server.search_filter	""	1790362473
ldap.server.use_tls	true	1790362473
ldap.server.ca_cert_file	""	1790362473
ldap.server.validate_cert	true	1790362473
ldap.server.ciphers	"ALL"	1790362473
ldap.group.enable_management	false	1790362473
ldap.group.enable_creation	false	1790362473
ldap.server.attribute_for_groups	"memberOf"	1790362473
auth.admin.email	null	1790362474
auth.admin.show	true	1790362474
auth.api_key.allowed_endpoints	""	1790362474
auth.api_key.endpoint_restrictions	false	1790362474
auth.enable_api_keys	false	1790362474
auth.jwt_expiry	"4w"	1790362474
automations.enable	true	1790362474
automations.max_count	""	1790362474
automations.min_interval	""	1790362474
calendar.enable	true	1790362474
channels.enable	true	1790362474
channels.model_response_mode	"thread"	1790362474
folders.enable	true	1790362474
folders.max_file_count	""	1790362474
memories.enable	true	1790362474
memories.system_context.enable	true	1790362474
notes.enable	true	1790362474
ui.enable_community_sharing	false	1790362474
ui.enable_message_rating	true	1790362474
ui.enable_user_webhooks	false	1790362474
users.enable_status	true	1790362474
ui.banners	[{"i18n": null, "id": "upgrade-banner", "type": "info", "title": "Maintenance", "content": "Maintenance on Sunday", "dismissible": true, "timestamp": 1700000000}]	1790362474
user.permissions	{"workspace": {"models": false, "knowledge": false, "prompts": true, "tools": false, "skills": false, "models_import": false, "models_export": false, "prompts_import": false, "prompts_export": false, "tools_import": false, "tools_export": false, "skills_import": false, "skills_export": false}, "sharing": {"models": false, "public_models": false, "knowledge": false, "public_knowledge": false, "prompts": false, "public_prompts": false, "tools": false, "public_tools": false, "skills": false, "public_skills": false, "notes": false, "public_notes": false, "folders": false, "public_chats": false, "open_chats": false, "public_calendars": false}, "access_grants": {"allow_users": true, "allow_groups": true}, "chat": {"controls": true, "valves": true, "system_prompt": true, "params": true, "file_upload": true, "web_upload": true, "delete": false, "delete_message": true, "continue_response": true, "regenerate_response": true, "rate_response": true, "edit": true, "share": true, "export": true, "import": true, "stt": true, "tts": true, "call": true, "multiple_models": true, "temporary": true, "temporary_enforced": false}, "features": {"api_keys": false, "notes": true, "channels": true, "folders": true, "direct_tool_servers": false, "web_search": true, "image_generation": true, "code_interpreter": true, "memories": true, "automations": false, "calendar": true, "webhooks": false}, "settings": {"interface": true}}	1790362474
\.


--
-- Data for Name: config_old; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_old (id, data, version, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (collection_name, name, title, filename, content, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, user_id, version, type, data, meta, snapshot, created_at, updated_at) FROM stdin;
a8a4ffe3-506b-43b2-bd55-e96f8851d418	3f12f684-e5fc-40c5-b268-0337affbfd46	0	rating	{"rating": 1, "model_id": "mock-model", "sibling_model_ids": null, "reason": "Accurate", "comment": null}	{"chat_id": "c443d13c-6c87-49ba-bdad-0d17218dc2b0", "message_id": "1d5baf5c-833b-4ded-9fb4-faf92ddd32ef"}	{"chat": {}}	1790362475	1790362475
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, user_id, filename, meta, created_at, hash, data, updated_at, path) FROM stdin;
53ed6416-682d-4563-a98c-f08a13a54d29	22eb504c-081c-44bf-8695-9c36a7714ee3	handbook.txt	{"name": "handbook.txt", "content_type": "text/plain", "size": 72, "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "data": {}, "collection_name": "98a87fcd-571b-477e-a101-2c0e8f504e2c"}	1790362474	51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb	{"status": "completed", "content": "The upgrade handbook says the lighthouse key hangs behind the blue door.", "error": null}	1790362474	/tmp/seed-v0.11.4-r4r049iy/data/uploads/53ed6416-682d-4563-a98c-f08a13a54d29_handbook.txt
696e8770-0bfe-487c-b63f-5dadec137d24	3f12f684-e5fc-40c5-b268-0337affbfd46	packing.txt	{"name": "packing.txt", "content_type": "text/plain", "size": 59, "file_hash": "85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a", "data": {}, "collection_name": "file-696e8770-0bfe-487c-b63f-5dadec137d24"}	1790362474	85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a	{"status": "completed", "content": "Packing list: umbrella, passport, a very old map of Vienna.", "error": null}	1790362474	/tmp/seed-v0.11.4-r4r049iy/data/uploads/696e8770-0bfe-487c-b63f-5dadec137d24_packing.txt
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder (id, parent_id, user_id, name, items, meta, is_expanded, created_at, updated_at, data) FROM stdin;
6481189c-6dc6-4a47-8b02-90d5b5fd9913	\N	3f12f684-e5fc-40c5-b268-0337affbfd46	Trips	null	null	f	1790362474	1790362474	null
5b004161-6dab-4b30-9d86-f090d3ff3618	6481189c-6dc6-4a47-8b02-90d5b5fd9913	3f12f684-e5fc-40c5-b268-0337affbfd46	Vienna	null	null	f	1790362474	1790362474	null
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function (id, user_id, name, type, content, meta, valves, is_active, is_global, updated_at, created_at) FROM stdin;
shout_filter	22eb504c-081c-44bf-8695-9c36a7714ee3	Shout filter	filter	"""\ntitle: Shout filter\n"""\n\nfrom pydantic import BaseModel\n\n\nclass Filter:\n    class Valves(BaseModel):\n        suffix: str = "!"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def inlet(self, body: dict) -> dict:\n        return body\n	{"description": "Adds emphasis", "manifest": {"title": "Shout filter"}}	{"suffix": "!!!"}	t	t	1790362474	1790362474
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."group" (id, user_id, name, description, data, meta, permissions, created_at, updated_at) FROM stdin;
946c9f9c-483e-4cd0-9419-c5ec9582b447	22eb504c-081c-44bf-8695-9c36a7714ee3	Research	People who read the handbook	{"config": {"share": "members"}}	null	null	1790362474	1790362474
\.


--
-- Data for Name: group_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_member (id, group_id, user_id, created_at, updated_at) FROM stdin;
708d9f04-6bbd-4660-92f4-8150e17e5633	946c9f9c-483e-4cd0-9419-c5ec9582b447	3f12f684-e5fc-40c5-b268-0337affbfd46	1790362474	1790362474
04aebedc-8862-4494-b010-89643a52cf08	946c9f9c-483e-4cd0-9419-c5ec9582b447	e46905eb-7892-437e-af54-878b306f578c	1790362474	1790362474
\.


--
-- Data for Name: knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge (id, user_id, name, description, meta, created_at, updated_at, data) FROM stdin;
98a87fcd-571b-477e-a101-2c0e8f504e2c	22eb504c-081c-44bf-8695-9c36a7714ee3	Handbook	Where things are	null	1790362474	1790362474	\N
\.


--
-- Data for Name: knowledge_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_directory (id, knowledge_id, parent_id, name, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_file (id, user_id, knowledge_id, file_id, created_at, updated_at, directory_id) FROM stdin;
6e5a409f-fa54-4d7c-96bd-27f4c0f24319	22eb504c-081c-44bf-8695-9c36a7714ee3	98a87fcd-571b-477e-a101-2c0e8f504e2c	53ed6416-682d-4563-a98c-f08a13a54d29	1790362474	1790362474	\N
\.


--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.memory (id, user_id, content, updated_at, created_at, type, path, meta) FROM stdin;
4fa81ca2-1638-4e04-a657-e2a460609f85	3f12f684-e5fc-40c5-b268-0337affbfd46	Alice is allergic to peanuts.	1790362475	1790362475	context	\N	{"created_by": "manual"}
4a400d4e-8fd5-4718-9b31-8ef0f56c0eea	3f12f684-e5fc-40c5-b268-0337affbfd46	Alice prefers window seats.	1790362475	1790362475	context	\N	{"created_by": "manual"}
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (id, user_id, channel_id, content, data, meta, created_at, updated_at, parent_id, reply_to_id, is_pinned, pinned_at, pinned_by) FROM stdin;
58bedbbb-9fcd-42c1-b5b9-b48d4c40f5bf	3f12f684-e5fc-40c5-b268-0337affbfd46	1b0e865c-f53c-4252-9409-ed5483e16bd3	Who has the lighthouse key?	null	null	1790362475561612325	1790362475561612325	\N	\N	f	\N	\N
42e3b92e-89a0-43ea-aaa3-4b7e847b2c4b	e46905eb-7892-437e-af54-878b306f578c	1b0e865c-f53c-4252-9409-ed5483e16bd3	Behind the blue door.	null	null	1790362475602300203	1790362475602300203	58bedbbb-9fcd-42c1-b5b9-b48d4c40f5bf	\N	f	\N	\N
\.


--
-- Data for Name: message_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reaction (id, user_id, message_id, name, created_at) FROM stdin;
d47aabb4-affe-4d58-ae37-d2c9a300a2c7	e46905eb-7892-437e-af54-878b306f578c	58bedbbb-9fcd-42c1-b5b9-b48d4c40f5bf	thumbsup	1790362475641679097
\.


--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model (id, user_id, base_model_id, name, params, meta, updated_at, created_at, is_active) FROM stdin;
research-assistant	22eb504c-081c-44bf-8695-9c36a7714ee3	mock-model	Research assistant	{"system": "You answer from the handbook.", "temperature": 0.2}	{"profile_image_url": null, "background_image_url": null, "description": "Answers from the handbook", "i18n": null, "capabilities": null, "knowledge": null}	1790362474	1790362474	t
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (id, user_id, title, data, meta, created_at, updated_at) FROM stdin;
2efffd0e-a575-4dd7-84e8-80a92bef05db	3f12f684-e5fc-40c5-b268-0337affbfd46	Groceries	{"content": {"md": "# Groceries\\n\\n- apples\\n- *dark* chocolate", "html": "", "json": null}}	null	1790362475480671649	1790362475480672049
\.


--
-- Data for Name: oauth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_session (id, user_id, provider, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pinned_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_note (id, user_id, note_id, created_at) FROM stdin;
\.


--
-- Data for Name: prompt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt (id, command, user_id, name, content, data, meta, is_active, version_id, tags, created_at, updated_at) FROM stdin;
80655670-0380-48b7-bcf9-4f9d34f81c9f	summarize	22eb504c-081c-44bf-8695-9c36a7714ee3	Summarize	Summarize the following text in three bullet points.	{}	{}	t	2a2bc419-aff6-4b77-a7e7-5f316f5aafc1	[]	1790362474	1790362474
667bf7c7-bd91-4eaf-9200-ea13c0c487ea	alice-draft	3f12f684-e5fc-40c5-b268-0337affbfd46	Alice's draft	Draft a polite reply to this email.	{}	{}	t	b4b0e10c-f02d-4eed-bd08-cc3314d7c43f	[]	1790362474	1790362474
\.


--
-- Data for Name: prompt_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt_history (id, prompt_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
2a2bc419-aff6-4b77-a7e7-5f316f5aafc1	80655670-0380-48b7-bcf9-4f9d34f81c9f	\N	{"name": "Summarize", "content": "Summarize the following text in three bullet points.", "command": "summarize", "data": {}, "meta": {}, "tags": [], "access_grants": [{"id": "1c63dfc1-1023-478d-94b6-6faac269d46b", "resource_type": "prompt", "resource_id": "80655670-0380-48b7-bcf9-4f9d34f81c9f", "principal_type": "group", "principal_id": "946c9f9c-483e-4cd0-9419-c5ec9582b447", "permission": "read", "created_at": 1790362474}]}	22eb504c-081c-44bf-8695-9c36a7714ee3	Initial version	1790362474
b4b0e10c-f02d-4eed-bd08-cc3314d7c43f	667bf7c7-bd91-4eaf-9200-ea13c0c487ea	\N	{"name": "Alice's draft", "content": "Draft a polite reply to this email.", "command": "alice-draft", "data": {}, "meta": {}, "tags": [], "access_grants": []}	3f12f684-e5fc-40c5-b268-0337affbfd46	Initial version	1790362474
\.


--
-- Data for Name: shared_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shared_chat (id, chat_id, user_id, title, chat, created_at, updated_at) FROM stdin;
9684011e-bb1b-4dea-9dda-a917ec1f9aa5	ba20db87-9477-492f-bc21-b405f01b07a1	3f12f684-e5fc-40c5-b268-0337affbfd46	Packing for Vienna	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "696e8770-0bfe-487c-b63f-5dadec137d24", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1790362474, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1790362475}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1790362476}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1790362477, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1790362478}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "696e8770-0bfe-487c-b63f-5dadec137d24", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1790362474, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1790362476}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1790362477, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1790362478}], "files": [{"type": "file", "id": "696e8770-0bfe-487c-b63f-5dadec137d24", "name": "packing.txt", "status": "uploaded"}], "params": {}}	1790362475	1790362475
\.


--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill (id, user_id, name, description, content, meta, is_active, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tag (id, name, user_id, meta) FROM stdin;
travel	travel	3f12f684-e5fc-40c5-b268-0337affbfd46	\N
\.


--
-- Data for Name: tool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool (id, user_id, name, content, specs, meta, valves, updated_at, created_at) FROM stdin;
weather_tool	22eb504c-081c-44bf-8695-9c36a7714ee3	Weather	"""\ntitle: Weather\n"""\n\n\nfrom pydantic import BaseModel\n\n\nclass Tools:\n    class Valves(BaseModel):\n        units: str = "metric"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def get_weather(self, city: str) -> str:\n        """Report the weather in a city."""\n        return f"Sunny in {city}"\n	[{"name": "get_weather", "description": "Report the weather in a city.", "parameters": {"properties": {"city": {"type": "string"}}, "required": ["city"], "type": "object"}}]	{"i18n": null, "description": "Weather lookups", "manifest": {"title": "Weather"}, "has_user_valves": false}	\N	1790362474	1790362474
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, role, profile_image_url, last_active_at, updated_at, created_at, settings, info, username, bio, gender, date_of_birth, profile_banner_image_url, timezone, presence_state, status_emoji, status_message, status_expires_at, oauth, scim, variables) FROM stdin;
22eb504c-081c-44bf-8695-9c36a7714ee3	Ada Admin	admin@example.com	admin	/user.png	1790362474	1790362473	1790362473	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
afe23f56-a470-4646-9d20-3d71bc974f4e	Carol Outsider	carol@example.com	user	/user.png	1790362474	1790362474	1790362474	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
3f12f684-e5fc-40c5-b268-0337affbfd46	Alice Author	alice@example.com	user	/user.png	1790362474	1790362474	1790362474	{"ui": {"theme": "dark", "chatBubble": false, "notesSeen": 3}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
e46905eb-7892-437e-af54-878b306f578c	Bob Reader	bob@example.com	user	/user.png	1790362475	1790362474	1790362474	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null	\N
\.


--
-- Name: config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_id_seq', 1, false);


--
-- Name: access_grant access_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT access_grant_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_key UNIQUE (key);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: automation automation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation
    ADD CONSTRAINT automation_pkey PRIMARY KEY (id);


--
-- Name: automation_run automation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_run
    ADD CONSTRAINT automation_run_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendee calendar_event_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT calendar_event_attendee_pkey PRIMARY KEY (id);


--
-- Name: calendar_event calendar_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event
    ADD CONSTRAINT calendar_event_pkey PRIMARY KEY (id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (id);


--
-- Name: channel_file channel_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_pkey PRIMARY KEY (id);


--
-- Name: channel_member channel_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT channel_member_pkey PRIMARY KEY (id);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_webhook channel_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_pkey PRIMARY KEY (id);


--
-- Name: chat_file chat_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: chat chat_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_share_id_key UNIQUE (share_id);


--
-- Name: chatidtag chatidtag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chatidtag
    ADD CONSTRAINT chatidtag_pkey PRIMARY KEY (id);


--
-- Name: config_old config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_old
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey1 PRIMARY KEY (key);


--
-- Name: document document_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_name_key UNIQUE (name);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (collection_name);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id, user_id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: group_member group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_pkey PRIMARY KEY (id);


--
-- Name: group group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pkey PRIMARY KEY (id);


--
-- Name: knowledge_directory knowledge_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_pkey PRIMARY KEY (id);


--
-- Name: knowledge_file knowledge_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_pkey PRIMARY KEY (id);


--
-- Name: knowledge knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge
    ADD CONSTRAINT knowledge_pkey PRIMARY KEY (id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: message_reaction message_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reaction
    ADD CONSTRAINT message_reaction_pkey PRIMARY KEY (id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: oauth_session oauth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_pkey PRIMARY KEY (id);


--
-- Name: pinned_note pinned_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_pkey PRIMARY KEY (id);


--
-- Name: tag pk_id_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_id_user_id PRIMARY KEY (id, user_id);


--
-- Name: prompt_history prompt_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt_history
    ADD CONSTRAINT prompt_history_pkey PRIMARY KEY (id);


--
-- Name: prompt prompt_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt
    ADD CONSTRAINT prompt_new_pkey PRIMARY KEY (id);


--
-- Name: shared_chat shared_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_pkey PRIMARY KEY (id);


--
-- Name: skill skill_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_name_key UNIQUE (name);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- Name: tool tool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool
    ADD CONSTRAINT tool_pkey PRIMARY KEY (id);


--
-- Name: access_grant uq_access_grant_grant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT uq_access_grant_grant UNIQUE (resource_type, resource_id, principal_type, principal_id, permission);


--
-- Name: channel_file uq_channel_file_channel_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT uq_channel_file_channel_file UNIQUE (channel_id, file_id);


--
-- Name: chat_file uq_chat_file_chat_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT uq_chat_file_chat_file UNIQUE (chat_id, file_id);


--
-- Name: calendar_event_attendee uq_event_attendee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT uq_event_attendee UNIQUE (event_id, user_id);


--
-- Name: group_member uq_group_member_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT uq_group_member_group_user UNIQUE (group_id, user_id);


--
-- Name: knowledge_directory uq_knowledge_directory_knowledge_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT uq_knowledge_directory_knowledge_parent_name UNIQUE (knowledge_id, parent_id, name);


--
-- Name: knowledge_file uq_knowledge_file_knowledge_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT uq_knowledge_file_knowledge_file UNIQUE (knowledge_id, file_id);


--
-- Name: pinned_note uq_pinned_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT uq_pinned_note UNIQUE (user_id, note_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: chat_message_chat_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_parent_idx ON public.chat_message USING btree (chat_id, parent_id);


--
-- Name: chat_message_chat_role_done_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_role_done_idx ON public.chat_message USING btree (chat_id, role, done);


--
-- Name: chat_message_model_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_model_created_idx ON public.chat_message USING btree (model_id, created_at);


--
-- Name: chat_message_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_user_created_idx ON public.chat_message USING btree (user_id, created_at);


--
-- Name: folder_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_idx ON public.chat USING btree (folder_id);


--
-- Name: folder_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_user_id_idx ON public.chat USING btree (folder_id, user_id);


--
-- Name: idx_access_grant_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_principal ON public.access_grant USING btree (principal_type, principal_id);


--
-- Name: idx_access_grant_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_resource ON public.access_grant USING btree (resource_type, resource_id);


--
-- Name: idx_oauth_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_expires_at ON public.oauth_session USING btree (expires_at);


--
-- Name: idx_oauth_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_id ON public.oauth_session USING btree (user_id);


--
-- Name: idx_oauth_session_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_provider ON public.oauth_session USING btree (user_id, provider);


--
-- Name: idx_skill_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_updated_at ON public.skill USING btree (updated_at);


--
-- Name: idx_skill_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_user_id ON public.skill USING btree (user_id);


--
-- Name: is_global_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX is_global_idx ON public.function USING btree (is_global);


--
-- Name: ix_automation_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_next_run ON public.automation USING btree (next_run_at);


--
-- Name: ix_automation_run_automation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_run_automation_id ON public.automation_run USING btree (automation_id);


--
-- Name: ix_automation_user_folder; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_user_folder ON public.automation USING btree (user_id, folder_id);


--
-- Name: ix_calendar_event_attendee_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_attendee_user ON public.calendar_event_attendee USING btree (user_id, status);


--
-- Name: ix_calendar_event_calendar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_calendar ON public.calendar_event USING btree (calendar_id, start_at);


--
-- Name: ix_calendar_event_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_user_date ON public.calendar_event USING btree (user_id, start_at);


--
-- Name: ix_calendar_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_user ON public.calendar USING btree (user_id);


--
-- Name: ix_channel_file_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_channel_id ON public.channel_file USING btree (channel_id);


--
-- Name: ix_channel_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_file_id ON public.channel_file USING btree (file_id);


--
-- Name: ix_channel_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_user_id ON public.channel_file USING btree (user_id);


--
-- Name: ix_chat_file_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_chat_id ON public.chat_file USING btree (chat_id);


--
-- Name: ix_chat_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_file_id ON public.chat_file USING btree (file_id);


--
-- Name: ix_chat_file_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_message_id ON public.chat_file USING btree (message_id);


--
-- Name: ix_chat_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_user_id ON public.chat_file USING btree (user_id);


--
-- Name: ix_chat_message_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_chat_id ON public.chat_message USING btree (chat_id);


--
-- Name: ix_chat_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_created_at ON public.chat_message USING btree (created_at);


--
-- Name: ix_chat_message_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_model_id ON public.chat_message USING btree (model_id);


--
-- Name: ix_chat_message_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_user_id ON public.chat_message USING btree (user_id);


--
-- Name: ix_group_member_user_id_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_group_member_user_id_group_id ON public.group_member USING btree (user_id, group_id);


--
-- Name: ix_knowledge_directory_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_knowledge_id ON public.knowledge_directory USING btree (knowledge_id);


--
-- Name: ix_knowledge_directory_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_parent_id ON public.knowledge_directory USING btree (parent_id);


--
-- Name: ix_knowledge_file_directory_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_directory_id ON public.knowledge_file USING btree (directory_id);


--
-- Name: ix_knowledge_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_file_id ON public.knowledge_file USING btree (file_id);


--
-- Name: ix_knowledge_file_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_knowledge_id ON public.knowledge_file USING btree (knowledge_id);


--
-- Name: ix_knowledge_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_user_id ON public.knowledge_file USING btree (user_id);


--
-- Name: ix_memory_id_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_id_user_id ON public.memory USING btree (id, user_id);


--
-- Name: ix_memory_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_type ON public.memory USING btree (type);


--
-- Name: ix_memory_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_user_id ON public.memory USING btree (user_id);


--
-- Name: ix_prompt_history_prompt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompt_history_prompt_id ON public.prompt_history USING btree (prompt_id);


--
-- Name: ix_prompt_new_command; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_prompt_new_command ON public.prompt USING btree (command);


--
-- Name: timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX timer_at_idx ON public.chat USING btree (timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: updated_at_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX updated_at_user_id_idx ON public.chat USING btree (updated_at, user_id);


--
-- Name: uq_user_email_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_user_email_lower ON public."user" USING btree (lower((email)::text)) WHERE (email IS NOT NULL);


--
-- Name: user_id_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_archived_idx ON public.chat USING btree (user_id, archived);


--
-- Name: user_id_folder_unread_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_folder_unread_idx ON public.chat USING btree (user_id, folder_id, archived, updated_at, last_read_at, id);


--
-- Name: user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_idx ON public.tag USING btree (user_id);


--
-- Name: user_id_pinned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_pinned_idx ON public.chat USING btree (user_id, pinned);


--
-- Name: user_id_timer_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_timer_at_idx ON public.chat USING btree (user_id, timer_at) WHERE (timer_at IS NOT NULL);


--
-- Name: user_id_updated_at_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_updated_at_id_idx ON public.chat USING btree (user_id, updated_at DESC, id);


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: channel_webhook channel_webhook_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: chat_message chat_message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: channel_file fk_channel_file_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT fk_channel_file_message_id FOREIGN KEY (message_id) REFERENCES public.message(id) ON DELETE CASCADE;


--
-- Name: knowledge_file fk_knowledge_file_directory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT fk_knowledge_file_directory_id FOREIGN KEY (directory_id) REFERENCES public.knowledge_directory(id) ON DELETE SET NULL;


--
-- Name: group_member group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: group_member group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_directory(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: oauth_session oauth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: pinned_note pinned_note_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id) ON DELETE CASCADE;


--
-- Name: shared_chat shared_chat_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

