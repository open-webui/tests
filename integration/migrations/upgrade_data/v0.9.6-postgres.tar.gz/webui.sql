--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_grant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_grant (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    user_id text,
    key text NOT NULL,
    data json,
    expires_at bigint,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth (
    id character varying NOT NULL,
    email character varying,
    password text,
    active boolean
);


--
-- Name: automation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    data json NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: automation_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_run (
    id text NOT NULL,
    automation_id text NOT NULL,
    chat_id text,
    status text NOT NULL,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    color text,
    is_default boolean NOT NULL,
    data json,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event (
    id text NOT NULL,
    calendar_id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    start_at bigint NOT NULL,
    end_at bigint,
    all_day boolean NOT NULL,
    rrule text,
    color text,
    location text,
    data json,
    meta json,
    is_cancelled boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event_attendee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendee (
    id text NOT NULL,
    event_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    type text,
    is_private boolean,
    archived_at bigint,
    archived_by text,
    deleted_at bigint,
    deleted_by text,
    updated_by text
);


--
-- Name: channel_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_file (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    message_id text
);


--
-- Name: channel_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_member (
    id text NOT NULL,
    channel_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    status text,
    is_active boolean DEFAULT true NOT NULL,
    is_channel_muted boolean DEFAULT false NOT NULL,
    is_channel_pinned boolean DEFAULT false NOT NULL,
    data json,
    meta json,
    joined_at bigint NOT NULL,
    left_at bigint,
    last_read_at bigint,
    updated_at bigint,
    role text,
    invited_by text,
    invited_at bigint
);


--
-- Name: channel_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_webhook (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    profile_image_url text,
    token text NOT NULL,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    user_id character varying,
    title text,
    old_chat text,
    created_at bigint,
    updated_at bigint,
    share_id text,
    archived boolean,
    chat json,
    pinned boolean,
    meta json DEFAULT '{}'::json NOT NULL,
    folder_id text,
    tasks json,
    summary text,
    last_read_at bigint
);


--
-- Name: chat_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_file (
    id text NOT NULL,
    user_id text NOT NULL,
    chat_id text NOT NULL,
    file_id text NOT NULL,
    message_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text,
    role text NOT NULL,
    parent_id text,
    content json,
    output json,
    model_id text,
    files json,
    sources json,
    embeds json,
    done boolean,
    status_history json,
    error json,
    usage json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: chatidtag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chatidtag (
    id character varying NOT NULL,
    tag_name character varying,
    chat_id character varying,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    id integer NOT NULL,
    data json NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    collection_name character varying NOT NULL,
    name character varying,
    title text,
    filename text,
    content text,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    user_id text,
    version bigint,
    type text,
    data json,
    meta json,
    snapshot json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id character varying NOT NULL,
    user_id character varying,
    filename text,
    meta json,
    created_at bigint,
    hash text,
    data json,
    updated_at bigint,
    path text
);


--
-- Name: folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder (
    id text NOT NULL,
    parent_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    items json,
    meta json,
    is_expanded boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    data json
);


--
-- Name: function; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    type text,
    content text,
    meta text,
    valves text,
    is_active boolean,
    is_global boolean,
    updated_at bigint,
    created_at bigint
);


--
-- Name: group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."group" (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    permissions json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: group_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_member (
    id text NOT NULL,
    group_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    updated_at bigint
);


--
-- Name: knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint,
    data json
);


--
-- Name: knowledge_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_directory (
    id text NOT NULL,
    knowledge_id text NOT NULL,
    parent_id text,
    name text NOT NULL,
    user_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: knowledge_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_file (
    id text NOT NULL,
    user_id text NOT NULL,
    knowledge_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    directory_id text
);


--
-- Name: memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory (
    id character varying NOT NULL,
    user_id character varying,
    content text,
    updated_at bigint,
    created_at bigint
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    id text NOT NULL,
    user_id text,
    channel_id text,
    content text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    parent_id text,
    reply_to_id text,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at bigint,
    pinned_by text
);


--
-- Name: message_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    message_id text NOT NULL,
    name text NOT NULL,
    created_at bigint
);


--
-- Name: model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model (
    id text NOT NULL,
    user_id text,
    base_model_id text,
    name text,
    params text,
    meta text,
    updated_at bigint,
    created_at bigint,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    id text NOT NULL,
    user_id text,
    title text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: oauth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_session (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pinned_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_note (
    id text NOT NULL,
    user_id text NOT NULL,
    note_id text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: prompt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt (
    id text NOT NULL,
    command character varying,
    user_id character varying NOT NULL,
    name text NOT NULL,
    content text NOT NULL,
    data json,
    meta json,
    is_active boolean DEFAULT true NOT NULL,
    version_id text,
    tags json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: prompt_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt_history (
    id text NOT NULL,
    prompt_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: shared_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_chat (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text NOT NULL,
    title text,
    chat json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    updated_at bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tag (
    id character varying NOT NULL,
    name character varying,
    user_id character varying NOT NULL,
    meta json
);


--
-- Name: tool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    content text,
    specs text,
    meta text,
    valves text,
    updated_at bigint,
    created_at bigint
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id character varying NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    profile_image_url text,
    last_active_at bigint,
    updated_at bigint,
    created_at bigint,
    settings json,
    info json,
    username character varying(50),
    bio text,
    gender text,
    date_of_birth date,
    profile_banner_image_url text,
    timezone character varying,
    presence_state character varying,
    status_emoji character varying,
    status_message text,
    status_expires_at bigint,
    oauth json,
    scim json
);


--
-- Name: config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Data for Name: access_grant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_grant (id, resource_type, resource_id, principal_type, principal_id, permission, created_at) FROM stdin;
38af3862-1137-4088-9354-f38bebe414f9	prompt	6edc1edf-1c5d-49fa-8338-75af16973647	group	ddb62723-0ee0-47d8-a31a-34d95be5eb00	read	1791544619
a81ce04a-8b95-416a-be57-37480545c050	tool	weather_tool	group	ddb62723-0ee0-47d8-a31a-34d95be5eb00	read	1791544619
edb34d3c-fae0-4a16-afa0-e2b82940779c	model	research-assistant	user	7f83f8e8-8d3d-4bb0-bd78-c481993db872	read	1791544619
81f51724-6989-4455-94b9-11640c329a2b	skill	trip-planner	group	ddb62723-0ee0-47d8-a31a-34d95be5eb00	read	1791544619
cc470a27-7adb-47ae-8a78-82af7a80965b	skill	trip-planner	user	7f83f8e8-8d3d-4bb0-bd78-c481993db872	write	1791544619
eb71809d-6539-41b6-bd82-34f18b644226	skill	house-style	user	*	read	1791544620
86dc7bcb-fae9-4f5e-9bdd-d68281f08c16	skill	dave-notes	group	ddb62723-0ee0-47d8-a31a-34d95be5eb00	read	1791544620
70ac7e80-c10a-479f-bbca-723935f163b2	knowledge	fd6b412c-7311-4aae-a949-1354be4a4c3d	group	ddb62723-0ee0-47d8-a31a-34d95be5eb00	read	1791544620
35617b6a-2494-426a-968f-e027448ad06a	shared_chat	eda3ec1f-88cb-4e8e-950c-3111558698a0	user	7f83f8e8-8d3d-4bb0-bd78-c481993db872	read	1791544621
c750edc6-71ef-4d7d-a98b-c4f3ec0b3120	note	4ed5d13d-63b3-4068-8c03-9b8571a4cada	user	7f83f8e8-8d3d-4bb0-bd78-c481993db872	read	1791544621
b0a542ac-0817-4402-a8b5-b7191feb0583	note	4ed5d13d-63b3-4068-8c03-9b8571a4cada	user	7f83f8e8-8d3d-4bb0-bd78-c481993db872	write	1791544621
dc836d36-6cb4-419d-8279-94e23413b187	channel	e1d8d956-6dc7-478a-98e5-e1f04259bb37	group	ddb62723-0ee0-47d8-a31a-34d95be5eb00	read	1791544621
a9963b5c-8e58-4195-9c13-cc78d98afdee	channel	e1d8d956-6dc7-478a-98e5-e1f04259bb37	group	ddb62723-0ee0-47d8-a31a-34d95be5eb00	write	1791544621
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
461111b60977
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, user_id, key, data, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth (id, email, password, active) FROM stdin;
ec9f46f7-27d8-4045-9852-401ccd233693	admin@example.com	$2b$12$TknZrYti6A6OCfM4Scz0g.7SVfJ9Cb55lE80lIcaPuGhjoPFoIAka	t
6dfcf736-78c9-4eb3-9337-a140900ba51e	alice@example.com	$2b$12$6eB54MGt6TJAZiMXO6CUIeDsKMVu1bTnyV2WSMlpfswxcpJ2ZfGKC	t
7f83f8e8-8d3d-4bb0-bd78-c481993db872	bob@example.com	$2b$12$XXBlbZ2cNq8rIuaCo2jnhOmXH3wBpCaHRAZ3DlhlJu.lxlcuOpoR.	t
811ec59c-ea87-4b95-b27e-b39b9c1a48cd	carol@example.com	$2b$12$L14bsQX5tuVJa6kLes1wh.gW0deC4by9GqD/mnyCYPFlxoI14aQnG	t
\.


--
-- Data for Name: automation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation (id, user_id, name, data, meta, is_active, last_run_at, next_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: automation_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_run (id, automation_id, chat_id, status, error, created_at) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar (id, user_id, name, color, is_default, data, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event (id, calendar_id, user_id, title, description, start_at, end_at, all_day, rrule, color, location, data, meta, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendee (id, event_id, user_id, status, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel (id, user_id, name, description, data, meta, created_at, updated_at, type, is_private, archived_at, archived_by, deleted_at, deleted_by, updated_by) FROM stdin;
e1d8d956-6dc7-478a-98e5-e1f04259bb37	ec9f46f7-27d8-4045-9852-401ccd233693	lighthouse	Team chatter	null	null	1791544621902783804	1791544621902784174	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: channel_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_file (id, user_id, channel_id, file_id, created_at, updated_at, message_id) FROM stdin;
\.


--
-- Data for Name: channel_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_member (id, channel_id, user_id, created_at, status, is_active, is_channel_muted, is_channel_pinned, data, meta, joined_at, left_at, last_read_at, updated_at, role, invited_by, invited_at) FROM stdin;
1d137797-698a-4610-9853-0982fcc2ad58	e1d8d956-6dc7-478a-98e5-e1f04259bb37	6dfcf736-78c9-4eb3-9337-a140900ba51e	1791544621942715035	joined	t	f	f	null	null	1791544621942714434	\N	1791544621942714924	1791544621942715235	\N	\N	\N
3f5d5f8c-8805-4a28-9559-7d2bd2c3f53c	e1d8d956-6dc7-478a-98e5-e1f04259bb37	7f83f8e8-8d3d-4bb0-bd78-c481993db872	1791544622007229515	joined	t	f	f	null	null	1791544622007229084	\N	1791544622007229395	1791544622007229615	\N	\N	\N
\.


--
-- Data for Name: channel_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_webhook (id, user_id, channel_id, name, profile_image_url, token, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat (id, user_id, title, old_chat, created_at, updated_at, share_id, archived, chat, pinned, meta, folder_id, tasks, summary, last_read_at) FROM stdin;
eda3ec1f-88cb-4e8e-950c-3111558698a0	6dfcf736-78c9-4eb3-9337-a140900ba51e	Packing for Vienna	\N	1791544621	1791544621	0bac0bb0-67e3-4392-8933-41f38c454cf8	f	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "66eab207-aa7c-48dc-9dde-c6e38b39579d", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1791544621, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1791544622}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1791544623}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1791544624, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1791544625}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "66eab207-aa7c-48dc-9dde-c6e38b39579d", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1791544621, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1791544623}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1791544624, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1791544625}], "files": [{"type": "file", "id": "66eab207-aa7c-48dc-9dde-c6e38b39579d", "name": "packing.txt", "status": "uploaded"}], "params": {}}	t	{"tags": ["travel"]}	da4010cd-9bec-49bd-882e-e3871a503783	null	\N	\N
41054faf-aff2-47e8-90c7-1a96de739e4d	6dfcf736-78c9-4eb3-9337-a140900ba51e	Where does the lighthouse key hang?	\N	1791544621	1791544621	\N	f	{"id": "41054faf-aff2-47e8-90c7-1a96de739e4d", "title": "Where does the lighthouse key hang?", "models": ["mock-model"], "history": {"currentId": "adca0f18-4388-4c28-9d11-1b782291f164", "messages": {"92699958-1d61-4c48-bdae-94fe57c0624f": {"id": "92699958-1d61-4c48-bdae-94fe57c0624f", "parentId": null, "childrenIds": ["adca0f18-4388-4c28-9d11-1b782291f164"], "role": "user", "content": "Where does the lighthouse key hang?", "models": ["mock-model"], "timestamp": 1791544621, "files": [{"type": "collection", "id": "fd6b412c-7311-4aae-a949-1354be4a4c3d", "name": "Handbook"}]}, "adca0f18-4388-4c28-9d11-1b782291f164": {"id": "adca0f18-4388-4c28-9d11-1b782291f164", "parentId": "92699958-1d61-4c48-bdae-94fe57c0624f", "childrenIds": [], "role": "assistant", "content": "Behind the blue door [1].", "done": true, "model": "mock-model", "timestamp": 1791544621, "statusHistory": [{"action": "queries_generated", "queries": ["ok"], "done": false}, {"action": "sources_retrieved", "count": 1, "done": true}], "sources": [{"source": {"type": "collection", "id": "fd6b412c-7311-4aae-a949-1354be4a4c3d", "name": "Handbook"}, "document": ["The upgrade handbook says the lighthouse key hangs behind the blue door."], "metadata": [{"source": "handbook.txt", "name": "handbook.txt", "file_id": "30fbd0fd-4fa6-4f94-939a-6ab0b3e2e48c", "hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "embedding_config": "{'engine': 'openai', 'model': 'sentence-transformers/all-MiniLM-L6-v2'}", "start_index": 0, "created_by": "ec9f46f7-27d8-4045-9852-401ccd233693"}], "distances": [0.9999999403953552]}], "output": [{"type": "message", "id": "msg_371c09da9cc644d6bc620b25", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Behind the blue door [1]."}]}]}}}, "messages": [{"role": "user", "content": "Where does the lighthouse key hang?"}], "files": [{"type": "collection", "id": "fd6b412c-7311-4aae-a949-1354be4a4c3d", "name": "Handbook"}], "tags": [], "timestamp": 1791544621559}	f	{}	\N	null	\N	\N
7ffb7379-bfbf-4ac2-88ff-a1b737354a37	6dfcf736-78c9-4eb3-9337-a140900ba51e	Schnitzel questions	\N	1791544621	1791544621	\N	f	{"id": "7ffb7379-bfbf-4ac2-88ff-a1b737354a37", "title": "Schnitzel questions", "models": ["mock-model"], "history": {"currentId": "56db5164-5b8a-4ce0-afe4-bc9a799b8108", "messages": {"6b715ce3-b8ae-4fcc-9fa3-b4a4ccf99b0e": {"id": "6b715ce3-b8ae-4fcc-9fa3-b4a4ccf99b0e", "parentId": null, "childrenIds": ["273c4535-ef5c-461e-a5fb-d7ad64349ca1"], "role": "user", "content": "What is a Schnitzel?", "models": ["mock-model"], "timestamp": 1791544621}, "273c4535-ef5c-461e-a5fb-d7ad64349ca1": {"id": "273c4535-ef5c-461e-a5fb-d7ad64349ca1", "parentId": "6b715ce3-b8ae-4fcc-9fa3-b4a4ccf99b0e", "childrenIds": ["e4009c63-8684-4750-b226-06873a503800"], "role": "assistant", "content": "Schnitzel is a breaded cutlet.", "done": true, "model": "mock-model", "timestamp": 1791544621, "output": [{"type": "message", "id": "msg_7afb3983d053490b80a687b5", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]}, "e4009c63-8684-4750-b226-06873a503800": {"id": "e4009c63-8684-4750-b226-06873a503800", "parentId": "273c4535-ef5c-461e-a5fb-d7ad64349ca1", "childrenIds": ["56db5164-5b8a-4ce0-afe4-bc9a799b8108"], "role": "user", "content": "How do I eat it?", "models": ["mock-model"], "timestamp": 1791544621}, "56db5164-5b8a-4ce0-afe4-bc9a799b8108": {"id": "56db5164-5b8a-4ce0-afe4-bc9a799b8108", "parentId": "e4009c63-8684-4750-b226-06873a503800", "childrenIds": [], "role": "assistant", "content": "Try it with lemon.", "done": true, "model": "mock-model", "timestamp": 1791544621, "output": [{"type": "message", "id": "msg_e16a477411b041b1b60d1ff9", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]}}}, "messages": [{"role": "user", "content": "What is a Schnitzel?"}], "files": [], "tags": [], "timestamp": 1791544621207}	f	{}	\N	null	\N	\N
549c0622-626c-475c-b319-02d1e1964967	6dfcf736-78c9-4eb3-9337-a140900ba51e	Old plans	\N	1791544621	1791544621	\N	t	{"title": "Old plans", "models": ["mock-model"], "history": {}}	f	{}	\N	null	\N	\N
\.


--
-- Data for Name: chat_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_file (id, user_id, chat_id, file_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_message (id, chat_id, user_id, role, parent_id, content, output, model_id, files, sources, embeds, done, status_history, error, usage, created_at, updated_at) FROM stdin;
eda3ec1f-88cb-4e8e-950c-3111558698a0-u1-0000-4000-8000-000000000000	eda3ec1f-88cb-4e8e-950c-3111558698a0	6dfcf736-78c9-4eb3-9337-a140900ba51e	user	\N	"What should I pack for Vienna?"	null	\N	[{"type": "file", "id": "66eab207-aa7c-48dc-9dde-c6e38b39579d", "name": "packing.txt", "status": "uploaded"}]	null	null	t	null	null	null	1791544621	1791544621
eda3ec1f-88cb-4e8e-950c-3111558698a0-a1-0000-4000-8000-000000000000	eda3ec1f-88cb-4e8e-950c-3111558698a0	6dfcf736-78c9-4eb3-9337-a140900ba51e	assistant	u1-0000-4000-8000-000000000000	"Pack an umbrella."	null	mock-model	null	null	null	t	null	null	null	1791544622	1791544621
eda3ec1f-88cb-4e8e-950c-3111558698a0-a1b-0000-4000-8000-000000000000	eda3ec1f-88cb-4e8e-950c-3111558698a0	6dfcf736-78c9-4eb3-9337-a140900ba51e	assistant	u1-0000-4000-8000-000000000000	"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses."	null	mock-model	null	null	null	t	null	null	null	1791544623	1791544621
eda3ec1f-88cb-4e8e-950c-3111558698a0-u2-0000-4000-8000-000000000000	eda3ec1f-88cb-4e8e-950c-3111558698a0	6dfcf736-78c9-4eb3-9337-a140900ba51e	user	a1b-0000-4000-8000-000000000000	"And for the evening?"	null	\N	null	null	null	t	null	null	null	1791544624	1791544621
eda3ec1f-88cb-4e8e-950c-3111558698a0-a2-0000-4000-8000-000000000000	eda3ec1f-88cb-4e8e-950c-3111558698a0	6dfcf736-78c9-4eb3-9337-a140900ba51e	assistant	u2-0000-4000-8000-000000000000	"A light jacket."	null	mock-model	null	null	null	t	null	null	null	1791544625	1791544621
7ffb7379-bfbf-4ac2-88ff-a1b737354a37-6b715ce3-b8ae-4fcc-9fa3-b4a4ccf99b0e	7ffb7379-bfbf-4ac2-88ff-a1b737354a37	6dfcf736-78c9-4eb3-9337-a140900ba51e	user	\N	"What is a Schnitzel?"	null	\N	null	null	null	t	null	null	null	1791544621	1791544621
7ffb7379-bfbf-4ac2-88ff-a1b737354a37-273c4535-ef5c-461e-a5fb-d7ad64349ca1	7ffb7379-bfbf-4ac2-88ff-a1b737354a37	6dfcf736-78c9-4eb3-9337-a140900ba51e	assistant	6b715ce3-b8ae-4fcc-9fa3-b4a4ccf99b0e	"Schnitzel is a breaded cutlet."	[{"type": "message", "id": "msg_7afb3983d053490b80a687b5", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]	mock-model	null	null	null	t	null	null	null	1791544621	1791544621
7ffb7379-bfbf-4ac2-88ff-a1b737354a37-e4009c63-8684-4750-b226-06873a503800	7ffb7379-bfbf-4ac2-88ff-a1b737354a37	6dfcf736-78c9-4eb3-9337-a140900ba51e	user	273c4535-ef5c-461e-a5fb-d7ad64349ca1	"How do I eat it?"	null	\N	null	null	null	t	null	null	null	1791544621	1791544621
7ffb7379-bfbf-4ac2-88ff-a1b737354a37-56db5164-5b8a-4ce0-afe4-bc9a799b8108	7ffb7379-bfbf-4ac2-88ff-a1b737354a37	6dfcf736-78c9-4eb3-9337-a140900ba51e	assistant	e4009c63-8684-4750-b226-06873a503800	"Try it with lemon."	[{"type": "message", "id": "msg_e16a477411b041b1b60d1ff9", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]	mock-model	null	null	null	t	null	null	null	1791544621	1791544621
41054faf-aff2-47e8-90c7-1a96de739e4d-92699958-1d61-4c48-bdae-94fe57c0624f	41054faf-aff2-47e8-90c7-1a96de739e4d	6dfcf736-78c9-4eb3-9337-a140900ba51e	user	\N	"Where does the lighthouse key hang?"	null	\N	[{"type": "collection", "id": "fd6b412c-7311-4aae-a949-1354be4a4c3d", "name": "Handbook"}]	null	null	t	null	null	null	1791544621	1791544621
41054faf-aff2-47e8-90c7-1a96de739e4d-adca0f18-4388-4c28-9d11-1b782291f164	41054faf-aff2-47e8-90c7-1a96de739e4d	6dfcf736-78c9-4eb3-9337-a140900ba51e	assistant	92699958-1d61-4c48-bdae-94fe57c0624f	"Behind the blue door [1]."	[{"type": "message", "id": "msg_371c09da9cc644d6bc620b25", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Behind the blue door [1]."}]}]	mock-model	null	[{"source": {"type": "collection", "id": "fd6b412c-7311-4aae-a949-1354be4a4c3d", "name": "Handbook"}, "document": ["The upgrade handbook says the lighthouse key hangs behind the blue door."], "metadata": [{"source": "handbook.txt", "name": "handbook.txt", "file_id": "30fbd0fd-4fa6-4f94-939a-6ab0b3e2e48c", "hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "embedding_config": "{'engine': 'openai', 'model': 'sentence-transformers/all-MiniLM-L6-v2'}", "start_index": 0, "created_by": "ec9f46f7-27d8-4045-9852-401ccd233693"}], "distances": [0.9999999403953552]}]	null	t	[{"action": "queries_generated", "queries": ["ok"], "done": false}, {"action": "sources_retrieved", "count": 1, "done": true}]	null	null	1791544621	1791544621
\.


--
-- Data for Name: chatidtag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chatidtag (id, tag_name, chat_id, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config (id, data, version, created_at, updated_at) FROM stdin;
1	{"version": 0, "ui": {"enable_signup": false, "default_user_role": "user", "default_group_id": "", "enable_community_sharing": false, "enable_message_rating": true, "enable_user_webhooks": false, "pending_user_overlay_title": "", "pending_user_overlay_content": "", "watermark": "", "banners": [{"id": "upgrade-banner", "type": "info", "title": "Maintenance", "content": "Maintenance on Sunday", "dismissible": true, "timestamp": 1700000000}]}, "auth": {"admin": {"show": true, "email": null}, "enable_api_keys": false, "api_key": {"endpoint_restrictions": false, "allowed_endpoints": ""}, "jwt_expiry": "4w"}, "webui": {"url": "https://chat.example.com"}, "folders": {"enable": true, "max_file_count": ""}, "automations": {"max_count": "", "min_interval": "", "enable": true}, "channels": {"enable": true}, "calendar": {"enable": true}, "memories": {"enable": true}, "notes": {"enable": true}, "users": {"enable_status": true}, "user": {"permissions": {"workspace": {"models": false, "knowledge": false, "prompts": true, "tools": false, "skills": true, "models_import": false, "models_export": false, "prompts_import": false, "prompts_export": false, "tools_import": false, "tools_export": false}, "sharing": {"models": false, "public_models": false, "knowledge": false, "public_knowledge": false, "prompts": false, "public_prompts": false, "tools": false, "public_tools": false, "skills": false, "public_skills": false, "notes": false, "public_notes": false, "public_chats": false, "public_calendars": false}, "access_grants": {"allow_users": true}, "chat": {"controls": true, "valves": true, "system_prompt": true, "params": true, "file_upload": true, "web_upload": true, "delete": false, "delete_message": true, "continue_response": true, "regenerate_response": true, "rate_response": true, "edit": true, "share": true, "export": true, "stt": true, "tts": true, "call": true, "multiple_models": true, "temporary": true, "temporary_enforced": false}, "features": {"api_keys": false, "notes": true, "channels": true, "folders": true, "direct_tool_servers": false, "web_search": true, "image_generation": true, "code_interpreter": true, "memories": true, "automations": false, "calendar": true}, "settings": {"interface": true}}}}	0	2026-10-09 13:16:58.177196	2026-10-09 13:16:58.969355
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (collection_name, name, title, filename, content, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, user_id, version, type, data, meta, snapshot, created_at, updated_at) FROM stdin;
145a121e-f741-4699-a711-a154488f91b8	6dfcf736-78c9-4eb3-9337-a140900ba51e	0	rating	{"rating": 1, "model_id": "mock-model", "sibling_model_ids": null, "reason": "Accurate", "comment": null}	{"chat_id": "7ffb7379-bfbf-4ac2-88ff-a1b737354a37", "message_id": "273c4535-ef5c-461e-a5fb-d7ad64349ca1"}	{"chat": {}}	1791544621	1791544621
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, user_id, filename, meta, created_at, hash, data, updated_at, path) FROM stdin;
30fbd0fd-4fa6-4f94-939a-6ab0b3e2e48c	ec9f46f7-27d8-4045-9852-401ccd233693	handbook.txt	{"name": "handbook.txt", "content_type": "text/plain", "size": 72, "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "data": {}, "collection_name": "fd6b412c-7311-4aae-a949-1354be4a4c3d"}	1791544620	51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb	{"status": "completed", "content": "The upgrade handbook says the lighthouse key hangs behind the blue door."}	1791544620	/tmp/seed-v0.9.6-postgres/data/uploads/30fbd0fd-4fa6-4f94-939a-6ab0b3e2e48c_handbook.txt
66eab207-aa7c-48dc-9dde-c6e38b39579d	6dfcf736-78c9-4eb3-9337-a140900ba51e	packing.txt	{"name": "packing.txt", "content_type": "text/plain", "size": 59, "file_hash": "85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a", "data": {}, "collection_name": "file-66eab207-aa7c-48dc-9dde-c6e38b39579d"}	1791544621	85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a	{"status": "completed", "content": "Packing list: umbrella, passport, a very old map of Vienna."}	1791544621	/tmp/seed-v0.9.6-postgres/data/uploads/66eab207-aa7c-48dc-9dde-c6e38b39579d_packing.txt
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder (id, parent_id, user_id, name, items, meta, is_expanded, created_at, updated_at, data) FROM stdin;
2855bbd0-7512-4b8e-9167-27ec033a5d7b	\N	6dfcf736-78c9-4eb3-9337-a140900ba51e	Trips	null	null	f	1791544621	1791544621	null
da4010cd-9bec-49bd-882e-e3871a503783	2855bbd0-7512-4b8e-9167-27ec033a5d7b	6dfcf736-78c9-4eb3-9337-a140900ba51e	Vienna	null	null	f	1791544621	1791544621	null
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function (id, user_id, name, type, content, meta, valves, is_active, is_global, updated_at, created_at) FROM stdin;
shout_filter	ec9f46f7-27d8-4045-9852-401ccd233693	Shout filter	filter	"""\ntitle: Shout filter\n"""\n\nfrom pydantic import BaseModel\n\n\nclass Filter:\n    class Valves(BaseModel):\n        suffix: str = "!"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def inlet(self, body: dict) -> dict:\n        return body\n	{"description": "Adds emphasis", "manifest": {"title": "Shout filter"}}	{"suffix": "!!!"}	t	t	1791544619	1791544619
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."group" (id, user_id, name, description, data, meta, permissions, created_at, updated_at) FROM stdin;
ddb62723-0ee0-47d8-a31a-34d95be5eb00	ec9f46f7-27d8-4045-9852-401ccd233693	Research	People who read the handbook	{"config": {"share": "members"}}	null	{"workspace": {"models": true}}	1791544618	1791544618
\.


--
-- Data for Name: group_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_member (id, group_id, user_id, created_at, updated_at) FROM stdin;
301183a9-1e09-41d9-92fe-83f16e6070ac	ddb62723-0ee0-47d8-a31a-34d95be5eb00	6dfcf736-78c9-4eb3-9337-a140900ba51e	1791544618	1791544618
b05d45b6-326f-4177-ac37-e7c465c17294	ddb62723-0ee0-47d8-a31a-34d95be5eb00	7f83f8e8-8d3d-4bb0-bd78-c481993db872	1791544618	1791544618
\.


--
-- Data for Name: knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge (id, user_id, name, description, meta, created_at, updated_at, data) FROM stdin;
fd6b412c-7311-4aae-a949-1354be4a4c3d	ec9f46f7-27d8-4045-9852-401ccd233693	Handbook	Where things are	null	1791544620	1791544620	\N
\.


--
-- Data for Name: knowledge_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_directory (id, knowledge_id, parent_id, name, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_file (id, user_id, knowledge_id, file_id, created_at, updated_at, directory_id) FROM stdin;
c968fbbe-60c5-428b-a368-c5759e715062	ec9f46f7-27d8-4045-9852-401ccd233693	fd6b412c-7311-4aae-a949-1354be4a4c3d	30fbd0fd-4fa6-4f94-939a-6ab0b3e2e48c	1791544620	1791544620	\N
\.


--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.memory (id, user_id, content, updated_at, created_at) FROM stdin;
83190bfe-f79c-4702-9ddf-dbbf2ddc3068	6dfcf736-78c9-4eb3-9337-a140900ba51e	Alice is allergic to peanuts.	1791544621	1791544621
77f3c8f7-d095-47b4-8b70-a18be62f997c	6dfcf736-78c9-4eb3-9337-a140900ba51e	Alice prefers window seats.	1791544621	1791544621
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (id, user_id, channel_id, content, data, meta, created_at, updated_at, parent_id, reply_to_id, is_pinned, pinned_at, pinned_by) FROM stdin;
c8991e9e-95ad-46be-ab0a-b1ed3a279be2	6dfcf736-78c9-4eb3-9337-a140900ba51e	e1d8d956-6dc7-478a-98e5-e1f04259bb37	Who has the lighthouse key?	null	null	1791544621948913841	1791544621948913841	\N	\N	f	\N	\N
ead3209a-e656-4f0c-8cd8-b45e172880a0	7f83f8e8-8d3d-4bb0-bd78-c481993db872	e1d8d956-6dc7-478a-98e5-e1f04259bb37	Behind the blue door.	null	null	1791544622009836646	1791544622009836646	c8991e9e-95ad-46be-ab0a-b1ed3a279be2	\N	f	\N	\N
\.


--
-- Data for Name: message_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reaction (id, user_id, message_id, name, created_at) FROM stdin;
8c7f43e5-9154-4972-a8c9-00db247930a7	7f83f8e8-8d3d-4bb0-bd78-c481993db872	c8991e9e-95ad-46be-ab0a-b1ed3a279be2	thumbsup	1791544622084364662
\.


--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model (id, user_id, base_model_id, name, params, meta, updated_at, created_at, is_active) FROM stdin;
research-assistant	ec9f46f7-27d8-4045-9852-401ccd233693	mock-model	Research assistant	{"system": "You answer from the handbook.", "temperature": 0.2}	{"profile_image_url": null, "description": "Answers from the handbook", "capabilities": null}	1791544619	1791544619	t
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (id, user_id, title, data, meta, created_at, updated_at) FROM stdin;
4ed5d13d-63b3-4068-8c03-9b8571a4cada	6dfcf736-78c9-4eb3-9337-a140900ba51e	Groceries	{"content": {"md": "# Groceries\\n\\n- apples\\n- *dark* chocolate", "html": "", "json": null}}	null	1791544621825921375	1791544621825922126
\.


--
-- Data for Name: oauth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_session (id, user_id, provider, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pinned_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_note (id, user_id, note_id, created_at) FROM stdin;
\.


--
-- Data for Name: prompt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt (id, command, user_id, name, content, data, meta, is_active, version_id, tags, created_at, updated_at) FROM stdin;
6edc1edf-1c5d-49fa-8338-75af16973647	summarize	ec9f46f7-27d8-4045-9852-401ccd233693	Summarize	Summarize the following text in three bullet points.	{}	{}	t	c6a2ae21-c351-4de8-9287-2beb34cc462f	[]	1791544619	1791544619
49a2d30b-ca44-459a-8de9-3dc045bfdff1	alice-draft	6dfcf736-78c9-4eb3-9337-a140900ba51e	Alice's draft	Draft a polite reply to this email.	{}	{}	t	1ae0ecb7-9b4f-4dcd-961d-4bf263e445aa	[]	1791544619	1791544619
\.


--
-- Data for Name: prompt_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt_history (id, prompt_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
c6a2ae21-c351-4de8-9287-2beb34cc462f	6edc1edf-1c5d-49fa-8338-75af16973647	\N	{"name": "Summarize", "content": "Summarize the following text in three bullet points.", "command": "summarize", "data": {}, "meta": {}, "tags": [], "access_grants": [{"id": "38af3862-1137-4088-9354-f38bebe414f9", "resource_type": "prompt", "resource_id": "6edc1edf-1c5d-49fa-8338-75af16973647", "principal_type": "group", "principal_id": "ddb62723-0ee0-47d8-a31a-34d95be5eb00", "permission": "read", "created_at": 1791544619}]}	ec9f46f7-27d8-4045-9852-401ccd233693	Initial version	1791544619
1ae0ecb7-9b4f-4dcd-961d-4bf263e445aa	49a2d30b-ca44-459a-8de9-3dc045bfdff1	\N	{"name": "Alice's draft", "content": "Draft a polite reply to this email.", "command": "alice-draft", "data": {}, "meta": {}, "tags": [], "access_grants": []}	6dfcf736-78c9-4eb3-9337-a140900ba51e	Initial version	1791544619
\.


--
-- Data for Name: shared_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shared_chat (id, chat_id, user_id, title, chat, created_at, updated_at) FROM stdin;
0bac0bb0-67e3-4392-8933-41f38c454cf8	eda3ec1f-88cb-4e8e-950c-3111558698a0	6dfcf736-78c9-4eb3-9337-a140900ba51e	Packing for Vienna	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "66eab207-aa7c-48dc-9dde-c6e38b39579d", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1791544621, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1791544622}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1791544623}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1791544624, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1791544625}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "66eab207-aa7c-48dc-9dde-c6e38b39579d", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1791544621, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1791544623}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1791544624, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1791544625}], "files": [{"type": "file", "id": "66eab207-aa7c-48dc-9dde-c6e38b39579d", "name": "packing.txt", "status": "uploaded"}], "params": {}}	1791544621	1791544621
\.


--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill (id, user_id, name, description, content, meta, is_active, updated_at, created_at) FROM stdin;
trip-planner	6dfcf736-78c9-4eb3-9337-a140900ba51e	Trip planner	Plans multi-city trips by train.	---\nname: trip-planner\ndescription: Plans multi-city trips by train.\n---\n\n# Trip planner\n\n1. Ask for the cities and the dates.\n2. Prefer night trains over flights.\n3. Keep every transfer above 40 minutes.\n4. Name the platform for every departure.\n	{"tags": ["travel"]}	t	1791544620	1791544619
uebersetzer	6dfcf736-78c9-4eb3-9337-a140900ba51e	Übersetzer 日本語 🚀		# Übersetzer 🌍\r\n\r\nÜbersetze höflich: «Grüß Gott» → 「こんにちは」, 你好, Привет, مرحبا, שלום.\r\n\tKeep combining marks (é, ñ) and emoji with modifiers (👋🏽).  \r\nMath stays: ∑ x² ≤ ∞; quotes stay: ‘single’ “double” `<$PATH>`.\r\n	{"tags": []}	t	1791544620	1791544620
old-habits	7f83f8e8-8d3d-4bb0-bd78-c481993db872	Old habits	\N	Answer in Latin.	{"tags": []}	f	1791544620	1791544620
house-style	ec9f46f7-27d8-4045-9852-401ccd233693	House style	How every answer is formatted.	Use sentence case headings and no exclamation marks.	{"tags": []}	t	1791544620	1791544620
dave-notes	edc24529-061e-48c8-8c2d-a8441c1322a9	Dave's notes	Left behind.	Hand over to the next shift at six.	{"tags": []}	t	1791544620	1791544620
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tag (id, name, user_id, meta) FROM stdin;
travel	travel	6dfcf736-78c9-4eb3-9337-a140900ba51e	\N
\.


--
-- Data for Name: tool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool (id, user_id, name, content, specs, meta, valves, updated_at, created_at) FROM stdin;
weather_tool	ec9f46f7-27d8-4045-9852-401ccd233693	Weather	"""\ntitle: Weather\n"""\n\n\nfrom pydantic import BaseModel\n\n\nclass Tools:\n    class Valves(BaseModel):\n        units: str = "metric"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def get_weather(self, city: str) -> str:\n        """Report the weather in a city."""\n        return f"Sunny in {city}"\n	[{"name": "get_weather", "description": "Report the weather in a city.", "parameters": {"properties": {"city": {"type": "string"}}, "required": ["city"], "type": "object"}}]	{"description": "Weather lookups", "manifest": {"title": "Weather"}}	\N	1791544619	1791544619
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, role, profile_image_url, last_active_at, updated_at, created_at, settings, info, username, bio, gender, date_of_birth, profile_banner_image_url, timezone, presence_state, status_emoji, status_message, status_expires_at, oauth, scim) FROM stdin;
811ec59c-ea87-4b95-b27e-b39b9c1a48cd	Carol Outsider	carol@example.com	user	/user.png	1791544618	1791544618	1791544618	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
ec9f46f7-27d8-4045-9852-401ccd233693	Ada Admin	admin@example.com	admin	/user.png	1791544621	1791544618	1791544618	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
6dfcf736-78c9-4eb3-9337-a140900ba51e	Alice Author	alice@example.com	user	/user.png	1791544621	1791544618	1791544618	{"ui": {"theme": "dark", "chatBubble": false, "notesSeen": 3}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
7f83f8e8-8d3d-4bb0-bd78-c481993db872	Bob Reader	bob@example.com	user	/user.png	1791544622	1791544618	1791544618	{"ui": {"models": ["research-assistant"]}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
\.


--
-- Name: config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_id_seq', 1, true);


--
-- Name: access_grant access_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT access_grant_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_key UNIQUE (key);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: automation automation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation
    ADD CONSTRAINT automation_pkey PRIMARY KEY (id);


--
-- Name: automation_run automation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_run
    ADD CONSTRAINT automation_run_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendee calendar_event_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT calendar_event_attendee_pkey PRIMARY KEY (id);


--
-- Name: calendar_event calendar_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event
    ADD CONSTRAINT calendar_event_pkey PRIMARY KEY (id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (id);


--
-- Name: channel_file channel_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_pkey PRIMARY KEY (id);


--
-- Name: channel_member channel_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT channel_member_pkey PRIMARY KEY (id);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_webhook channel_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_pkey PRIMARY KEY (id);


--
-- Name: chat_file chat_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: chat chat_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_share_id_key UNIQUE (share_id);


--
-- Name: chatidtag chatidtag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chatidtag
    ADD CONSTRAINT chatidtag_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: document document_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_name_key UNIQUE (name);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (collection_name);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id, user_id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: group_member group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_pkey PRIMARY KEY (id);


--
-- Name: group group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pkey PRIMARY KEY (id);


--
-- Name: knowledge_directory knowledge_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_pkey PRIMARY KEY (id);


--
-- Name: knowledge_file knowledge_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_pkey PRIMARY KEY (id);


--
-- Name: knowledge knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge
    ADD CONSTRAINT knowledge_pkey PRIMARY KEY (id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: message_reaction message_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reaction
    ADD CONSTRAINT message_reaction_pkey PRIMARY KEY (id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: oauth_session oauth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_pkey PRIMARY KEY (id);


--
-- Name: pinned_note pinned_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_pkey PRIMARY KEY (id);


--
-- Name: tag pk_id_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_id_user_id PRIMARY KEY (id, user_id);


--
-- Name: prompt_history prompt_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt_history
    ADD CONSTRAINT prompt_history_pkey PRIMARY KEY (id);


--
-- Name: prompt prompt_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt
    ADD CONSTRAINT prompt_new_pkey PRIMARY KEY (id);


--
-- Name: shared_chat shared_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_pkey PRIMARY KEY (id);


--
-- Name: skill skill_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_name_key UNIQUE (name);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- Name: tool tool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool
    ADD CONSTRAINT tool_pkey PRIMARY KEY (id);


--
-- Name: access_grant uq_access_grant_grant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT uq_access_grant_grant UNIQUE (resource_type, resource_id, principal_type, principal_id, permission);


--
-- Name: channel_file uq_channel_file_channel_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT uq_channel_file_channel_file UNIQUE (channel_id, file_id);


--
-- Name: chat_file uq_chat_file_chat_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT uq_chat_file_chat_file UNIQUE (chat_id, file_id);


--
-- Name: calendar_event_attendee uq_event_attendee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT uq_event_attendee UNIQUE (event_id, user_id);


--
-- Name: group_member uq_group_member_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT uq_group_member_group_user UNIQUE (group_id, user_id);


--
-- Name: knowledge_directory uq_knowledge_directory_knowledge_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT uq_knowledge_directory_knowledge_parent_name UNIQUE (knowledge_id, parent_id, name);


--
-- Name: knowledge_file uq_knowledge_file_knowledge_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT uq_knowledge_file_knowledge_file UNIQUE (knowledge_id, file_id);


--
-- Name: pinned_note uq_pinned_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT uq_pinned_note UNIQUE (user_id, note_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: chat_message_chat_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_parent_idx ON public.chat_message USING btree (chat_id, parent_id);


--
-- Name: chat_message_model_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_model_created_idx ON public.chat_message USING btree (model_id, created_at);


--
-- Name: chat_message_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_user_created_idx ON public.chat_message USING btree (user_id, created_at);


--
-- Name: folder_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_idx ON public.chat USING btree (folder_id);


--
-- Name: folder_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_user_id_idx ON public.chat USING btree (folder_id, user_id);


--
-- Name: idx_access_grant_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_principal ON public.access_grant USING btree (principal_type, principal_id);


--
-- Name: idx_access_grant_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_resource ON public.access_grant USING btree (resource_type, resource_id);


--
-- Name: idx_oauth_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_expires_at ON public.oauth_session USING btree (expires_at);


--
-- Name: idx_oauth_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_id ON public.oauth_session USING btree (user_id);


--
-- Name: idx_oauth_session_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_provider ON public.oauth_session USING btree (user_id, provider);


--
-- Name: idx_skill_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_updated_at ON public.skill USING btree (updated_at);


--
-- Name: idx_skill_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_user_id ON public.skill USING btree (user_id);


--
-- Name: is_global_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX is_global_idx ON public.function USING btree (is_global);


--
-- Name: ix_automation_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_next_run ON public.automation USING btree (next_run_at);


--
-- Name: ix_automation_run_automation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_run_automation_id ON public.automation_run USING btree (automation_id);


--
-- Name: ix_calendar_event_attendee_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_attendee_user ON public.calendar_event_attendee USING btree (user_id, status);


--
-- Name: ix_calendar_event_calendar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_calendar ON public.calendar_event USING btree (calendar_id, start_at);


--
-- Name: ix_calendar_event_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_user_date ON public.calendar_event USING btree (user_id, start_at);


--
-- Name: ix_calendar_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_user ON public.calendar USING btree (user_id);


--
-- Name: ix_channel_file_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_channel_id ON public.channel_file USING btree (channel_id);


--
-- Name: ix_channel_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_file_id ON public.channel_file USING btree (file_id);


--
-- Name: ix_channel_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_user_id ON public.channel_file USING btree (user_id);


--
-- Name: ix_chat_file_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_chat_id ON public.chat_file USING btree (chat_id);


--
-- Name: ix_chat_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_file_id ON public.chat_file USING btree (file_id);


--
-- Name: ix_chat_file_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_message_id ON public.chat_file USING btree (message_id);


--
-- Name: ix_chat_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_user_id ON public.chat_file USING btree (user_id);


--
-- Name: ix_chat_message_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_chat_id ON public.chat_message USING btree (chat_id);


--
-- Name: ix_chat_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_created_at ON public.chat_message USING btree (created_at);


--
-- Name: ix_chat_message_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_model_id ON public.chat_message USING btree (model_id);


--
-- Name: ix_chat_message_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_user_id ON public.chat_message USING btree (user_id);


--
-- Name: ix_knowledge_directory_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_knowledge_id ON public.knowledge_directory USING btree (knowledge_id);


--
-- Name: ix_knowledge_directory_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_parent_id ON public.knowledge_directory USING btree (parent_id);


--
-- Name: ix_knowledge_file_directory_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_directory_id ON public.knowledge_file USING btree (directory_id);


--
-- Name: ix_knowledge_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_file_id ON public.knowledge_file USING btree (file_id);


--
-- Name: ix_knowledge_file_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_knowledge_id ON public.knowledge_file USING btree (knowledge_id);


--
-- Name: ix_knowledge_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_user_id ON public.knowledge_file USING btree (user_id);


--
-- Name: ix_memory_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_user_id ON public.memory USING btree (user_id);


--
-- Name: ix_prompt_history_prompt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompt_history_prompt_id ON public.prompt_history USING btree (prompt_id);


--
-- Name: ix_prompt_new_command; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_prompt_new_command ON public.prompt USING btree (command);


--
-- Name: updated_at_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX updated_at_user_id_idx ON public.chat USING btree (updated_at, user_id);


--
-- Name: user_id_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_archived_idx ON public.chat USING btree (user_id, archived);


--
-- Name: user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_idx ON public.tag USING btree (user_id);


--
-- Name: user_id_pinned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_pinned_idx ON public.chat USING btree (user_id, pinned);


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: channel_webhook channel_webhook_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: chat_message chat_message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: channel_file fk_channel_file_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT fk_channel_file_message_id FOREIGN KEY (message_id) REFERENCES public.message(id) ON DELETE CASCADE;


--
-- Name: knowledge_file fk_knowledge_file_directory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT fk_knowledge_file_directory_id FOREIGN KEY (directory_id) REFERENCES public.knowledge_directory(id) ON DELETE SET NULL;


--
-- Name: group_member group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: group_member group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_directory(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: oauth_session oauth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: pinned_note pinned_note_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id) ON DELETE CASCADE;


--
-- Name: shared_chat shared_chat_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

