--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: access_grant; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.access_grant (
    id text NOT NULL,
    resource_type text NOT NULL,
    resource_id text NOT NULL,
    principal_type text NOT NULL,
    principal_id text NOT NULL,
    permission text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


--
-- Name: api_key; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_key (
    id text NOT NULL,
    user_id text,
    key text NOT NULL,
    data json,
    expires_at bigint,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: auth; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth (
    id character varying NOT NULL,
    email character varying,
    password text,
    active boolean
);


--
-- Name: automation; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    data json NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    last_run_at bigint,
    next_run_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: automation_run; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_run (
    id text NOT NULL,
    automation_id text NOT NULL,
    chat_id text,
    status text NOT NULL,
    error text,
    created_at bigint NOT NULL
);


--
-- Name: calendar; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    color text,
    is_default boolean NOT NULL,
    data json,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event (
    id text NOT NULL,
    calendar_id text NOT NULL,
    user_id text NOT NULL,
    title text NOT NULL,
    description text,
    start_at bigint NOT NULL,
    end_at bigint,
    all_day boolean NOT NULL,
    rrule text,
    color text,
    location text,
    data json,
    meta json,
    is_cancelled boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: calendar_event_attendee; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_event_attendee (
    id text NOT NULL,
    event_id text NOT NULL,
    user_id text NOT NULL,
    status text NOT NULL,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: channel; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    type text,
    is_private boolean,
    archived_at bigint,
    archived_by text,
    deleted_at bigint,
    deleted_by text,
    updated_by text
);


--
-- Name: channel_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_file (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    message_id text
);


--
-- Name: channel_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_member (
    id text NOT NULL,
    channel_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    status text,
    is_active boolean DEFAULT true NOT NULL,
    is_channel_muted boolean DEFAULT false NOT NULL,
    is_channel_pinned boolean DEFAULT false NOT NULL,
    data json,
    meta json,
    joined_at bigint NOT NULL,
    left_at bigint,
    last_read_at bigint,
    updated_at bigint,
    role text,
    invited_by text,
    invited_at bigint
);


--
-- Name: channel_webhook; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.channel_webhook (
    id text NOT NULL,
    user_id text NOT NULL,
    channel_id text NOT NULL,
    name text NOT NULL,
    profile_image_url text,
    token text NOT NULL,
    last_used_at bigint,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat (
    id character varying NOT NULL,
    user_id character varying,
    title text,
    old_chat text,
    created_at bigint,
    updated_at bigint,
    share_id text,
    archived boolean,
    chat json,
    pinned boolean,
    meta json DEFAULT '{}'::json NOT NULL,
    folder_id text,
    tasks json,
    summary text,
    last_read_at bigint
);


--
-- Name: chat_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_file (
    id text NOT NULL,
    user_id text NOT NULL,
    chat_id text NOT NULL,
    file_id text NOT NULL,
    message_id text,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: chat_message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_message (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text,
    role text NOT NULL,
    parent_id text,
    content json,
    output json,
    model_id text,
    files json,
    sources json,
    embeds json,
    done boolean,
    status_history json,
    error json,
    usage json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: chatidtag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chatidtag (
    id character varying NOT NULL,
    tag_name character varying,
    chat_id character varying,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config (
    id integer NOT NULL,
    data json NOT NULL,
    version integer NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: config_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_id_seq OWNED BY public.config.id;


--
-- Name: document; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document (
    collection_name character varying NOT NULL,
    name character varying,
    title text,
    filename text,
    content text,
    user_id character varying,
    "timestamp" bigint
);


--
-- Name: feedback; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feedback (
    id text NOT NULL,
    user_id text,
    version bigint,
    type text,
    data json,
    meta json,
    snapshot json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.file (
    id character varying NOT NULL,
    user_id character varying,
    filename text,
    meta json,
    created_at bigint,
    hash text,
    data json,
    updated_at bigint,
    path text
);


--
-- Name: folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.folder (
    id text NOT NULL,
    parent_id text,
    user_id text NOT NULL,
    name text NOT NULL,
    items json,
    meta json,
    is_expanded boolean NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    data json
);


--
-- Name: function; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.function (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    type text,
    content text,
    meta text,
    valves text,
    is_active boolean,
    is_global boolean,
    updated_at bigint,
    created_at bigint
);


--
-- Name: group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."group" (
    id text NOT NULL,
    user_id text,
    name text,
    description text,
    data json,
    meta json,
    permissions json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: group_member; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.group_member (
    id text NOT NULL,
    group_id text NOT NULL,
    user_id text NOT NULL,
    created_at bigint,
    updated_at bigint
);


--
-- Name: knowledge; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge (
    id text NOT NULL,
    user_id text NOT NULL,
    name text NOT NULL,
    description text,
    meta json,
    created_at bigint NOT NULL,
    updated_at bigint,
    data json
);


--
-- Name: knowledge_directory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_directory (
    id text NOT NULL,
    knowledge_id text NOT NULL,
    parent_id text,
    name text NOT NULL,
    user_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: knowledge_file; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knowledge_file (
    id text NOT NULL,
    user_id text NOT NULL,
    knowledge_id text NOT NULL,
    file_id text NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL,
    directory_id text
);


--
-- Name: memory; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.memory (
    id character varying NOT NULL,
    user_id character varying,
    content text,
    updated_at bigint,
    created_at bigint
);


--
-- Name: message; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message (
    id text NOT NULL,
    user_id text,
    channel_id text,
    content text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint,
    parent_id text,
    reply_to_id text,
    is_pinned boolean DEFAULT false NOT NULL,
    pinned_at bigint,
    pinned_by text
);


--
-- Name: message_reaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.message_reaction (
    id text NOT NULL,
    user_id text NOT NULL,
    message_id text NOT NULL,
    name text NOT NULL,
    created_at bigint
);


--
-- Name: model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model (
    id text NOT NULL,
    user_id text,
    base_model_id text,
    name text,
    params text,
    meta text,
    updated_at bigint,
    created_at bigint,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.note (
    id text NOT NULL,
    user_id text,
    title text,
    data json,
    meta json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: oauth_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oauth_session (
    id text NOT NULL,
    user_id text NOT NULL,
    provider text NOT NULL,
    token text NOT NULL,
    expires_at bigint NOT NULL,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: pinned_note; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pinned_note (
    id text NOT NULL,
    user_id text NOT NULL,
    note_id text NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: prompt; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt (
    id text NOT NULL,
    command character varying,
    user_id character varying NOT NULL,
    name text NOT NULL,
    content text NOT NULL,
    data json,
    meta json,
    is_active boolean DEFAULT true NOT NULL,
    version_id text,
    tags json,
    created_at bigint NOT NULL,
    updated_at bigint NOT NULL
);


--
-- Name: prompt_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prompt_history (
    id text NOT NULL,
    prompt_id text NOT NULL,
    parent_id text,
    snapshot json NOT NULL,
    user_id text NOT NULL,
    commit_message text,
    created_at bigint NOT NULL
);


--
-- Name: shared_chat; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.shared_chat (
    id text NOT NULL,
    chat_id text NOT NULL,
    user_id text NOT NULL,
    title text,
    chat json,
    created_at bigint,
    updated_at bigint
);


--
-- Name: skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skill (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    content text NOT NULL,
    meta json,
    is_active boolean NOT NULL,
    updated_at bigint NOT NULL,
    created_at bigint NOT NULL
);


--
-- Name: tag; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tag (
    id character varying NOT NULL,
    name character varying,
    user_id character varying NOT NULL,
    meta json
);


--
-- Name: tool; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tool (
    id character varying NOT NULL,
    user_id character varying,
    name text,
    content text,
    specs text,
    meta text,
    valves text,
    updated_at bigint,
    created_at bigint
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."user" (
    id character varying NOT NULL,
    name character varying,
    email character varying,
    role character varying,
    profile_image_url text,
    last_active_at bigint,
    updated_at bigint,
    created_at bigint,
    settings json,
    info json,
    username character varying(50),
    bio text,
    gender text,
    date_of_birth date,
    profile_banner_image_url text,
    timezone character varying,
    presence_state character varying,
    status_emoji character varying,
    status_message text,
    status_expires_at bigint,
    oauth json,
    scim json
);


--
-- Name: config id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config ALTER COLUMN id SET DEFAULT nextval('public.config_id_seq'::regclass);


--
-- Data for Name: access_grant; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.access_grant (id, resource_type, resource_id, principal_type, principal_id, permission, created_at) FROM stdin;
830bd361-cd7c-44de-9207-90d2310df724	prompt	3119396b-56e2-40dc-bbb6-13b9c1e0e6a4	group	1f603e34-3a4a-447f-b970-457597c2b231	read	1790362428
c2bd097e-3ee9-4513-92aa-8955fd48a65c	tool	weather_tool	group	1f603e34-3a4a-447f-b970-457597c2b231	read	1790362428
9f38d14b-4e52-4382-b084-70ce40d3a2e0	model	research-assistant	user	baaff868-81c5-4188-b2cc-06e39e16513b	read	1790362428
7067b6f0-dfaa-47d9-b6a1-8748c904306e	knowledge	981ceb99-1193-4d46-8fd9-232c50395191	group	1f603e34-3a4a-447f-b970-457597c2b231	read	1790362428
fe4f7e07-eee3-48bd-b986-8b168cbed9e9	shared_chat	a84c76ce-61a4-4571-be5b-983391d3cbed	user	baaff868-81c5-4188-b2cc-06e39e16513b	read	1790362428
5a9d6fcc-9efe-4fb1-a1b0-a01b5a801cd8	note	f2c8637d-3934-4f29-98b4-b97f4a80f520	user	baaff868-81c5-4188-b2cc-06e39e16513b	read	1790362429
e077685f-ba99-4ceb-9853-71050125910a	note	f2c8637d-3934-4f29-98b4-b97f4a80f520	user	baaff868-81c5-4188-b2cc-06e39e16513b	write	1790362429
db68e055-953b-45de-a110-2514935b0d29	channel	241fa008-c9b3-4817-8e92-8813dffca12e	group	1f603e34-3a4a-447f-b970-457597c2b231	read	1790362429
d4ca3bf6-26f0-4939-8610-f4e2ee26178a	channel	241fa008-c9b3-4817-8e92-8813dffca12e	group	1f603e34-3a4a-447f-b970-457597c2b231	write	1790362429
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alembic_version (version_num) FROM stdin;
461111b60977
\.


--
-- Data for Name: api_key; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_key (id, user_id, key, data, expires_at, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: auth; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth (id, email, password, active) FROM stdin;
80d80055-1e5a-45cb-8f31-f19fddaa5d24	admin@example.com	$2b$12$teqJufBkvYJpH24s/nV8MeJU.draDXknvjehGKJk9iIRgbCxWu4z.	t
5d51d5a0-be36-48fb-92e3-07976995874f	alice@example.com	$2b$12$FIyWUD/FXAynYoSQIXZxIecC39LzZwGbVDY3pFV5ibIVIOWMUYoEa	t
baaff868-81c5-4188-b2cc-06e39e16513b	bob@example.com	$2b$12$aYrVcwM5mV9czzbf.SsQKuGNxkhwk4yl7WoYdVvVhh/NnHG/KGaiS	t
22db8b74-62dc-4b2b-946c-57e41538b2c2	carol@example.com	$2b$12$ro0.4GXd9uvrcnUrqpEL3OxZHqDkCwGQzhxrXa3GSEmhEPjDdozE.	t
\.


--
-- Data for Name: automation; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation (id, user_id, name, data, meta, is_active, last_run_at, next_run_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: automation_run; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_run (id, automation_id, chat_id, status, error, created_at) FROM stdin;
\.


--
-- Data for Name: calendar; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar (id, user_id, name, color, is_default, data, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event (id, calendar_id, user_id, title, description, start_at, end_at, all_day, rrule, color, location, data, meta, is_cancelled, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: calendar_event_attendee; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_event_attendee (id, event_id, user_id, status, meta, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel (id, user_id, name, description, data, meta, created_at, updated_at, type, is_private, archived_at, archived_by, deleted_at, deleted_by, updated_by) FROM stdin;
241fa008-c9b3-4817-8e92-8813dffca12e	80d80055-1e5a-45cb-8f31-f19fddaa5d24	lighthouse	Team chatter	null	null	1790362429108142477	1790362429108142767	\N	\N	\N	\N	\N	\N	\N
\.


--
-- Data for Name: channel_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_file (id, user_id, channel_id, file_id, created_at, updated_at, message_id) FROM stdin;
\.


--
-- Data for Name: channel_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_member (id, channel_id, user_id, created_at, status, is_active, is_channel_muted, is_channel_pinned, data, meta, joined_at, left_at, last_read_at, updated_at, role, invited_by, invited_at) FROM stdin;
1debf056-5b82-4be8-82de-184be7939320	241fa008-c9b3-4817-8e92-8813dffca12e	5d51d5a0-be36-48fb-92e3-07976995874f	1790362429132758595	joined	t	f	f	null	null	1790362429132758274	\N	1790362429132758514	1790362429132758745	\N	\N	\N
7434b93d-b83c-453a-bffb-d0d30f29569b	241fa008-c9b3-4817-8e92-8813dffca12e	baaff868-81c5-4188-b2cc-06e39e16513b	1790362429168394530	joined	t	f	f	null	null	1790362429168393869	\N	1790362429168394370	1790362429168394620	\N	\N	\N
\.


--
-- Data for Name: channel_webhook; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.channel_webhook (id, user_id, channel_id, name, profile_image_url, token, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat (id, user_id, title, old_chat, created_at, updated_at, share_id, archived, chat, pinned, meta, folder_id, tasks, summary, last_read_at) FROM stdin;
a84c76ce-61a4-4571-be5b-983391d3cbed	5d51d5a0-be36-48fb-92e3-07976995874f	Packing for Vienna	\N	1790362428	1790362428	ca570ad3-3b83-4451-9ce7-2fef605938c2	f	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "4627ef5c-7d21-4d4a-9aae-3c1f836c34c4", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1790362428, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1790362429}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1790362430}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1790362431, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1790362432}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "4627ef5c-7d21-4d4a-9aae-3c1f836c34c4", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1790362428, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1790362430}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1790362431, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1790362432}], "files": [{"type": "file", "id": "4627ef5c-7d21-4d4a-9aae-3c1f836c34c4", "name": "packing.txt", "status": "uploaded"}], "params": {}}	t	{"tags": ["travel"]}	b780d0f6-5b0d-479f-9185-27af2930deae	null	\N	\N
759c7ee0-19dc-4f91-996a-3338a0a034a8	5d51d5a0-be36-48fb-92e3-07976995874f	Schnitzel questions	\N	1790362428	1790362429	\N	f	{"id": "759c7ee0-19dc-4f91-996a-3338a0a034a8", "title": "Schnitzel questions", "models": ["mock-model"], "history": {"currentId": "06817110-6b16-42ff-b20c-99e847b8f4bc", "messages": {"b8439b84-3926-4f25-b78d-d90f76ef4291": {"id": "b8439b84-3926-4f25-b78d-d90f76ef4291", "parentId": null, "childrenIds": ["35956b46-13f0-484d-ac88-66b97bf38feb"], "role": "user", "content": "What is a Schnitzel?", "models": ["mock-model"], "timestamp": 1790362428}, "35956b46-13f0-484d-ac88-66b97bf38feb": {"id": "35956b46-13f0-484d-ac88-66b97bf38feb", "parentId": "b8439b84-3926-4f25-b78d-d90f76ef4291", "childrenIds": ["1882472e-ebc4-4d02-a797-ec1bc07f6826"], "role": "assistant", "content": "Schnitzel is a breaded cutlet.", "done": true, "model": "mock-model", "timestamp": 1790362428, "output": [{"type": "message", "id": "msg_3dbe40a98efe4b9ba70b9d87", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]}, "1882472e-ebc4-4d02-a797-ec1bc07f6826": {"id": "1882472e-ebc4-4d02-a797-ec1bc07f6826", "parentId": "35956b46-13f0-484d-ac88-66b97bf38feb", "childrenIds": ["06817110-6b16-42ff-b20c-99e847b8f4bc"], "role": "user", "content": "How do I eat it?", "models": ["mock-model"], "timestamp": 1790362428}, "06817110-6b16-42ff-b20c-99e847b8f4bc": {"id": "06817110-6b16-42ff-b20c-99e847b8f4bc", "parentId": "1882472e-ebc4-4d02-a797-ec1bc07f6826", "childrenIds": [], "role": "assistant", "content": "Try it with lemon.", "done": true, "model": "mock-model", "timestamp": 1790362428, "output": [{"type": "message", "id": "msg_b59b867f81594638b3bb7dd2", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]}}}, "messages": [{"role": "user", "content": "What is a Schnitzel?"}], "files": [], "tags": [], "timestamp": 1790362428732}	f	{}	\N	null	\N	\N
0ecafb5a-95af-4e4c-a7ea-454c022c720c	5d51d5a0-be36-48fb-92e3-07976995874f	Old plans	\N	1790362429	1790362429	\N	t	{"title": "Old plans", "models": ["mock-model"], "history": {}}	f	{}	\N	null	\N	\N
\.


--
-- Data for Name: chat_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_file (id, user_id, chat_id, file_id, message_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chat_message (id, chat_id, user_id, role, parent_id, content, output, model_id, files, sources, embeds, done, status_history, error, usage, created_at, updated_at) FROM stdin;
a84c76ce-61a4-4571-be5b-983391d3cbed-u1-0000-4000-8000-000000000000	a84c76ce-61a4-4571-be5b-983391d3cbed	5d51d5a0-be36-48fb-92e3-07976995874f	user	\N	"What should I pack for Vienna?"	null	\N	[{"type": "file", "id": "4627ef5c-7d21-4d4a-9aae-3c1f836c34c4", "name": "packing.txt", "status": "uploaded"}]	null	null	t	null	null	null	1790362428	1790362428
a84c76ce-61a4-4571-be5b-983391d3cbed-a1-0000-4000-8000-000000000000	a84c76ce-61a4-4571-be5b-983391d3cbed	5d51d5a0-be36-48fb-92e3-07976995874f	assistant	u1-0000-4000-8000-000000000000	"Pack an umbrella."	null	mock-model	null	null	null	t	null	null	null	1790362429	1790362428
a84c76ce-61a4-4571-be5b-983391d3cbed-a1b-0000-4000-8000-000000000000	a84c76ce-61a4-4571-be5b-983391d3cbed	5d51d5a0-be36-48fb-92e3-07976995874f	assistant	u1-0000-4000-8000-000000000000	"<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses."	null	mock-model	null	null	null	t	null	null	null	1790362430	1790362428
a84c76ce-61a4-4571-be5b-983391d3cbed-u2-0000-4000-8000-000000000000	a84c76ce-61a4-4571-be5b-983391d3cbed	5d51d5a0-be36-48fb-92e3-07976995874f	user	a1b-0000-4000-8000-000000000000	"And for the evening?"	null	\N	null	null	null	t	null	null	null	1790362431	1790362428
a84c76ce-61a4-4571-be5b-983391d3cbed-a2-0000-4000-8000-000000000000	a84c76ce-61a4-4571-be5b-983391d3cbed	5d51d5a0-be36-48fb-92e3-07976995874f	assistant	u2-0000-4000-8000-000000000000	"A light jacket."	null	mock-model	null	null	null	t	null	null	null	1790362432	1790362428
759c7ee0-19dc-4f91-996a-3338a0a034a8-b8439b84-3926-4f25-b78d-d90f76ef4291	759c7ee0-19dc-4f91-996a-3338a0a034a8	5d51d5a0-be36-48fb-92e3-07976995874f	user	\N	"What is a Schnitzel?"	null	\N	null	null	null	t	null	null	null	1790362428	1790362429
759c7ee0-19dc-4f91-996a-3338a0a034a8-35956b46-13f0-484d-ac88-66b97bf38feb	759c7ee0-19dc-4f91-996a-3338a0a034a8	5d51d5a0-be36-48fb-92e3-07976995874f	assistant	b8439b84-3926-4f25-b78d-d90f76ef4291	"Schnitzel is a breaded cutlet."	[{"type": "message", "id": "msg_3dbe40a98efe4b9ba70b9d87", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Schnitzel is a breaded cutlet."}]}]	mock-model	null	null	null	t	null	null	null	1790362428	1790362429
759c7ee0-19dc-4f91-996a-3338a0a034a8-1882472e-ebc4-4d02-a797-ec1bc07f6826	759c7ee0-19dc-4f91-996a-3338a0a034a8	5d51d5a0-be36-48fb-92e3-07976995874f	user	35956b46-13f0-484d-ac88-66b97bf38feb	"How do I eat it?"	null	\N	null	null	null	t	null	null	null	1790362428	1790362429
759c7ee0-19dc-4f91-996a-3338a0a034a8-06817110-6b16-42ff-b20c-99e847b8f4bc	759c7ee0-19dc-4f91-996a-3338a0a034a8	5d51d5a0-be36-48fb-92e3-07976995874f	assistant	1882472e-ebc4-4d02-a797-ec1bc07f6826	"Try it with lemon."	[{"type": "message", "id": "msg_b59b867f81594638b3bb7dd2", "status": "completed", "role": "assistant", "content": [{"type": "output_text", "text": "Try it with lemon."}]}]	mock-model	null	null	null	t	null	null	null	1790362428	1790362429
\.


--
-- Data for Name: chatidtag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.chatidtag (id, tag_name, chat_id, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config (id, data, version, created_at, updated_at) FROM stdin;
1	{"version": 0, "ui": {"enable_signup": false, "default_user_role": "user", "default_group_id": "", "enable_community_sharing": false, "enable_message_rating": true, "enable_user_webhooks": false, "pending_user_overlay_title": "", "pending_user_overlay_content": "", "watermark": "", "banners": [{"id": "upgrade-banner", "type": "info", "title": "Maintenance", "content": "Maintenance on Sunday", "dismissible": true, "timestamp": 1700000000}]}, "auth": {"admin": {"show": true, "email": null}, "enable_api_keys": false, "api_key": {"endpoint_restrictions": false, "allowed_endpoints": ""}, "jwt_expiry": "4w"}, "webui": {"url": "https://chat.example.com"}, "folders": {"enable": true, "max_file_count": ""}, "automations": {"max_count": "", "min_interval": "", "enable": true}, "channels": {"enable": true}, "calendar": {"enable": true}, "memories": {"enable": true}, "notes": {"enable": true}, "users": {"enable_status": true}, "user": {"permissions": {"workspace": {"models": false, "knowledge": false, "prompts": true, "tools": false, "skills": false, "models_import": false, "models_export": false, "prompts_import": false, "prompts_export": false, "tools_import": false, "tools_export": false}, "sharing": {"models": false, "public_models": false, "knowledge": false, "public_knowledge": false, "prompts": false, "public_prompts": false, "tools": false, "public_tools": false, "skills": false, "public_skills": false, "notes": false, "public_notes": false, "public_chats": false, "public_calendars": false}, "access_grants": {"allow_users": true}, "chat": {"controls": true, "valves": true, "system_prompt": true, "params": true, "file_upload": true, "web_upload": true, "delete": false, "delete_message": true, "continue_response": true, "regenerate_response": true, "rate_response": true, "edit": true, "share": true, "export": true, "stt": true, "tts": true, "call": true, "multiple_models": true, "temporary": true, "temporary_enforced": false}, "features": {"api_keys": false, "notes": true, "channels": true, "folders": true, "direct_tool_servers": false, "web_search": true, "image_generation": true, "code_interpreter": true, "memories": true, "automations": false, "calendar": true}, "settings": {"interface": true}}}}	0	2026-09-25 20:53:47.624608	2026-09-25 20:53:48.279756
\.


--
-- Data for Name: document; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document (collection_name, name, title, filename, content, user_id, "timestamp") FROM stdin;
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feedback (id, user_id, version, type, data, meta, snapshot, created_at, updated_at) FROM stdin;
ba392966-c877-4e59-982b-3a5f7ab84ee7	5d51d5a0-be36-48fb-92e3-07976995874f	0	rating	{"rating": 1, "model_id": "mock-model", "sibling_model_ids": null, "reason": "Accurate", "comment": null}	{"chat_id": "759c7ee0-19dc-4f91-996a-3338a0a034a8", "message_id": "35956b46-13f0-484d-ac88-66b97bf38feb"}	{"chat": {}}	1790362429	1790362429
\.


--
-- Data for Name: file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.file (id, user_id, filename, meta, created_at, hash, data, updated_at, path) FROM stdin;
501b9d89-52ac-4995-9948-a7ed72a43349	80d80055-1e5a-45cb-8f31-f19fddaa5d24	handbook.txt	{"name": "handbook.txt", "content_type": "text/plain", "size": 72, "file_hash": "51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb", "data": {}, "collection_name": "981ceb99-1193-4d46-8fd9-232c50395191"}	1790362428	51c3976ce123a0979114420392246e723885b4e0a1a38ac58c15a91dc08d4dcb	{"status": "completed", "content": "The upgrade handbook says the lighthouse key hangs behind the blue door."}	1790362428	/tmp/seed-v0.9.6-wu4y83jd/data/uploads/501b9d89-52ac-4995-9948-a7ed72a43349_handbook.txt
4627ef5c-7d21-4d4a-9aae-3c1f836c34c4	5d51d5a0-be36-48fb-92e3-07976995874f	packing.txt	{"name": "packing.txt", "content_type": "text/plain", "size": 59, "file_hash": "85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a", "data": {}, "collection_name": "file-4627ef5c-7d21-4d4a-9aae-3c1f836c34c4"}	1790362428	85bd1dadcb8261f0f2a160958af44237ddb41816bfcea2ae6582ff7066d2af6a	{"status": "completed", "content": "Packing list: umbrella, passport, a very old map of Vienna."}	1790362428	/tmp/seed-v0.9.6-wu4y83jd/data/uploads/4627ef5c-7d21-4d4a-9aae-3c1f836c34c4_packing.txt
\.


--
-- Data for Name: folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.folder (id, parent_id, user_id, name, items, meta, is_expanded, created_at, updated_at, data) FROM stdin;
cf0e2691-9e02-43ca-b36c-f4779a912e1f	\N	5d51d5a0-be36-48fb-92e3-07976995874f	Trips	null	null	f	1790362428	1790362428	null
b780d0f6-5b0d-479f-9185-27af2930deae	cf0e2691-9e02-43ca-b36c-f4779a912e1f	5d51d5a0-be36-48fb-92e3-07976995874f	Vienna	null	null	f	1790362428	1790362428	null
\.


--
-- Data for Name: function; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.function (id, user_id, name, type, content, meta, valves, is_active, is_global, updated_at, created_at) FROM stdin;
shout_filter	80d80055-1e5a-45cb-8f31-f19fddaa5d24	Shout filter	filter	"""\ntitle: Shout filter\n"""\n\nfrom pydantic import BaseModel\n\n\nclass Filter:\n    class Valves(BaseModel):\n        suffix: str = "!"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def inlet(self, body: dict) -> dict:\n        return body\n	{"description": "Adds emphasis", "manifest": {"title": "Shout filter"}}	{"suffix": "!!!"}	t	t	1790362428	1790362428
\.


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."group" (id, user_id, name, description, data, meta, permissions, created_at, updated_at) FROM stdin;
1f603e34-3a4a-447f-b970-457597c2b231	80d80055-1e5a-45cb-8f31-f19fddaa5d24	Research	People who read the handbook	{"config": {"share": "members"}}	null	null	1790362428	1790362428
\.


--
-- Data for Name: group_member; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.group_member (id, group_id, user_id, created_at, updated_at) FROM stdin;
d7806049-9f4b-440e-baec-fa44b8e73362	1f603e34-3a4a-447f-b970-457597c2b231	5d51d5a0-be36-48fb-92e3-07976995874f	1790362428	1790362428
6f6123e5-ee52-4e7d-8b40-b85ecd565792	1f603e34-3a4a-447f-b970-457597c2b231	baaff868-81c5-4188-b2cc-06e39e16513b	1790362428	1790362428
\.


--
-- Data for Name: knowledge; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge (id, user_id, name, description, meta, created_at, updated_at, data) FROM stdin;
981ceb99-1193-4d46-8fd9-232c50395191	80d80055-1e5a-45cb-8f31-f19fddaa5d24	Handbook	Where things are	null	1790362428	1790362428	\N
\.


--
-- Data for Name: knowledge_directory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_directory (id, knowledge_id, parent_id, name, user_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_file; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knowledge_file (id, user_id, knowledge_id, file_id, created_at, updated_at, directory_id) FROM stdin;
5cc9a74d-4685-42b3-8dda-943536fa46d6	80d80055-1e5a-45cb-8f31-f19fddaa5d24	981ceb99-1193-4d46-8fd9-232c50395191	501b9d89-52ac-4995-9948-a7ed72a43349	1790362428	1790362428	\N
\.


--
-- Data for Name: memory; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.memory (id, user_id, content, updated_at, created_at) FROM stdin;
e2964a70-1f6e-409d-b91d-5d3fd17a58ea	5d51d5a0-be36-48fb-92e3-07976995874f	Alice is allergic to peanuts.	1790362429	1790362429
01af7ad6-b2ad-4dfa-b0ef-a45a6f5ef6b1	5d51d5a0-be36-48fb-92e3-07976995874f	Alice prefers window seats.	1790362429	1790362429
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message (id, user_id, channel_id, content, data, meta, created_at, updated_at, parent_id, reply_to_id, is_pinned, pinned_at, pinned_by) FROM stdin;
78e4f78b-2d97-482f-b189-4df71fbcc367	5d51d5a0-be36-48fb-92e3-07976995874f	241fa008-c9b3-4817-8e92-8813dffca12e	Who has the lighthouse key?	null	null	1790362429135507209	1790362429135507209	\N	\N	f	\N	\N
a3fbf447-f483-4897-9fe4-749160565088	baaff868-81c5-4188-b2cc-06e39e16513b	241fa008-c9b3-4817-8e92-8813dffca12e	Behind the blue door.	null	null	1790362429170555121	1790362429170555121	78e4f78b-2d97-482f-b189-4df71fbcc367	\N	f	\N	\N
\.


--
-- Data for Name: message_reaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.message_reaction (id, user_id, message_id, name, created_at) FROM stdin;
17f851ed-7d4d-4eef-be2d-3d5171b15467	baaff868-81c5-4188-b2cc-06e39e16513b	78e4f78b-2d97-482f-b189-4df71fbcc367	thumbsup	1790362429203242300
\.


--
-- Data for Name: model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model (id, user_id, base_model_id, name, params, meta, updated_at, created_at, is_active) FROM stdin;
research-assistant	80d80055-1e5a-45cb-8f31-f19fddaa5d24	mock-model	Research assistant	{"system": "You answer from the handbook.", "temperature": 0.2}	{"profile_image_url": null, "description": "Answers from the handbook", "capabilities": null}	1790362428	1790362428	t
\.


--
-- Data for Name: note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.note (id, user_id, title, data, meta, created_at, updated_at) FROM stdin;
f2c8637d-3934-4f29-98b4-b97f4a80f520	5d51d5a0-be36-48fb-92e3-07976995874f	Groceries	{"content": {"md": "# Groceries\\n\\n- apples\\n- *dark* chocolate", "html": "", "json": null}}	null	1790362429062526819	1790362429062527200
\.


--
-- Data for Name: oauth_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oauth_session (id, user_id, provider, token, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: pinned_note; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pinned_note (id, user_id, note_id, created_at) FROM stdin;
\.


--
-- Data for Name: prompt; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt (id, command, user_id, name, content, data, meta, is_active, version_id, tags, created_at, updated_at) FROM stdin;
3119396b-56e2-40dc-bbb6-13b9c1e0e6a4	summarize	80d80055-1e5a-45cb-8f31-f19fddaa5d24	Summarize	Summarize the following text in three bullet points.	{}	{}	t	b22dfe5c-267e-4ca0-80e9-2b487f440b81	[]	1790362428	1790362428
c8adf87a-b904-4ace-87c3-bd5346ea80c7	alice-draft	5d51d5a0-be36-48fb-92e3-07976995874f	Alice's draft	Draft a polite reply to this email.	{}	{}	t	13de8a46-efe1-477c-8b71-e8eaa7f88a0b	[]	1790362428	1790362428
\.


--
-- Data for Name: prompt_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prompt_history (id, prompt_id, parent_id, snapshot, user_id, commit_message, created_at) FROM stdin;
b22dfe5c-267e-4ca0-80e9-2b487f440b81	3119396b-56e2-40dc-bbb6-13b9c1e0e6a4	\N	{"name": "Summarize", "content": "Summarize the following text in three bullet points.", "command": "summarize", "data": {}, "meta": {}, "tags": [], "access_grants": [{"id": "830bd361-cd7c-44de-9207-90d2310df724", "resource_type": "prompt", "resource_id": "3119396b-56e2-40dc-bbb6-13b9c1e0e6a4", "principal_type": "group", "principal_id": "1f603e34-3a4a-447f-b970-457597c2b231", "permission": "read", "created_at": 1790362428}]}	80d80055-1e5a-45cb-8f31-f19fddaa5d24	Initial version	1790362428
13de8a46-efe1-477c-8b71-e8eaa7f88a0b	c8adf87a-b904-4ace-87c3-bd5346ea80c7	\N	{"name": "Alice's draft", "content": "Draft a polite reply to this email.", "command": "alice-draft", "data": {}, "meta": {}, "tags": [], "access_grants": []}	5d51d5a0-be36-48fb-92e3-07976995874f	Initial version	1790362428
\.


--
-- Data for Name: shared_chat; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.shared_chat (id, chat_id, user_id, title, chat, created_at, updated_at) FROM stdin;
ca570ad3-3b83-4451-9ce7-2fef605938c2	a84c76ce-61a4-4571-be5b-983391d3cbed	5d51d5a0-be36-48fb-92e3-07976995874f	Packing for Vienna	{"title": "Packing for Vienna", "models": ["mock-model"], "history": {"messages": {"u1-0000-4000-8000-000000000000": {"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "4627ef5c-7d21-4d4a-9aae-3c1f836c34c4", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1790362428, "models": ["mock-model"]}, "a1-0000-4000-8000-000000000000": {"id": "a1-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "Pack an umbrella.", "model": "mock-model", "done": true, "timestamp": 1790362429}, "a1b-0000-4000-8000-000000000000": {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1790362430}, "u2-0000-4000-8000-000000000000": {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1790362431, "models": ["mock-model"]}, "a2-0000-4000-8000-000000000000": {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1790362432}}, "currentId": "a2-0000-4000-8000-000000000000"}, "messages": [{"id": "u1-0000-4000-8000-000000000000", "parentId": null, "childrenIds": ["a1-0000-4000-8000-000000000000", "a1b-0000-4000-8000-000000000000"], "role": "user", "content": "What should I pack for Vienna?", "files": [{"type": "file", "id": "4627ef5c-7d21-4d4a-9aae-3c1f836c34c4", "name": "packing.txt", "status": "uploaded"}], "timestamp": 1790362428, "models": ["mock-model"]}, {"id": "a1b-0000-4000-8000-000000000000", "parentId": "u1-0000-4000-8000-000000000000", "childrenIds": ["u2-0000-4000-8000-000000000000"], "role": "assistant", "content": "<details type=\\"tool_calls\\" done=\\"true\\" id=\\"call_1\\" name=\\"get_weather\\" arguments=\\"{&quot;city&quot;: &quot;Vienna&quot;}\\" result=\\"&quot;Sunny in Vienna&quot;\\">\\n<summary>Tool Executed</summary>\\n</details>\\nIt is sunny, so pack sunglasses.", "model": "mock-model", "done": true, "timestamp": 1790362430}, {"id": "u2-0000-4000-8000-000000000000", "parentId": "a1b-0000-4000-8000-000000000000", "childrenIds": ["a2-0000-4000-8000-000000000000"], "role": "user", "content": "And for the evening?", "timestamp": 1790362431, "models": ["mock-model"]}, {"id": "a2-0000-4000-8000-000000000000", "parentId": "u2-0000-4000-8000-000000000000", "childrenIds": [], "role": "assistant", "content": "A light jacket.", "model": "mock-model", "done": true, "timestamp": 1790362432}], "files": [{"type": "file", "id": "4627ef5c-7d21-4d4a-9aae-3c1f836c34c4", "name": "packing.txt", "status": "uploaded"}], "params": {}}	1790362428	1790362428
\.


--
-- Data for Name: skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skill (id, user_id, name, description, content, meta, is_active, updated_at, created_at) FROM stdin;
\.


--
-- Data for Name: tag; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tag (id, name, user_id, meta) FROM stdin;
travel	travel	5d51d5a0-be36-48fb-92e3-07976995874f	\N
\.


--
-- Data for Name: tool; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tool (id, user_id, name, content, specs, meta, valves, updated_at, created_at) FROM stdin;
weather_tool	80d80055-1e5a-45cb-8f31-f19fddaa5d24	Weather	"""\ntitle: Weather\n"""\n\n\nfrom pydantic import BaseModel\n\n\nclass Tools:\n    class Valves(BaseModel):\n        units: str = "metric"\n\n    def __init__(self):\n        self.valves = self.Valves()\n\n    def get_weather(self, city: str) -> str:\n        """Report the weather in a city."""\n        return f"Sunny in {city}"\n	[{"name": "get_weather", "description": "Report the weather in a city.", "parameters": {"properties": {"city": {"type": "string"}}, "required": ["city"], "type": "object"}}]	{"description": "Weather lookups", "manifest": {"title": "Weather"}}	\N	1790362428	1790362428
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."user" (id, name, email, role, profile_image_url, last_active_at, updated_at, created_at, settings, info, username, bio, gender, date_of_birth, profile_banner_image_url, timezone, presence_state, status_emoji, status_message, status_expires_at, oauth, scim) FROM stdin;
22db8b74-62dc-4b2b-946c-57e41538b2c2	Carol Outsider	carol@example.com	user	/user.png	1790362428	1790362428	1790362428	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
80d80055-1e5a-45cb-8f31-f19fddaa5d24	Ada Admin	admin@example.com	admin	/user.png	1790362429	1790362427	1790362427	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
5d51d5a0-be36-48fb-92e3-07976995874f	Alice Author	alice@example.com	user	/user.png	1790362429	1790362427	1790362427	{"ui": {"theme": "dark", "chatBubble": false, "notesSeen": 3}}	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
baaff868-81c5-4188-b2cc-06e39e16513b	Bob Reader	bob@example.com	user	/user.png	1790362429	1790362427	1790362427	null	null	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	null	null
\.


--
-- Name: config_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_id_seq', 1, true);


--
-- Name: access_grant access_grant_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT access_grant_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_key api_key_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_key_key UNIQUE (key);


--
-- Name: api_key api_key_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_pkey PRIMARY KEY (id);


--
-- Name: auth auth_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth
    ADD CONSTRAINT auth_pkey PRIMARY KEY (id);


--
-- Name: automation automation_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation
    ADD CONSTRAINT automation_pkey PRIMARY KEY (id);


--
-- Name: automation_run automation_run_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_run
    ADD CONSTRAINT automation_run_pkey PRIMARY KEY (id);


--
-- Name: calendar_event_attendee calendar_event_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT calendar_event_attendee_pkey PRIMARY KEY (id);


--
-- Name: calendar_event calendar_event_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event
    ADD CONSTRAINT calendar_event_pkey PRIMARY KEY (id);


--
-- Name: calendar calendar_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar
    ADD CONSTRAINT calendar_pkey PRIMARY KEY (id);


--
-- Name: channel_file channel_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_pkey PRIMARY KEY (id);


--
-- Name: channel_member channel_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_member
    ADD CONSTRAINT channel_member_pkey PRIMARY KEY (id);


--
-- Name: channel channel_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel
    ADD CONSTRAINT channel_pkey PRIMARY KEY (id);


--
-- Name: channel_webhook channel_webhook_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_pkey PRIMARY KEY (id);


--
-- Name: chat_file chat_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_pkey PRIMARY KEY (id);


--
-- Name: chat_message chat_message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_pkey PRIMARY KEY (id);


--
-- Name: chat chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pkey PRIMARY KEY (id);


--
-- Name: chat chat_share_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_share_id_key UNIQUE (share_id);


--
-- Name: chatidtag chatidtag_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chatidtag
    ADD CONSTRAINT chatidtag_pkey PRIMARY KEY (id);


--
-- Name: config config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config
    ADD CONSTRAINT config_pkey PRIMARY KEY (id);


--
-- Name: document document_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_name_key UNIQUE (name);


--
-- Name: document document_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document
    ADD CONSTRAINT document_pkey PRIMARY KEY (collection_name);


--
-- Name: feedback feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pkey PRIMARY KEY (id);


--
-- Name: file file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.file
    ADD CONSTRAINT file_pkey PRIMARY KEY (id);


--
-- Name: folder folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.folder
    ADD CONSTRAINT folder_pkey PRIMARY KEY (id, user_id);


--
-- Name: function function_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.function
    ADD CONSTRAINT function_pkey PRIMARY KEY (id);


--
-- Name: group_member group_member_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_pkey PRIMARY KEY (id);


--
-- Name: group group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pkey PRIMARY KEY (id);


--
-- Name: knowledge_directory knowledge_directory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_pkey PRIMARY KEY (id);


--
-- Name: knowledge_file knowledge_file_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_pkey PRIMARY KEY (id);


--
-- Name: knowledge knowledge_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge
    ADD CONSTRAINT knowledge_pkey PRIMARY KEY (id);


--
-- Name: memory memory_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.memory
    ADD CONSTRAINT memory_pkey PRIMARY KEY (id);


--
-- Name: message message_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pkey PRIMARY KEY (id);


--
-- Name: message_reaction message_reaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.message_reaction
    ADD CONSTRAINT message_reaction_pkey PRIMARY KEY (id);


--
-- Name: model model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model
    ADD CONSTRAINT model_pkey PRIMARY KEY (id);


--
-- Name: note note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.note
    ADD CONSTRAINT note_pkey PRIMARY KEY (id);


--
-- Name: oauth_session oauth_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_pkey PRIMARY KEY (id);


--
-- Name: pinned_note pinned_note_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_pkey PRIMARY KEY (id);


--
-- Name: tag pk_id_user_id; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tag
    ADD CONSTRAINT pk_id_user_id PRIMARY KEY (id, user_id);


--
-- Name: prompt_history prompt_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt_history
    ADD CONSTRAINT prompt_history_pkey PRIMARY KEY (id);


--
-- Name: prompt prompt_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prompt
    ADD CONSTRAINT prompt_new_pkey PRIMARY KEY (id);


--
-- Name: shared_chat shared_chat_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_pkey PRIMARY KEY (id);


--
-- Name: skill skill_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_name_key UNIQUE (name);


--
-- Name: skill skill_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skill
    ADD CONSTRAINT skill_pkey PRIMARY KEY (id);


--
-- Name: tool tool_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tool
    ADD CONSTRAINT tool_pkey PRIMARY KEY (id);


--
-- Name: access_grant uq_access_grant_grant; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.access_grant
    ADD CONSTRAINT uq_access_grant_grant UNIQUE (resource_type, resource_id, principal_type, principal_id, permission);


--
-- Name: channel_file uq_channel_file_channel_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT uq_channel_file_channel_file UNIQUE (channel_id, file_id);


--
-- Name: chat_file uq_chat_file_chat_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT uq_chat_file_chat_file UNIQUE (chat_id, file_id);


--
-- Name: calendar_event_attendee uq_event_attendee; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_event_attendee
    ADD CONSTRAINT uq_event_attendee UNIQUE (event_id, user_id);


--
-- Name: group_member uq_group_member_group_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT uq_group_member_group_user UNIQUE (group_id, user_id);


--
-- Name: knowledge_directory uq_knowledge_directory_knowledge_parent_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT uq_knowledge_directory_knowledge_parent_name UNIQUE (knowledge_id, parent_id, name);


--
-- Name: knowledge_file uq_knowledge_file_knowledge_file; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT uq_knowledge_file_knowledge_file UNIQUE (knowledge_id, file_id);


--
-- Name: pinned_note uq_pinned_note; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT uq_pinned_note UNIQUE (user_id, note_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: chat_message_chat_parent_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_chat_parent_idx ON public.chat_message USING btree (chat_id, parent_id);


--
-- Name: chat_message_model_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_model_created_idx ON public.chat_message USING btree (model_id, created_at);


--
-- Name: chat_message_user_created_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX chat_message_user_created_idx ON public.chat_message USING btree (user_id, created_at);


--
-- Name: folder_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_idx ON public.chat USING btree (folder_id);


--
-- Name: folder_id_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX folder_id_user_id_idx ON public.chat USING btree (folder_id, user_id);


--
-- Name: idx_access_grant_principal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_principal ON public.access_grant USING btree (principal_type, principal_id);


--
-- Name: idx_access_grant_resource; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_access_grant_resource ON public.access_grant USING btree (resource_type, resource_id);


--
-- Name: idx_oauth_session_expires_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_expires_at ON public.oauth_session USING btree (expires_at);


--
-- Name: idx_oauth_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_id ON public.oauth_session USING btree (user_id);


--
-- Name: idx_oauth_session_user_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oauth_session_user_provider ON public.oauth_session USING btree (user_id, provider);


--
-- Name: idx_skill_updated_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_updated_at ON public.skill USING btree (updated_at);


--
-- Name: idx_skill_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_skill_user_id ON public.skill USING btree (user_id);


--
-- Name: is_global_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX is_global_idx ON public.function USING btree (is_global);


--
-- Name: ix_automation_next_run; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_next_run ON public.automation USING btree (next_run_at);


--
-- Name: ix_automation_run_automation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_automation_run_automation_id ON public.automation_run USING btree (automation_id);


--
-- Name: ix_calendar_event_attendee_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_attendee_user ON public.calendar_event_attendee USING btree (user_id, status);


--
-- Name: ix_calendar_event_calendar; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_calendar ON public.calendar_event USING btree (calendar_id, start_at);


--
-- Name: ix_calendar_event_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_event_user_date ON public.calendar_event USING btree (user_id, start_at);


--
-- Name: ix_calendar_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_calendar_user ON public.calendar USING btree (user_id);


--
-- Name: ix_channel_file_channel_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_channel_id ON public.channel_file USING btree (channel_id);


--
-- Name: ix_channel_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_file_id ON public.channel_file USING btree (file_id);


--
-- Name: ix_channel_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_channel_file_user_id ON public.channel_file USING btree (user_id);


--
-- Name: ix_chat_file_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_chat_id ON public.chat_file USING btree (chat_id);


--
-- Name: ix_chat_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_file_id ON public.chat_file USING btree (file_id);


--
-- Name: ix_chat_file_message_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_message_id ON public.chat_file USING btree (message_id);


--
-- Name: ix_chat_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_file_user_id ON public.chat_file USING btree (user_id);


--
-- Name: ix_chat_message_chat_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_chat_id ON public.chat_message USING btree (chat_id);


--
-- Name: ix_chat_message_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_created_at ON public.chat_message USING btree (created_at);


--
-- Name: ix_chat_message_model_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_model_id ON public.chat_message USING btree (model_id);


--
-- Name: ix_chat_message_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_chat_message_user_id ON public.chat_message USING btree (user_id);


--
-- Name: ix_knowledge_directory_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_knowledge_id ON public.knowledge_directory USING btree (knowledge_id);


--
-- Name: ix_knowledge_directory_parent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_directory_parent_id ON public.knowledge_directory USING btree (parent_id);


--
-- Name: ix_knowledge_file_directory_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_directory_id ON public.knowledge_file USING btree (directory_id);


--
-- Name: ix_knowledge_file_file_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_file_id ON public.knowledge_file USING btree (file_id);


--
-- Name: ix_knowledge_file_knowledge_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_knowledge_id ON public.knowledge_file USING btree (knowledge_id);


--
-- Name: ix_knowledge_file_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_knowledge_file_user_id ON public.knowledge_file USING btree (user_id);


--
-- Name: ix_memory_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_memory_user_id ON public.memory USING btree (user_id);


--
-- Name: ix_prompt_history_prompt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX ix_prompt_history_prompt_id ON public.prompt_history USING btree (prompt_id);


--
-- Name: ix_prompt_new_command; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX ix_prompt_new_command ON public.prompt USING btree (command);


--
-- Name: updated_at_user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX updated_at_user_id_idx ON public.chat USING btree (updated_at, user_id);


--
-- Name: user_id_archived_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_archived_idx ON public.chat USING btree (user_id, archived);


--
-- Name: user_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_idx ON public.tag USING btree (user_id);


--
-- Name: user_id_pinned_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX user_id_pinned_idx ON public.chat USING btree (user_id, pinned);


--
-- Name: api_key api_key_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_key
    ADD CONSTRAINT api_key_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: channel_file channel_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT channel_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: channel_webhook channel_webhook_channel_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_webhook
    ADD CONSTRAINT channel_webhook_channel_id_fkey FOREIGN KEY (channel_id) REFERENCES public.channel(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: chat_file chat_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_file
    ADD CONSTRAINT chat_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: chat_message chat_message_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_message
    ADD CONSTRAINT chat_message_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- Name: channel_file fk_channel_file_message_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.channel_file
    ADD CONSTRAINT fk_channel_file_message_id FOREIGN KEY (message_id) REFERENCES public.message(id) ON DELETE CASCADE;


--
-- Name: knowledge_file fk_knowledge_file_directory_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT fk_knowledge_file_directory_id FOREIGN KEY (directory_id) REFERENCES public.knowledge_directory(id) ON DELETE SET NULL;


--
-- Name: group_member group_member_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_group_id_fkey FOREIGN KEY (group_id) REFERENCES public."group"(id) ON DELETE CASCADE;


--
-- Name: group_member group_member_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.group_member
    ADD CONSTRAINT group_member_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: knowledge_directory knowledge_directory_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_directory
    ADD CONSTRAINT knowledge_directory_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.knowledge_directory(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_file_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_file_id_fkey FOREIGN KEY (file_id) REFERENCES public.file(id) ON DELETE CASCADE;


--
-- Name: knowledge_file knowledge_file_knowledge_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knowledge_file
    ADD CONSTRAINT knowledge_file_knowledge_id_fkey FOREIGN KEY (knowledge_id) REFERENCES public.knowledge(id) ON DELETE CASCADE;


--
-- Name: oauth_session oauth_session_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oauth_session
    ADD CONSTRAINT oauth_session_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE CASCADE;


--
-- Name: pinned_note pinned_note_note_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pinned_note
    ADD CONSTRAINT pinned_note_note_id_fkey FOREIGN KEY (note_id) REFERENCES public.note(id) ON DELETE CASCADE;


--
-- Name: shared_chat shared_chat_chat_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.shared_chat
    ADD CONSTRAINT shared_chat_chat_id_fkey FOREIGN KEY (chat_id) REFERENCES public.chat(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

